# AAYS Layer24 ChatGPT Contract V2

This contract is authoritative for `AAYS_LAYER24_EVIDENCE_V1`. The older 21-slot
GitHub contract is source history only and cannot reject or own Layer24 slots.

## Slots and partitions

The only valid writers are `gas_emissions_1..6`, `height_difference_1..6`,
`security_public_safety_1..6`, and `internet_access_1..6`. Suffixes map to parcel
ranges `1-15381`, `15382-30762`, `30763-46143`, `46144-61523`, `61524-76903`,
and `76904-92283`. Each slot writes only its own range. `topography_N` is an alias
for `height_difference_N` and is not a separate writer.

## Page and prompt gate

Every logical slot has one lineage. A physical page may rotate, but a new page
must receive the start prompt before any continuation. A continuation is valid
only after a recorded start delivery for the current page generation. Shared or
read-only pages are `HELD_ACCOUNT_ACCESS`; rate-limited pages are `HELD_RATE_LIMIT`.
Neither state is progress. Missing page bindings remain `UNBOUND_PAGE`.

## Accepted progress

Progress requires a downloadable ZIP named
`AAYS_LAYER24__<SLOT_ID>__<LINEAGE_ID>__g<PAGE_GENERATION>__<BATCH_ID>.zip`.
It must contain `records.geojson`, `evidence_manifest.json`,
`source_ledger.jsonl`, `unmatched.jsonl`, `checkpoint.json`, `receipt.json`, and
matching SHA-256 sidecars. The importer accepts two evidence scopes.
`coverage_area` records use an official Polygon/MultiPolygon, a stable
`coverage_area_id`, source resolution, time window, legal public no-login source,
exact selector, spatial binding, confidence, evidence grade, and duplicate checks.
`direct_parcel` records use a canonical parcel ID and the true parcel
Polygon/MultiPolygon. Coverage-area rows are source evidence only; the local
materializer spatially joins them to every matching canonical parcel. They must
never be counted as direct parcel measurements.

An HTTP response, generated prompt, busy state, prose report, unchanged hash,
or ZIP that was not downloaded and imported does not increase accepted totals.
Only importer readback with a new semantic ID and matching receipt/sidecar does.

## Family semantics

- `gas_emissions`: collect each official DESNZ/UK-AIR geographic area once, then
  spatially materialize its dated value to every matching program parcel.
- `height_difference`: direct coverage of every canonical parcel using official OS
  Terrain/LIDAR data, true parcel geometry, CRS, tile/grid/cell, nodata,
  min/max/mean, and `height_difference=max-min`. Unprocessed parcels are not
  progress.
- `security_public_safety`: collect each official safety coverage area and time
  window once, record the score formula, then spatially materialize it to all
  matching parcels. Area evidence remains labelled as area-derived.
- `internet_access`: use an official coverage area or exact postcode/equivalent
  official identifier, then materialize it to matching parcels. District,
  outward-code, and nearest-only joins are proxy evidence.

Counters are distinct: `source_area_count`, `materialized_parcel_count`,
`direct_parcel_count`, and `unprocessed_count`. The current loaded program
inventory has 92,283 parcel centroids; this is not proof of full England coverage.
Full-England completion requires a verified national canonical parcel polygon
inventory with stable IDs and an independently checked denominator.

Every continuation must select exactly one semantic mode before acquisition:
`AREA_JOIN` for gas, security and internet, or `DIRECT_ALL` for height. An area
row is never a completed parcel row. `DIRECT_ALL` must account for every parcel
in its partition as direct evidence or explicit `UNPROCESSED`; a source-area,
proxy or nearest match cannot satisfy it.

For multi-PC delivery, an authorized producer uploads packages to
`cagdascagdas100/chat_gpt_clone_1` under `incoming/layer24/` and records the remote
commit SHA and exact path. Otherwise it returns `DELIVERY_TRANSPORT_REQUIRED` with
a downloadable ZIP. A remote commit SHA is mandatory evidence of GitHub delivery.
The presence of a ZIP in a producer PC's Downloads folder is not delivery. Local
progress additionally requires receiver copy/receipt SHA, import, canonical
readback, publication, and live panel evidence on this PC.

Batch size is at most 50. Three consecutive zero-accept batches must change the
authority, source family, parser, spatial binding method, or parcel window.
Evidence may never be invented.
