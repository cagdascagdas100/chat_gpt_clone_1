AAYS ChatGPT Producer ZIP Transport

Purpose
-------
This kit runs on every Windows PC where ChatGPT creates AAYS ZIP files.
It watches that PC's Downloads folder, validates the ZIP and all SHA-256
sidecars, and uploads a retained copy to:

  https://github.com/cagdascagdas100/chat_gpt_clone_1.git
  incoming/plan0/<COMPUTERNAME>/
  incoming/layer24/<COMPUTERNAME>/

The original ZIP is never deleted. This receiving PC already fetches those
paths and routes valid packages into the F: import inboxes.

One-time setup on each producer PC
----------------------------------
1. Download bootstrap/AAYS_CHATGPT_PRODUCER_KIT.zip from
   https://github.com/cagdascagdas100/chat_gpt_clone_1 and extract it.
2. Make sure Git for Windows is installed and GitHub push authentication for
   cagdascagdas100/chat_gpt_clone_1 is available in Git Credential Manager.
3. Right-click INSTALL_ON_THIS_PC.ps1 and run with PowerShell.
4. Run START_NOW.cmd once. Afterwards the uploader also starts at logon.

Prompt files
------------
Use the current files under PROMPTS instead of an older saved continuation.
Plan 0 pages use AAYS_PLAN0_CHATGPT_FAST_START_V4.txt once and
AAYS_PLAN0_CHATGPT_FAST_CONTINUE_V4.txt for later turns. Layer24 pages use the
UNIFIED start/continue files. The COMMON files contain the shared 47-slot gate.
These continuations enforce AREA_JOIN, DIRECT_ALL, CLASSIFY_ALL and
DISTINCT_BUILDINGS semantics and require GitHub delivery proof.

This one-time installation is required on each computer whose Downloads
folder receives ChatGPT ZIPs. A different computer cannot read that local
Downloads folder through GitHub until this uploader commits the package.

Proof
-----
Successful deliveries create a JSON receipt under:

  %USERPROFILE%\AAYS_CHATGPT_UPLOAD_RECEIPTS

A successful receipt contains status=UPLOADED, github_path and
remote_commit_sha. A downloaded ZIP without that receipt has not reached this
computer through GitHub.
