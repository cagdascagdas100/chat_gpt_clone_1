[CmdletBinding()]
param(
    [string]$RepoDir = $(if (Test-Path -LiteralPath "F:\") { "F:\AAYS_GITHUB_DELIVERY_CLIENT" } else { "$env:USERPROFILE\AAYS_GITHUB_DELIVERY_CLIENT" }),
    [string]$DownloadsDir = "$env:USERPROFILE\Downloads",
    [string]$Branch = "main",
    [int]$PollSeconds = 30,
    [switch]$Once
)

$ErrorActionPreference = "Stop"
$OriginUrl = "https://github.com/cagdascagdas100/chat_gpt_clone_1.git"
$RequiredMembers = @(
    "records.geojson", "evidence_manifest.json", "source_ledger.jsonl",
    "unmatched.jsonl", "checkpoint.json", "receipt.json"
)
$Plan0Categories = @("future_growth_new", "building_type_new", "planned_building_new")

Add-Type -AssemblyName System.IO.Compression.FileSystem

function Invoke-AaysGit {
    param([Parameter(Mandatory)][string[]]$Arguments)
    $output = & git -c "safe.directory=$RepoDir" -C $RepoDir @Arguments 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "git $($Arguments -join ' ') failed: $($output -join [Environment]::NewLine)"
    }
    return @($output)
}

function Get-EntryBytes {
    param(
        [Parameter(Mandatory)]$Entry
    )
    $stream = $Entry.Open()
    try {
        $memory = [System.IO.MemoryStream]::new()
        try {
            $stream.CopyTo($memory)
            return $memory.ToArray()
        }
        finally {
            $memory.Dispose()
        }
    }
    finally {
        $stream.Dispose()
    }
}

function Get-Sha256Hex {
    param([Parameter(Mandatory)][byte[]]$Bytes)
    $algorithm = [System.Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString($algorithm.ComputeHash($Bytes))).Replace("-", "").ToLowerInvariant()
    }
    finally {
        $algorithm.Dispose()
    }
}

function Test-AaysPackage {
    param([Parameter(Mandatory)][System.IO.FileInfo]$File)
    $archive = [System.IO.Compression.ZipFile]::OpenRead($File.FullName)
    try {
        $entries = @{}
        foreach ($entry in $archive.Entries) {
            if (-not $entry.Name) { continue }
            if ($entries.ContainsKey($entry.Name)) {
                throw "duplicate ZIP basename: $($entry.Name)"
            }
            $entries[$entry.Name] = $entry
        }
        foreach ($name in $RequiredMembers) {
            if (-not $entries.ContainsKey($name)) { throw "missing ZIP member: $name" }
            $sidecar = "$name.sha256"
            if (-not $entries.ContainsKey($sidecar)) { throw "missing ZIP sidecar: $sidecar" }
            $actual = Get-Sha256Hex (Get-EntryBytes $entries[$name])
            $claimedText = [Text.Encoding]::UTF8.GetString((Get-EntryBytes $entries[$sidecar])).Trim()
            $claimed = (($claimedText -split '\s+')[0] -split '=', 2)[-1].ToLowerInvariant()
            if ($claimed -ne $actual) { throw "sidecar mismatch: $sidecar" }
        }
        $receipt = [Text.Encoding]::UTF8.GetString((Get-EntryBytes $entries["receipt.json"])) | ConvertFrom-Json
        $accepted = if ($null -ne $receipt.accepted_count) {
            [int]$receipt.accepted_count
        }
        else {
            [int]$receipt.batch_summary.accepted_count
        }
        $duplicates = if ($null -ne $receipt.duplicate_count) {
            [int]$receipt.duplicate_count
        }
        elseif ($null -ne $receipt.batch_summary.duplicate_count) {
            [int]$receipt.batch_summary.duplicate_count
        }
        else { 0 }
        if ($accepted -le 0) { throw "accepted_count must be positive" }
        if ($duplicates -ne 0) { throw "duplicate_count must be zero" }

        $category = [string]$receipt.category
        $slotId = [string]$receipt.slot_id
        if ($category -eq "AAYS_LAYER24_EVIDENCE_V1") {
            if ($slotId -notmatch '^(gas_emissions|height_difference|security_public_safety|internet_access)_[1-6]$') {
                throw "invalid Layer24 slot: $slotId"
            }
            $family = "layer24"
        }
        elseif ($Plan0Categories -contains $category) {
            if ($slotId -notmatch '^(future_growth|building_type)_[1-9]$|^planned_buildings_[1-5]$') {
                throw "invalid Plan0 slot: $slotId"
            }
            $family = "plan0"
        }
        else {
            throw "unsupported receipt category: $category"
        }
        return [pscustomobject]@{
            Family = $family
            Category = $category
            SlotId = $slotId
            AcceptedCount = $accepted
            DuplicateCount = $duplicates
        }
    }
    finally {
        $archive.Dispose()
    }
}

function Initialize-AaysRepo {
    if (-not (Test-Path -LiteralPath $RepoDir -PathType Container)) {
        $parent = Split-Path -Parent $RepoDir
        New-Item -ItemType Directory -Path $parent -Force | Out-Null
        & git clone --branch $Branch --single-branch --depth 1 --filter=blob:none --no-checkout $OriginUrl $RepoDir
        if ($LASTEXITCODE -ne 0) { throw "GitHub bridge clone failed" }
        Invoke-AaysGit -Arguments @("sparse-checkout", "init", "--cone") | Out-Null
        Invoke-AaysGit -Arguments @("sparse-checkout", "set", "incoming") | Out-Null
        Invoke-AaysGit -Arguments @("checkout", $Branch) | Out-Null
    }
    if (-not (Test-Path -LiteralPath (Join-Path $RepoDir ".git") -PathType Container)) {
        throw "RepoDir is not a Git repository: $RepoDir"
    }
    $origin = (Invoke-AaysGit -Arguments @("remote", "get-url", "origin") | Select-Object -First 1).Trim()
    $normalizedOrigin = $origin.TrimEnd("/")
    if ($normalizedOrigin.EndsWith(".git")) { $normalizedOrigin = $normalizedOrigin.Substring(0, $normalizedOrigin.Length - 4) }
    $normalizedExpected = $OriginUrl.Substring(0, $OriginUrl.Length - 4)
    if ($normalizedOrigin -ne $normalizedExpected) {
        throw "Unexpected origin: $origin"
    }
    $userName = (& git -c "safe.directory=$RepoDir" -C $RepoDir config --get user.name 2>$null | Select-Object -First 1)
    $userEmail = (& git -c "safe.directory=$RepoDir" -C $RepoDir config --get user.email 2>$null | Select-Object -First 1)
    if (-not $userName) {
        Invoke-AaysGit -Arguments @("config", "user.name", "AAYS ChatGPT Producer $env:COMPUTERNAME") | Out-Null
    }
    if (-not $userEmail) {
        Invoke-AaysGit -Arguments @("config", "user.email", "aays-producer@users.noreply.github.com") | Out-Null
    }
}

function Write-UploadReceipt {
    param([Parameter(Mandatory)]$Value)
    $root = Join-Path (Split-Path -Parent $RepoDir) "AAYS_CHATGPT_UPLOAD_RECEIPTS"
    New-Item -ItemType Directory -Path $root -Force | Out-Null
    $stamp = [DateTime]::UtcNow.ToString("yyyyMMddTHHmmssfffZ")
    $path = Join-Path $root "$stamp.json"
    $Value | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $path -Encoding utf8
}

function Invoke-UploadCycle {
    Initialize-AaysRepo
    if (-not (Test-Path -LiteralPath $DownloadsDir -PathType Container)) {
        throw "DownloadsDir does not exist: $DownloadsDir"
    }
    $dirty = @(Invoke-AaysGit -Arguments @("status", "--porcelain"))
    if ($dirty.Count -gt 0) { throw "Bridge repository has unrelated local changes; refusing automatic upload" }
    Invoke-AaysGit -Arguments @("pull", "--rebase", "origin", $Branch) | Out-Null

    $candidates = Get-ChildItem -LiteralPath $DownloadsDir -File -Filter "*.zip" |
        Where-Object { $_.Name -like "AAYS_PLAN0__*.zip" -or $_.Name -like "AAYS_LAYER24__*.zip" } |
        Sort-Object LastWriteTimeUtc
    foreach ($file in $candidates) {
        try {
            $package = Test-AaysPackage -File $file
            $sha = (Get-FileHash -Algorithm SHA256 -LiteralPath $file.FullName).Hash.ToLowerInvariant()
            $machine = ($env:COMPUTERNAME -replace '[^A-Za-z0-9_.-]', '_')
            $base = [IO.Path]::GetFileNameWithoutExtension($file.Name)
            $relative = "incoming/$($package.Family)/$machine/${base}__$($sha.Substring(0, 16)).zip"
            $destination = Join-Path $RepoDir ($relative -replace '/', [IO.Path]::DirectorySeparatorChar)
            if (Test-Path -LiteralPath $destination) { continue }
            New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
            Copy-Item -LiteralPath $file.FullName -Destination $destination
            Invoke-AaysGit -Arguments @("add", "--", $relative) | Out-Null
            Invoke-AaysGit -Arguments @("commit", "-m", "AAYS $($package.SlotId) package $($sha.Substring(0, 12))") | Out-Null
            try {
                Invoke-AaysGit -Arguments @("push", "origin", "HEAD:$Branch") | Out-Null
            }
            catch {
                Invoke-AaysGit -Arguments @("pull", "--rebase", "origin", $Branch) | Out-Null
                Invoke-AaysGit -Arguments @("push", "origin", "HEAD:$Branch") | Out-Null
            }
            $commit = (Invoke-AaysGit -Arguments @("rev-parse", "HEAD") | Select-Object -First 1).Trim()
            Write-UploadReceipt ([ordered]@{
                utc = [DateTime]::UtcNow.ToString("o")
                status = "UPLOADED"
                source = $file.FullName
                sha256 = $sha
                category = $package.Category
                slot_id = $package.SlotId
                accepted_count = $package.AcceptedCount
                github_path = $relative
                remote_commit_sha = $commit
                source_retained = $true
            })
        }
        catch {
            Write-UploadReceipt ([ordered]@{
                utc = [DateTime]::UtcNow.ToString("o")
                status = "REJECTED_OR_UPLOAD_FAILED"
                source = $file.FullName
                error = $_.Exception.Message
                source_retained = $true
            })
        }
    }
}

$lockPath = Join-Path (Split-Path -Parent $RepoDir) ".aays_chatgpt_zip_uploader.lock"
$lock = $null
try {
    New-Item -ItemType Directory -Path (Split-Path -Parent $RepoDir) -Force | Out-Null
    $lock = [IO.File]::Open($lockPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    do {
        Invoke-UploadCycle
        if (-not $Once) { Start-Sleep -Seconds ([Math]::Max(10, $PollSeconds)) }
    } while (-not $Once)
}
finally {
    if ($lock) { $lock.Dispose() }
    Remove-Item -LiteralPath $lockPath -Force -ErrorAction SilentlyContinue
}
