[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$uploader = Join-Path $PSScriptRoot "AAYS_CHATGPT_ZIP_UPLOADER.ps1"
if (-not (Test-Path -LiteralPath $uploader -PathType Leaf)) {
    throw "Uploader script is missing: $uploader"
}
$taskName = "AAYS ChatGPT ZIP Uploader"
$quotedUploader = '"' + $uploader + '"'
$command = "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File $quotedUploader"
& schtasks.exe /Create /SC ONLOGON /TN $taskName /TR $command /F | Out-Host
if ($LASTEXITCODE -ne 0) {
    throw "Scheduled task creation failed with exit code $LASTEXITCODE"
}
Write-Host "Installed: $taskName"
Write-Host "Run START_NOW.cmd to begin immediately."
