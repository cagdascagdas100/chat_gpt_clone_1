@echo off
start "AAYS ChatGPT ZIP Uploader" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0AAYS_CHATGPT_ZIP_UPLOADER.ps1"
