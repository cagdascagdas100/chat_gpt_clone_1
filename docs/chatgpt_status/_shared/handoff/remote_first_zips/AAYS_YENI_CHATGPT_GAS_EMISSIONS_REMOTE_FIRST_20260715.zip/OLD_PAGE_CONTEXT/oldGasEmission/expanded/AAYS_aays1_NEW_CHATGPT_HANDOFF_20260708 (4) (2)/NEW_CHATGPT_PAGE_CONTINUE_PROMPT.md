# AAYS / TerraYield — New ChatGPT Page Continue Prompt

Bu ZIP paketini oku ve aynı PAGE_KEY ile kaldığın yerden devam et.

## Sabit bilgiler

```text
PAGE_KEY=aays1
REPO_ROOT=C:\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707
BRANCH=codex/aays-single-runner-v5-20260706
LAUNCHER=C:\Users\cagda\Documents\GitHub\AAYS\START_AAYS_RUNNER.bat
RUNNER=RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707
```

## Kurallar

- Yeni runner açma.
- Paralel runner açma.
- Yeni V5 runner başlatma.
- Aynı stable shared runner akışını kullan.
- Önce ZIP içindeki `HANDOFF_SUMMARY.md` dosyasını oku.
- Sonra `github_snapshot/` altındaki queue/status/reports/heartbeat/runner_outputs kanıtlarını oku.
- GitHub’da güncel durum gerekiyorsa şu dosyaları tekrar oku:
  - `docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json`
  - `docs/chatgpt_status/_shared/status/stable_runner_daemon_latest.json`
  - `docs/chatgpt_status/_shared/status/MULTI_PAGE_latest_status.json`
  - `docs/chatgpt_status/aays1/status/aays1_site_visible_current_status_latest.json`
  - `docs/chatgpt_status/aays1/status/aays1_required_resources_latest.json`
  - `docs/chatgpt_status/aays1/queue/`
  - `docs/chatgpt_status/aays1/status/`
  - `docs/chatgpt_status/aays1/reports/`
  - `docs/chatgpt_status/aays1/heartbeat/`
  - `docs/chatgpt_status/aays1/runner_outputs/`
  - `docs/chatgpt_status/aays1/automation/`

## Kullanıcı sadece `devam et` derse yapılacak işlem

1. PAGE_KEY=`aays1` kabul et.
2. Önce mevcut aays1 status/resource dosyalarını oku.
3. Pending task varsa yeni task yazma; runner pickup/output kanıtını bekle ve raporla.
4. Valid task yoksa sadece `docs/chatgpt_status/aays1/` altında sözleşmeye uygun yeni queue task yaz.
5. Sonraki eksik program adımını ilerlet:
   - 046 recovery
   - preflight
   - watchdog/stuck detector
   - endpoint health
   - red-flag quickscan
   - 044 accuracy expansion
6. Site-visible output dosyalarını güncelle.
7. Kısa cevap ver:
   - yapılan işlemler
   - genel yüzde
   - bu tur artış
   - bekleme notu
   - blocker
   - final

## Yasaklar

- Sahte completed yazma.
- Sahte %100 yazma.
- Sahte final_ready=true yazma.
- GitHub kanıtı olmadan metrik artırma.
- fake_data=true yazma.
- db_write=true yazma.
- migration=true yazma.
- production_deploy=true yazma.
- DB, migration, production deploy yapma.
- Başka PAGE_KEY kullanma.

## Mevcut son durum

- aays1 visible sync çıktı dosyaları GitHub’da var.
- aays1 current status aktif programı gösteriyor.
- aays1 required resources listesi var.
- Genel program yüzdesi: 35.
- Görünür yapı yüzdesi: 60.
- final_ready=false.

## Kalan blockerlar

- `SHARED_MULTI_PAGE_LATEST_STATUS_STALE_FOR_GLOBAL_RUNNER_VIEW`
- `046_RECOVERY_OUTPUTS_NOT_YET_PRODUCED`
- `044_ACCURACY_EXPANSION_OUTPUTS_NOT_YET_PRODUCED`
- `SITE_PANEL_OUTPUT_MAPPING_NOT_VERIFIED`

## Cevap formatı

Kısa yaz:

```text
Yapılan işlemler:
- ...

Yüzde:
- Genel: %..
- Bu tur artış: +%..

Bekleme:
- ...

Blocker:
- ...

Final: false
```
