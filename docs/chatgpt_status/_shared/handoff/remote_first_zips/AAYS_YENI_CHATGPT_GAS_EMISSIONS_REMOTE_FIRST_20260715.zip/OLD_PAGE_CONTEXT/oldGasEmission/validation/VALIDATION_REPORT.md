# oldGasEmission Birleştirme ve Doğrulama Raporu

- Oluşturulma zamanı (UTC): `2026-07-11T00:40:07.383208+00:00`
- Kaynak dosya sayısı: `4`
- Orijinal dosyalar byte-for-byte korunmuştur.
- Her iç ZIP için CRC/bütünlük testi çalıştırılmıştır.
- İçerikler çakışmayı önlemek için ayrı klasörlere açılmıştır.
- Yol geçişi (`../`) ve mutlak yol güvenlik kontrolü uygulanmıştır.

## Kaynaklar

### AAYS_aays1_NEW_CHATGPT_HANDOFF_20260710(1)(1).zip
- Boyut: `190366` bayt
- SHA-256: `2cf898879785b470924f16406bfdead64fd223867ec7c6b6509e39455c79be05`
- ZIP bütünlüğü: `PASS`
- Girdi sayısı: `25`
- Açılan dosya sayısı: `25`
- Sıkıştırılmamış toplam boyut: `215635` bayt

### NEW_CHATGPT_PAGE_CONTINUE_PROMPT(2).md
- Boyut: `3697` bayt
- SHA-256: `dd56f30dfc896cb43a1b83af1f3d8afa9e91c8215044c2d5adc06463067e6dd2`
- Kodlama: `UTF-8`
- Satır sayısı: `125`

### AAYS_aays1_NEW_CHATGPT_HANDOFF_20260708 (4) (2).zip
- Boyut: `29430` bayt
- SHA-256: `1ba6a1dc0e5731cdb8a57c31882ffa3dd24cdf936df67a6f914bbd90c8dcf51c`
- ZIP bütünlüğü: `PASS`
- Girdi sayısı: `24`
- Açılan dosya sayısı: `24`
- Sıkıştırılmamış toplam boyut: `62241` bayt

### gas_emissions_final_handoff_20260703 (2).zip
- Boyut: `11087` bayt
- SHA-256: `cd24515f09d2559f9ac16c5959ced12e010e9df7a60d42fb13bc9a058cd540f0`
- ZIP bütünlüğü: `PASS`
- Girdi sayısı: `13`
- Açılan dosya sayısı: `10`
- Sıkıştırılmamış toplam boyut: `20001` bayt
