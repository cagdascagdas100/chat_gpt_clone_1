# NEXT_ACTION_PLAN

## Son durum

- Panel: %74
- Verified rows: 174
- CSV rows: 174
- GeoJSON features: 174
- Accuracy >=3: 174
- Kalan: %26
- Sıradaki hedef: %75
- Hedefe kalan: 1 source-backed row
- Final: false

## Yeni sayfada ilk yapılacak iş

1. Runner proof dosyalarını oku.
2. Panel ve product status dosyalarını oku.
3. Mevcut durum %74 ise, %75 için en az 1 yeni internet kaynaklı satır doğrula.
4. Kaynak doğrulanırsa yeni CSV/GeoJSON/status/panel çıktısı yaz.
5. Gerçek output yoksa yüzde artırma.
6. Browser smoke/right panel proof olmadan final_ready=true yazma.

## Geometri politikası

Canonical boundary/parcel geometri kanıtı yoksa `geometry:null` kullanılacak.
