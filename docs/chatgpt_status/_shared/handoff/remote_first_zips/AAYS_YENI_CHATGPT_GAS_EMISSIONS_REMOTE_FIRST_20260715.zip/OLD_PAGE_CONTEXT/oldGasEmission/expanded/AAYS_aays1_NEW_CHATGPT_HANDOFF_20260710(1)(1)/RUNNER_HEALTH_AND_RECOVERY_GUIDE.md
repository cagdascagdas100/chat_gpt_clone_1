# RUNNER_HEALTH_AND_RECOVERY_GUIDE

## Canonical runner

```text
F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd
```

## Canonical repo

```text
F:\TerraYield_AAYS_Portable\runner_system\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707
```

## Canonical rule

F portable tek shared runner kullanılacak. Yeni runner veya paralel runner açılmayacak. C:\ canonical kabul edilmeyecek.

## Yeni sayfada ilk sağlık kontrolü

GitHub’dan şu dosyalar okunacak:

```text
docs/chatgpt_status/aays1/status/134_f_portable_one_click_recovery_test_latest.json
docs/chatgpt_status/aays1/status/130_f_portable_one_click_recovery_bootstrap_latest.json
docs/chatgpt_status/_shared/heartbeat/stable_runner_daemon_heartbeat_latest.json
docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json
docs/chatgpt_status/_shared/locks/single_runner.lock
```

Sağlıklı kabul şartı:

```text
runner_active=true
pid_alive=true
lock_valid=true
git_push_status=pushed
final_ready=false
fake_data=false
db_write=false
migration=false
production_deploy=false
```

## Sağlıklı değilse verilecek tek mesaj

```text
F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd dosyasına çift tıkla, sonra bu sayfaya devam yaz.
```
