param(
  [string]$TaskPath = "docs\chatgpt_status\gas_emissions\current_task\gas_emissions_current_task_20260703.json",
  [string]$VerifiedRowsCsv = "docs\chatgpt_status\gas_emissions\fixtures\gas_emissions_verified_rows_template_20260703.csv",
  [string]$SiteVisibleJson = "outputs\england_program_parcel_matrix_20260629\gas_emissions_updates\latest_changes.json"
)

$ErrorActionPreference = "Stop"
$RepoRoot = if ($env:AAYS_REPO_ROOT) { $env:AAYS_REPO_ROOT } else { (Resolve-Path ".").Path }
$TaskFullPath = Join-Path $RepoRoot $TaskPath
$RowsFullPath = Join-Path $RepoRoot $VerifiedRowsCsv
$SiteJsonFullPath = Join-Path $RepoRoot $SiteVisibleJson
$ReportDir = Join-Path $RepoRoot "docs\chatgpt_status\gas_emissions\reports"
$StatusDir = Join-Path $RepoRoot "docs\chatgpt_status\gas_emissions\status"
$HeartbeatDir = Join-Path $RepoRoot "docs\chatgpt_status\gas_emissions\heartbeat"
New-Item -ItemType Directory -Force -Path $ReportDir,$StatusDir,$HeartbeatDir,(Split-Path -Parent $SiteJsonFullPath) | Out-Null

$ts = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
$rows = @()
if (Test-Path -LiteralPath $RowsFullPath) {
  $rows = @(Import-Csv -LiteralPath $RowsFullPath)
}

$realRows = @($rows | Where-Object {
  $_.parcel_id -and
  $_.parcel_id -notlike "REPLACE_WITH_*" -and
  $_.emission_percent -ne "" -and
  $_.source_url -and
  $_.source_url -notlike "REPLACE_WITH_*"
})

$changes = @($realRows | ForEach-Object {
  [ordered]@{
    parcel_id = $_.parcel_id
    parcel_ref = $_.parcel_ref
    emission_percent = if ($_.emission_percent -ne "") { [double]$_.emission_percent } else { $null }
    gas_emission_level = $_.gas_emission_level
    risk_color = $_.risk_color
    confidence_percent = if ($_.confidence_percent -ne "") { [double]$_.confidence_percent } else { $null }
    source = $_.source
    source_url = $_.source_url
    source_date = $_.source_date
    matching_method = $_.matching_method
    calculation_explanation = $_.calculation_explanation
    accuracy_score_4 = if ($_.accuracy_score_4 -ne "") { [double]$_.accuracy_score_4 } else { 0 }
    needs_manual_review = [bool]::Parse((($_.needs_manual_review, "true") | Select-Object -First 1).ToString())
    changed_in_latest_run = [bool]::Parse((($_.changed_in_latest_run, "false") | Select-Object -First 1).ToString())
    change_reason = "Runner imported verified Gas Emissions row from CSV template."
  }
})

$finalReady = ($changes.Count -gt 0) -and (($changes | Where-Object { $_.accuracy_score_4 -lt 3 -or $_.needs_manual_review }).Count -eq 0)
$payload = [ordered]@{
  layer = "Gas Emissions"
  program_output = "Gas Emission Level"
  status = if ($finalReady) { "RUNNER_VERIFIED_SITE_VISIBLE" } else { "WAITING_FOR_VERIFIED_SOURCE_ROWS" }
  fake_data = $false
  db_write = $false
  migration_apply = $false
  prod_deploy = $false
  last_updated = $ts
  runner_status = "single_runner_bridge_completed"
  verification_score_before = "0/4"
  verification_score_after = if ($finalReady) { "3/4" } elseif ($changes.Count -gt 0) { "2/4" } else { "0/4" }
  next_action = if ($finalReady) { "Open 8020 matrix site and verify Gas Emissions updated changes panel." } else { "ChatGPT must replace template CSV rows with verified source-backed parcel rows, then rerun this bridge." }
  summary = [ordered]@{
    changed_count = $changes.Count
    verified_count = @($changes | Where-Object { $_.accuracy_score_4 -ge 3 }).Count
    manual_review_count = @($changes | Where-Object { $_.needs_manual_review }).Count
    accuracy_ge_3_count = @($changes | Where-Object { $_.accuracy_score_4 -ge 3 }).Count
    final_ready = $finalReady
  }
  expected_output_files = @(
    "england_map_web/data/parcel_emissions_scores.geojson",
    "england_map_web/data/parcel_air_quality_scores.geojson",
    "outputs/england_program_parcel_matrix_20260629/gas_emissions_updates/latest_changes.json"
  )
  changes = $changes
}

$json = $payload | ConvertTo-Json -Depth 12
Set-Content -LiteralPath $SiteJsonFullPath -Value $json -Encoding UTF8
Set-Content -LiteralPath (Join-Path $StatusDir "gas_emissions_current_status_20260703.txt") -Value @(
  "layer=Gas Emissions",
  "task_path=$TaskPath",
  "site_visible_json=$SiteVisibleJson",
  "runner_status=$($payload.runner_status)",
  "final_ready=$finalReady",
  "changed_count=$($changes.Count)",
  "verification_score_after=$($payload.verification_score_after)",
  "updated_at=$ts"
) -Encoding UTF8
Set-Content -LiteralPath (Join-Path $HeartbeatDir "gas_emissions_single_runner_bridge_20260703_heartbeat.txt") -Value "heartbeat=$ts" -Encoding UTF8
Set-Content -LiteralPath (Join-Path $ReportDir "gas_emissions_progress_latest_20260703.md") -Value @(
  "# Gas Emissions Progress Latest",
  "",
  "updated_at=$ts",
  "runner_status=$($payload.runner_status)",
  "final_ready=$finalReady",
  "verification_score_after=$($payload.verification_score_after)",
  "site_visible_json=$SiteVisibleJson",
  "changed_count=$($changes.Count)",
  "",
  "## Next Action",
  $payload.next_action
) -Encoding UTF8

Write-Output "gas_emissions_single_runner_bridge_completed"
