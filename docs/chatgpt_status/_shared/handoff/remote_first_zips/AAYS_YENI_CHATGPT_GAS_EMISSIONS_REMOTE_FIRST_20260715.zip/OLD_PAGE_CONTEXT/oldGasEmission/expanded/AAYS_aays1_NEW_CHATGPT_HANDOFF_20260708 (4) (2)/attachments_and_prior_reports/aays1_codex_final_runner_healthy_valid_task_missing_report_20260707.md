# AAYS / TerraYield - aays1 Codex Handoff Report

## Sonuç

Runner sağlıklı görünüyor. Problem runner'ın çalışmaması değil; aays1 için başlatılacak valid queued task olmaması.

## Güncel GitHub kanıtı

### runner_bootstrap_latest.json

- repo_root: C:\AAYS_WT\AAYS_RUNNER_CLEAN_20260707
- runner_status: runner_active
- runner_engine: stable_legacy_worktree_runner_20260707
- scan_runner: RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707
- runner_pid: 5324
- runner_lock_active: true
- CONTINUE_RUNNER_READY: true
- final_ready: false
- product_final_ready: false
- fake_data: false
- db_write: false
- migration: false
- production_deploy: false

### stable_runner_daemon_latest.json

- status: runner_loop_completed
- scan_runner: RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707
- runner_exit_code: 0
- CONTINUE_RUNNER_READY: true
- controller_sync_ok: true
- controller_sync_mode: restore_runtime_then_fetch_rebase_controller
- final_ready: false
- fake_data: false
- db_write: false
- migration: false
- production_deploy: false

### MULTI_PAGE_latest_status.json

- run_id: 20260707_212504
- queue_seen: true
- queue_started: false
- single_runner_lock_acquired: true
- processed: []
- skipped: []
- blockers: []
- controller_sync_ok: true
- final_ready: false
- runner_output_uploaded: false

## Teşhis

Stable runner artık doğru runner kimliğiyle çalışıyor ve exit_code=0 dönüyor. Fakat queue_started=false ve processed boş. Bu, runner'ın valid task bulmadığını gösterir.

Eski aays1 queue işleri valid iş değildir:
- normalized_065_progress_report_20260706.json: status=blocked, BLOCKED_WORKTREE_DIRTY_EXISTING_OUTPUTS
- normalized_080_restore_75_rel_20260706.json: status=blocked, BLOCKED_080_REPAIR_SOURCE_CSV_MISSING, obsolete/fail-closed

Bu eski işler completed yapılmamalı ve final_ready=true yapılmamalı.

## Codex'ten istenen net iş

1. Runner'ı yeniden icat etme veya yeni runner açma.
2. Mevcut stable runner'ı kullan:
   docs/chatgpt_status/_shared/automation/RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707.ps1
3. aays1 için gerçek yapılacak işi temsil eden yeni valid task üret.
4. Task dosyasını şuraya yaz:
   docs/chatgpt_status/aays1/queue/<new_task>.task.json
5. Task minimum şu alanları içermeli:
   - page_key: aays1
   - status: queued
   - target_branch: codex/aays-single-runner-v5-20260706
   - script_path: docs/chatgpt_status/aays1/automation/<script>.ps1
   - allowed_paths: ["docs/chatgpt_status/aays1/"]
   - new_runner_allowed: false
   - single_shared_runner_required: true
   - final_ready: false
   - fake_data: false
   - db_write: false
   - migration: false
   - production_deploy: false
6. Task gereksizse completed yapma; status=blocked veya skipped_obsolete yaz.
7. Kabul kanıtı:
   - MULTI_PAGE_latest_status.json yeni timestamp
   - queue_seen=true
   - queue_started=true
   - processed içinde aays1 task_id
   - aays1 altında status/report/heartbeat/runner_outputs kanıtı
   - final_ready=false

## Kısa blocker

VALID_AAYS1_TASK_MISSING

## Güvenlik bayrakları

- completed=false
- final_ready=false
- product_final_ready=false
- fake_data=false
- db_write=false
- migration=false
- production_deploy=false
