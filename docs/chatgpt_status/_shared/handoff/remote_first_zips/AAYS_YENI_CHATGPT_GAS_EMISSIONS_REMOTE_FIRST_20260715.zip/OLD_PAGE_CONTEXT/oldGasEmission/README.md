# oldGasEmission

Bu paket, kullanıcının belirttiği dört dosyayı tek ZIP içinde birleştirir.

- `original_files/`: Kaynak dosyaların değiştirilmemiş kopyaları.
- `expanded/`: İç ZIP arşivlerinin ayrı klasörlere güvenli biçimde açılmış içerikleri.
- `validation/`: SHA-256 manifesti ve bütünlük raporu.
