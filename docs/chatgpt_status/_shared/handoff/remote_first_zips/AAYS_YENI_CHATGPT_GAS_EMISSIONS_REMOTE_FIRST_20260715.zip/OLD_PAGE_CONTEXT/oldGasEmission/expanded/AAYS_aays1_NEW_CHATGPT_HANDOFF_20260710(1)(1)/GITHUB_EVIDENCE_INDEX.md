# GITHUB_EVIDENCE_INDEX

## Runner proof

- `docs/chatgpt_status/aays1/status/134_f_portable_one_click_recovery_test_latest.json` — F portable runner active proof.
- `docs/chatgpt_status/aays1/status/130_f_portable_one_click_recovery_bootstrap_latest.json` — one-click bootstrap proof.
- `docs/chatgpt_status/_shared/heartbeat/stable_runner_daemon_heartbeat_latest.json` — daemon heartbeat proof.
- `docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json` — shared runner bootstrap proof.
- `docs/chatgpt_status/_shared/locks/single_runner.lock` — single runner lock, PID and canonical repo path.

## AAYS1 status / reports

- `docs/chatgpt_status/aays1/status/113_aays1_next_geometry_source_candidate_extraction_latest.json`
- `docs/chatgpt_status/aays1/status/114_aays1_live_source_verification_latest.json`
- `docs/chatgpt_status/aays1/status/115_aays1_source_verified_product_integration_latest.json`
- `docs/chatgpt_status/aays1/status/116_aays1_source_verified_incremental_latest.json`
- `docs/chatgpt_status/aays1/status/117_aays1_source_verified_batch_latest.json`
- `docs/chatgpt_status/aays1/reports/114_aays1_live_source_verification_report.md`
- `docs/chatgpt_status/aays1/reports/115_aays1_source_verified_product_integration_report.md`

## Site / panel data

- `england_map_web/data/aays1/aays1_product_status_latest.json`
- `england_map_web/data/runner_panel/page_status_index.json`
- `england_map_web/data/runner_panel/aays1_visible_positive_progress_latest.json`

## Web-visible CSV / GeoJSON rows

- `england_map_web/data/aays1/aays1_114_source_verified_integrated.csv`
- `england_map_web/data/aays1/aays1_114_source_verified_integrated.geojson`
- `england_map_web/data/aays1/aays1_116_source_verified_incremental_rows.csv`
- `england_map_web/data/aays1/aays1_116_source_verified_incremental_rows.geojson`
- `england_map_web/data/aays1/aays1_117_source_verified_batch_rows.csv`
- `england_map_web/data/aays1/aays1_117_source_verified_batch_rows.geojson`
