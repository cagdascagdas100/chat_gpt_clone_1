# CURRENT_PAGE_CLOSEOUT_PROMPT

Bu mevcut ChatGPT sayfası artık yalnızca handoff doğrulaması için kullanılacak.

Yeni iş yeni ChatGPT sayfasında devam edecek. Yeni sayfaya `AAYS_aays1_NEW_CHATGPT_HANDOFF_20260710.zip` yüklenecek ve `NEW_CHATGPT_PAGE_CONTINUE_PROMPT.md` içeriği ilk mesaj olarak verilecek.

Mevcut sayfanın son doğrulanmış durumu:

```text
Repo: cagdascagdas100/chat_gpt_clone_1
Branch: codex/aays-single-runner-v5-20260706
Page key: aays1
Runner: F portable tek shared runner
Latest task: aays1-117-source-verified-batch-20260710
Panel: %74
Remaining: %26
Next target: %75
Verified rows: 174
CSV rows: 174
GeoJSON features: 174
Accuracy >=3: 174
Final: false
```

Bu sayfada yeni runner açma, yeni paralel akış başlatma veya final_ready=true yazma. Yeni iş yeni sayfada sürecek.
