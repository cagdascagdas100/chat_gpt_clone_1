# AAYS / TerraYield — aays1 Sayfa Devam + Eksik Yapılar Raporu

Tarih: 2026-07-08
PAGE_KEY: aays1
Branch: codex/aays-single-runner-v5-20260706
Beklenen aktif repo: C:\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707
Beklenen başlatıcı: C:\Users\cagda\Documents\GitHub\AAYS\START_AAYS_RUNNER.bat
Beklenen shared runner: RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707

## 1. Kullanıcının asıl istediği çalışma modeli

Kullanıcı sadece "devam et" yazdığında bu sayfada başta verilen AAYS/TerraYield planı ilerlemeli.

Bu şu anlama gelir:
- ChatGPT sadece runner sağlık kontrolü yapmamalı.
- Her "devam et" turunda önce PAGE_KEY=aays1 altındaki queue/status/reports/heartbeat/runner_outputs kontrol edilmeli.
- Pending/queued task varsa yeni runner açılmamalı; mevcut tek shared stable runner'ın işlemesi beklenmeli.
- Valid pending task yoksa, baştaki planı ilerletecek yeni valid task aays1 queue altına yazılmalı.
- Site/panelde gözlenebilir çıktı dosyaları üretilmeli.
- Final/product tamamlandı iddiası ancak gerçek GitHub kanıtıyla yapılmalı; aksi halde final_ready=false kalmalı.

## 2. Bu sayfanın başta verilen planı

Bu sayfada temel plan/iş:
- terrayield-046-runner-sync-recovery-then-accuracy-expansion
- runner/Git sync recovery
- preflight checks
- runner stuck detector + watchdog kontrolü
- endpoint health probe
- project red-flag quickscan
- 044 kapsamlı paralel doğruluk artırma child başlatma

Başlangıç kalite/sağlık hedefleri:
- Kaynak Doğruluk Skoru: 45/100
- Parsel Eşleşme Doğruluk Skoru: 27/100
- Operasyonel Sağlık Skoru: 0/100
- Genel Güven Skoru: 32/100
- Teknik runner ilerleme: %99
- Geniş doğruluk artırma programı: %35

## 3. Şu an GitHub'da görünen runner durumu

GitHub latest status dosyalarına göre:
- runner_status: runner_active
- runner_engine: stable_legacy_worktree_runner_20260707
- scan_runner: RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707
- runner_exit_code: 0
- controller_sync_ok: true

Ama pickup/output tarafı hâlâ sağlıklı kanıt göstermiyor:
- repo_root hâlâ C:\AAYS_WT\AAYS_RUNNER_CLEAN_20260707 görünüyor, beklenen C:\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707 değil.
- queue_started=false
- runner_output_uploaded=false
- PUSH_SYNC_OK=false
- processed=[]
- skipped=[]
- blockers=[]

Bu nedenle "runner tamamen sağlıklı şekilde gerçek işi aldı, işledi ve site çıktılarını pushladı" denemez.

## 4. ChatGPT'nin bu sayfada yaptığı son gerçek ekleme

aays1 için yeni valid queued task yazıldı:
- docs/chatgpt_status/aays1/queue/aays1-visible-program-sync-20260708.task.json

Bu task'ın hedefi:
- baştaki AAYS/TerraYield devam planını aays1 altında site-visible status/report/heartbeat/runner_outputs çıktısına dönüştürmek
- final_ready=false bırakmak
- DB/migration/prod deploy yapmamak

aays1 için runner script yazıldı:
- docs/chatgpt_status/aays1/automation/aays1_visible_program_sync_20260708.ps1

Script sadece şu path'lere yazacak şekilde sınırlandırıldı:
- docs/chatgpt_status/aays1/status/
- docs/chatgpt_status/aays1/reports/
- docs/chatgpt_status/aays1/heartbeat/
- docs/chatgpt_status/aays1/runner_outputs/

## 5. Şu an ana blocker

HEALTHY_RUNNER_PICKUP_OUTPUT_MISSING

Açıklama:
- aays1 queued task repo'da var.
- Script repo'da var.
- Fakat shared runner latest GitHub status hâlâ bu task'ı processed içinde göstermiyor.
- MULTI_PAGE_latest_status hâlâ queue_started=false ve runner_output_uploaded=false.
- Beklenen HEALTHY repo root latest status'a yansımamış.

## 6. Eksik olan zorunlu yapılar

### 6.1 Runner pickup kanıtı eksik

Eksik kanıt:
- MULTI_PAGE_latest_status.json içinde yeni run_id
- queue_started=true
- processed içinde aays1-visible-program-sync-20260708
- runner_output_uploaded=true
- PUSH_SYNC_OK=true

### 6.2 aays1 site-visible output kanıtı eksik

Eksik beklenen dosyalar:
- docs/chatgpt_status/aays1/status/aays1_site_visible_current_status_latest.json
- docs/chatgpt_status/aays1/reports/aays1_visible_program_sync_20260708.md
- docs/chatgpt_status/aays1/heartbeat/aays1_visible_program_sync_heartbeat_latest.txt
- docs/chatgpt_status/aays1/runner_outputs/aays1_visible_program_sync_20260708_runner_output.txt

### 6.3 Runner repo root uyumsuzluğu

Beklenen:
- C:\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707

GitHub latest hâlâ gösteriyor:
- C:\AAYS_WT\AAYS_RUNNER_CLEAN_20260707

Bu, START_AAYS_RUNNER.bat veya daemon/latest status'ın hâlâ eski clone'a bağlı olabileceğini gösterir.

### 6.4 Site/panel okuma sözleşmesi eksik veya doğrulanmamış

Kullanıcının sitede görebilmesi için site/panel şu dosyalardan en az birini okumalı:
- docs/chatgpt_status/_shared/panel/page_status_index_latest.json
- docs/chatgpt_status/aays1/status/aays1_site_visible_current_status_latest.json
- docs/chatgpt_status/aays1/reports/aays1_visible_program_sync_20260708.md

Eğer site bu path'leri okumuyorsa, runner çalışsa bile kullanıcı arayüzünde değişiklik görünmeyebilir.

### 6.5 046/044 gerçek doğruluk artırma çıktıları eksik

Bunlar ayrı olarak ispatlanmalı:
- 046 recovery status/report
- 044 child accuracy expansion output
- endpoint health probe output
- red-flag quickscan output
- doğruluk skoru değişim raporu
- site/panelde hangi skorların güncellendiği

Şu an sadece aays1 visible sync task kuyruğa yazıldı; 046/044 final çıktıları hâlâ GitHub kanıtıyla tamamlanmış görünmüyor.

## 7. Codex'in yapması gereken net düzeltme

Codex şu sırayla ilerlemeli:

1. START_AAYS_RUNNER.bat dosyasının gerçekten şu repo'ya yöneldiğini doğrula:
   C:\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707

2. Eski repo lock/daemon etkisi var mı kontrol et:
   C:\AAYS_WT\AAYS_RUNNER_CLEAN_20260707

3. Yeni runner açma. Var olan shared runner sözleşmesini kullan:
   RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707

4. aays1 queued task'ı pickup ettir:
   docs/chatgpt_status/aays1/queue/aays1-visible-program-sync-20260708.task.json

5. Runner çalışınca şu kanıtları GitHub'a pushla:
   - docs/chatgpt_status/_shared/status/MULTI_PAGE_latest_status.json
   - docs/chatgpt_status/_shared/status/stable_runner_daemon_latest.json
   - docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json
   - docs/chatgpt_status/_shared/reports/MULTI_PAGE_runner_output_<new_run_id>.json
   - docs/chatgpt_status/aays1/status/aays1_site_visible_current_status_latest.json
   - docs/chatgpt_status/aays1/reports/aays1_visible_program_sync_20260708.md
   - docs/chatgpt_status/aays1/heartbeat/aays1_visible_program_sync_heartbeat_latest.txt
   - docs/chatgpt_status/aays1/runner_outputs/aays1_visible_program_sync_20260708_runner_output.txt

6. Eğer runner task'ı almıyorsa, queue selection debug üret:
   - docs/chatgpt_status/_shared/status/queue_selection_debug_20260708.json
   - neden aays1-visible-program-sync-20260708 seçilmedi açıkça yazılsın.

7. Eğer JSON parse hatası veya bozuk queue varsa:
   - tüm runner fatal düşmesin
   - invalid queue olarak skip/debug raporuna yazılsın
   - sağlam queued task işlenmeye devam etsin

8. Eğer rebase/push sorunu varsa:
   - reset/clean yapmadan git status, conflict path, current branch, last commit ve push error çıktısını raporla.

## 8. "Devam et" komutunda ChatGPT'nin bundan sonra yapması gerekenler

Her "devam et" turunda:

1. PAGE_KEY=aays1 kabul et.
2. Şunları oku:
   - docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json
   - docs/chatgpt_status/_shared/status/stable_runner_daemon_latest.json
   - docs/chatgpt_status/_shared/status/MULTI_PAGE_latest_status.json
   - docs/chatgpt_status/aays1/queue/
   - docs/chatgpt_status/aays1/status/
   - docs/chatgpt_status/aays1/reports/
   - docs/chatgpt_status/aays1/heartbeat/
   - docs/chatgpt_status/aays1/runner_outputs/
3. Eğer queued task hâlâ işlenmediyse:
   - yeni runner açma
   - blocker=HEALTHY_RUNNER_PICKUP_OUTPUT_MISSING yaz
4. Eğer task işlendiyse:
   - status/report/heartbeat/runner_output dosyalarını kontrol et
   - site-visible değişiklikleri raporla
   - final_ready=false bırak
5. Eğer valid task yoksa:
   - baştaki planın eksik alt işine göre yeni valid aays1 task yaz
   - sahte completed yazma

## 9. Kabul kriteri

Bu sayfa için gerçek ilerleme ancak şu olduğunda kabul edilir:

- queue_started=true
- processed içinde aays1-visible-program-sync-20260708 veya 046/044 alt task'ı
- runner_output_uploaded=true
- PUSH_SYNC_OK=true
- aays1 status/report/heartbeat/runner_outputs dosyaları GitHub'da görünür
- site/panel bu dosyaları okuyup kullanıcıya gösterir
- final_ready=false kalır
- fake_data=false
- db_write=false
- migration=false
- production_deploy=false

## 10. Son durum

completed=false
final_ready=false
product_final_ready=false
fake_data=false
db_write=false
migration=false
production_deploy=false

Ana blocker:
HEALTHY_RUNNER_PICKUP_OUTPUT_MISSING

İkincil blocker:
RUNNER_REPO_ROOT_STILL_POINTS_TO_OLD_CLEAN_WORKTREE

Üçüncül blocker:
SITE_PANEL_OUTPUT_MAPPING_NOT_VERIFIED
