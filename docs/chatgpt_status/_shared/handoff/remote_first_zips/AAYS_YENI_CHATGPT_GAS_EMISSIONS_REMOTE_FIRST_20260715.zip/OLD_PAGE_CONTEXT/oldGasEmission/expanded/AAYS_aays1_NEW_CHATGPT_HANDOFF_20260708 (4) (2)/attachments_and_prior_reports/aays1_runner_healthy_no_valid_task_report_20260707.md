# AAYS / TerraYield - aays1 Runner Durum Raporu

Tarih: 2026-07-07
PAGE_KEY: aays1
Branch: codex/aays-single-runner-v5-20260706
Beklenen runner: RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707

## Kısa teşhis

Sorun artık "runner çalışmıyor" değil.

GitHub kanıtına göre stable runner çalışıyor:
- repo_root: C:\AAYS_WT\AAYS_RUNNER_CLEAN_20260707
- runner_status: runner_active
- runner_engine: stable_legacy_worktree_runner_20260707
- scan_runner: RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707
- runner_exit_code: 0
- controller_sync_ok: true
- CONTINUE_RUNNER_READY: true

Asıl sorun:
- aays1 için valid pending task yok.
- MULTI_PAGE_latest_status içinde queue_seen=true ama queue_started=false.
- processed boş.
- skipped boş.
- blockers boş.
- runner_output_uploaded=false.
- Yani runner ayakta, queue'yu görüyor, ama başlatacak geçerli task bulmuyor.

## Kanıt dosyaları

1. docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json
   - updated_at: 2026-07-07T18:25:07.3644030Z
   - repo_root: C:\AAYS_WT\AAYS_RUNNER_CLEAN_20260707
   - runner_status: runner_active
   - scan_runner: RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707
   - CONTINUE_RUNNER_READY: true
   - final_ready: false
   - product_final_ready: false
   - fake_data: false
   - db_write: false
   - migration: false
   - production_deploy: false

2. docs/chatgpt_status/_shared/status/stable_runner_daemon_latest.json
   - checked_at: 2026-07-07T18:25:07.3604160Z
   - status: runner_loop_completed
   - scan_runner: RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707
   - runner_exit_code: 0
   - CONTINUE_RUNNER_READY: true
   - controller_sync_ok: true
   - controller_sync_mode: restore_runtime_then_fetch_rebase_controller
   - final_ready: false
   - fake_data: false
   - db_write: false
   - migration: false
   - production_deploy: false

3. docs/chatgpt_status/_shared/status/MULTI_PAGE_latest_status.json
   - run_id: 20260707_212504
   - checked_at: 2026-07-07T18:25:04Z
   - repo_root: C:\AAYS_WT\AAYS_RUNNER_CLEAN_20260707
   - queue_seen: true
   - queue_started: false
   - single_runner_lock_acquired: true
   - processed: []
   - skipped: []
   - blockers: []
   - controller_sync_ok: true
   - final_ready: false

## aays1 task durumu

Mevcut eski aays1 queue işleri valid başlatılabilir iş değil:

1. normalized_065_progress_report_20260706.json
   - status: blocked
   - blockers:
     - BLOCKED_WORKTREE_DIRTY_EXISTING_OUTPUTS
     - runner_status_reports_controller_dirty_sync_skipped
   - final_ready: false
   - fake_data: false
   - db_write: false
   - migration: false
   - production_deploy: false

2. normalized_080_restore_75_rel_20260706.json
   - status: blocked
   - blocker: BLOCKED_080_REPAIR_SOURCE_CSV_MISSING
   - skip_reason: obsolete_duplicate_fail_closed_task_script_always_blocks_until_real_source_csv_exists
   - runner_action: removed_from_pending_queue_without_marking_completed
   - final_ready: false
   - fake_data: false
   - db_write: false
   - migration: false
   - production_deploy: false

## Codex için net yapılacak iş

Codex runner'ı yeniden icat etmemeli. Runner sağlıklı görünüyor.

Codex'in yapması gereken:
1. aays1 için gerçek iş tanımı varsa valid yeni task dosyası oluşturmak.
2. Dosya yeri:
   docs/chatgpt_status/aays1/queue/<yeni_task>.task.json
3. Task içinde mutlaka:
   - page_key: aays1
   - status: queued
   - target_branch: codex/aays-single-runner-v5-20260706
   - script_path: docs/chatgpt_status/aays1/automation/<script>.ps1
   - allowed_paths: ["docs/chatgpt_status/aays1/"]
   - new_runner_allowed: false
   - single_shared_runner_required: true
   - final_ready: false
   - fake_data: false
   - db_write: false
   - migration: false
   - production_deploy: false
4. Task gereksiz veya obsolete ise completed yapılmamalı; status=blocked veya skipped_obsolete yazılmalı.
5. Yeni task yoksa runner beklemede kalır; bu runner arızası değildir.

## Kabul kriteri

Runner'ın gerçek işe başladığını söylemek için GitHub'da şunlar görülmeli:
- MULTI_PAGE_latest_status checked_at yeni timestamp
- queue_seen=true
- queue_started=true
- processed içinde aays1 task_id
- task output/status/report aays1 allowed paths altında
- final_ready=false kalmalı

## Sonuç

status=RUNNER_HEALTHY_NO_VALID_AAYS1_TASK
runner_health=healthy
page_key=aays1
completed=false
final_ready=false
product_final_ready=false
blocker=VALID_AAYS1_TASK_MISSING
