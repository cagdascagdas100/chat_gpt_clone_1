# TerraYield AAYS - Gas Emissions ChatGPT Runner Prompt

Bu paketi TerraYield AAYS Gas Emissions katmani icin kullan. Kullanici ChatGPT sayfasinda sadece "devam" dediginde, tek runner ve GitHub repo dosyalari uzerinden kaldigin yerden ilerle.

## Katman

- Layer name: Gas Emissions
- Program output: Gas Emission Level
- Control site: `http://127.0.0.1:8020/TerraYield_England_Program_Parcel_Layer_Matrix_20260629.html?refresh=20260630-final`
- Main app: `http://127.0.0.1:8010/england_map_web/`
- Site-visible update JSON: `outputs/england_program_parcel_matrix_20260629/gas_emissions_updates/latest_changes.json`
- Current task: `docs/chatgpt_status/gas_emissions/current_task/gas_emissions_current_task_20260703.json`
- Runner bridge: `docs/chatgpt_status/gas_emissions/automation/gas_emissions_single_runner_bridge_20260703.ps1`
- Fillable CSV: `docs/chatgpt_status/gas_emissions/fixtures/gas_emissions_verified_rows_template_20260703.csv`
- Schema: `docs/chatgpt_status/gas_emissions/schemas/gas_emissions_site_update_schema_20260703.json`

## Source Of Truth

Gas Emissions tamamlandi sayilmaz, eger sadece `air.png` ikonu, buton toggle, frontend binding veya asset HTTP 200 dogrulandiysa. Final kabul icin kullanici haritada katmani acabilmeli, parseller yuzdeye gore renklenmeli, legend gorunmeli, parsele tiklayinca popup veya sag panel zorunlu alanlari gostermelidir.

## Zorunlu Alanlar

Her dogrulanmis satir su alanlari doldurmalidir:

- parcel_id
- parcel_ref
- emission_percent
- gas_emission_level
- risk_color
- confidence_percent
- source
- source_url
- source_date
- matching_method
- calculation_explanation
- accuracy_score_4
- needs_manual_review
- changed_in_latest_run

## Varsayilan Skala

- 0-20%: Very Low, green
- 21-40%: Low, light green
- 41-60%: Medium, yellow
- 61-80%: High, orange
- 81-100%: Very High, red
- No data: gray or transparent

## Dogruluk Skoru

- 0/4: Veri yok veya sadece ikon/toggle var.
- 1/4: Yerel veri alani var ama kaynak/evidence belirsiz.
- 2/4: Parsel eslesmesi ve UI baglantisi var ama resmi kaynak zayif.
- 3/4: Resmi veya guvenilir kaynak + parcel match + UI popup/panel kaniti var.
- 3.5/4: Resmi kaynak + AI kontrolu uyumlu, celiski yok.
- 4/4: Resmi kaynak + AI kontrolu + browser smoke + runner raporu + site-visible JSON tamam.

## Tek Runner Akisi

1. Yeni runner baslatmadan once status/heartbeat dosyalarini oku.
2. `current_task/gas_emissions_current_task_20260703.json` dosyasini oku.
3. `england_map_web/data/parcel_emissions_scores.geojson` ve `parcel_air_quality_scores.geojson` alanlarini kontrol et.
4. Resmi veya guvenilir kaynak kaniti bulmadan `final_ready=true` yazma.
5. Dogrulanmis satirlari `fixtures/gas_emissions_verified_rows_template_20260703.csv` icine yaz.
6. Runner bridge komutunu repo root'ta calistir:

```powershell
$env:AAYS_REPO_ROOT="C:\Users\cagda\Documents\GitHub\AAYS"
powershell -NoProfile -ExecutionPolicy Bypass -File docs\chatgpt_status\gas_emissions\automation\gas_emissions_single_runner_bridge_20260703.ps1
```

7. Sonuclari su dosyalardan kontrol et:

- `outputs/england_program_parcel_matrix_20260629/gas_emissions_updates/latest_changes.json`
- `docs/chatgpt_status/gas_emissions/reports/gas_emissions_progress_latest_20260703.md`
- `docs/chatgpt_status/gas_emissions/status/gas_emissions_current_status_20260703.txt`

8. Kullanici 8020 kontrol sitesinde Gas Emissions - Guncel Degisiklikler panelinden sonucu gorebilmeli.

## Final Kabul Kurali

`final_ready=true` sadece su kosullarda yaz:

- air.png tiklayinca Gas Emissions aciliyor.
- Tekrar tiklayinca kapaniyor.
- Buton aktifken aktif gorunuyor.
- Parseller emission_percent ile yesilden kirmiziya tematik boyaniyor.
- Legend gorunuyor.
- Parsele tiklayinca popup veya sag panelde emission_percent, level, risk_color, confidence, source, source_date, matching_method ve calculation_explanation gorunuyor.
- `latest_changes.json` 8020 kontrol sitesinde guncel sonucu gosteriyor.
- Kaynak/evidence ve AI kontrolu raporda yaziyor.

Eksik varsa `final_ready=false`, `manual_review_required=true/false`, `blockers=` ve `next_action=` alanlarini net yaz.
