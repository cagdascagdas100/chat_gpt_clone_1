# FILE_MANIFEST

## Generated handoff docs

- `NEW_CHATGPT_PAGE_CONTINUE_PROMPT.md`
- `CURRENT_PAGE_WORK_SUMMARY.md`
- `GITHUB_EVIDENCE_INDEX.md`
- `RUNNER_HEALTH_AND_RECOVERY_GUIDE.md`
- `NEXT_ACTION_PLAN.md`
- `SAFETY_CONTRACT.md`
- `FILE_MANIFEST.md`
- `CURRENT_PAGE_CLOSEOUT_PROMPT.md`
- `HANDOFF_INDEX.json`
- `MISSING_FILES.md`

## Snapshot copies

- `snapshots/github/134_f_portable_one_click_recovery_test_latest.json`
- `snapshots/github/130_f_portable_one_click_recovery_bootstrap_latest.json`
- `snapshots/github/stable_runner_daemon_heartbeat_latest.json`
- `snapshots/github/runner_bootstrap_latest.json`
- `snapshots/github/single_runner.lock.json`
- `snapshots/github/117_aays1_source_verified_batch_latest.json`
- `snapshots/site_data/aays1_product_status_latest.json`
- `snapshots/site_data/page_status_index_aays1_extract.json`
- `snapshots/site_data/aays1_117_source_verified_batch_rows.csv`
- `snapshots/site_data/aays1_117_source_verified_batch_rows.geojson`

## Uploaded local context copied when available

See `uploaded_context/`.
