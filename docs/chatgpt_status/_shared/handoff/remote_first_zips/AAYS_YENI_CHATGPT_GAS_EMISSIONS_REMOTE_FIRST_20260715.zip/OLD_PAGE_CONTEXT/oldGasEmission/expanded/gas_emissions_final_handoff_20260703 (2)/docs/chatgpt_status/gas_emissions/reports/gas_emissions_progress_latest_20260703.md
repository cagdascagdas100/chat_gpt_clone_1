# Gas Emissions Progress Latest

updated_at=2026-07-03T00:00:00Z
layer=Gas Emissions
program_output=Gas Emission Level
runner_status=waiting_for_chatgpt_continue
final_ready=false
verification_score_before=0/4
verification_score_after=0/4
site_visible_json=outputs/england_program_parcel_matrix_20260629/gas_emissions_updates/latest_changes.json
control_site=http://127.0.0.1:8020/TerraYield_England_Program_Parcel_Layer_Matrix_20260629.html?refresh=20260630-final

## Handoff Files

- current_task: docs/chatgpt_status/gas_emissions/current_task/gas_emissions_current_task_20260703.json
- prompt: docs/chatgpt_status/gas_emissions/chatgpt_prompt/GAS_EMISSIONS_CHATGPT_FINAL_PROMPT_20260703.md
- schema: docs/chatgpt_status/gas_emissions/schemas/gas_emissions_site_update_schema_20260703.json
- fillable_csv: docs/chatgpt_status/gas_emissions/fixtures/gas_emissions_verified_rows_template_20260703.csv
- runner_bridge: docs/chatgpt_status/gas_emissions/automation/gas_emissions_single_runner_bridge_20260703.ps1

## Next Action

ChatGPT must replace template CSV rows with verified source-backed Gas Emissions parcel rows, run the single runner bridge, and check the 8020 control site.
