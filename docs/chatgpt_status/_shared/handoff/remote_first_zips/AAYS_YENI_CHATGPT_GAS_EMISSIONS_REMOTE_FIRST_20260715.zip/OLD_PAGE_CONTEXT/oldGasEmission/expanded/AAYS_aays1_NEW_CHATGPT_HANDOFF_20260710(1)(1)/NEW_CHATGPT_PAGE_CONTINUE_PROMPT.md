# AAYS / aays1 — Yeni ChatGPT Sayfası Devam Promptu

Bu ZIP paketini oku ve **sadece AAYS / aays1** işine devam et.

## Sabit proje bilgileri

```text
REPO_FULL_NAME=cagdascagdas100/chat_gpt_clone_1
BRANCH=codex/aays-single-runner-v5-20260706
PAGE_KEY=aays1
CANONICAL_RUNNER_LAUNCHER=F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd
CANONICAL_RUNNER_REPO=F:\TerraYield_AAYS_Portable\runner_system\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707
CANONICAL_PORTABLE_ROOT=F:\TerraYield_AAYS_Portable
```

## Kesin kurallar

- Yeni runner açma.
- Paralel runner isteme.
- C:\ canonical kabul etme.
- F portable tek shared runner kullanılacak.
- Sahte completed yazma.
- Sahte %100 yazma.
- Sahte `final_ready=true` yazma.
- `final_ready=false`, `product_final_ready=false`, `fake_data=false`, `db_write=false`, `migration=false`, `production_deploy=false` kalacak.
- Gerçek GitHub proof/output olmadan metrik artırma.
- Web/site görünür çıktılar gerçek dosyalara yazılsın.
- Geometri kanıtı yoksa `geometry:null` kullan; geometri uydurma.
- Cevapları kısa ver.

## İlk yapılacak kontrol

Önce GitHub’dan şu proof dosyalarını oku:

```text
docs/chatgpt_status/aays1/status/134_f_portable_one_click_recovery_test_latest.json
docs/chatgpt_status/aays1/status/130_f_portable_one_click_recovery_bootstrap_latest.json
docs/chatgpt_status/_shared/heartbeat/stable_runner_daemon_heartbeat_latest.json
docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json
docs/chatgpt_status/_shared/locks/single_runner.lock
```

Runner sağlıklı kabul şartı:

```text
runner_active=true
pid_alive=true
lock_valid=true
git_push_status=pushed
final_ready=false
fake_data=false
db_write=false
migration=false
production_deploy=false
```

Runner sağlıklı değilse sadece şunu söyle:

```text
F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd dosyasına çift tıkla, sonra bu sayfaya devam yaz.
```

## Son doğrulanmış durum

```text
page_key=aays1
latest_task_id=aays1-117-source-verified-batch-20260710
runner_status=AAYS1_117_BATCH_SOURCE_ROWS_PANEL_74
completion_percent=74
remaining_percent=26
next_target_completion_percent=75
next_target_remaining_percent=25
verified_rows=174
verified_csv_rows=174
verified_geojson_features=174
accuracy_ge_3_count=174
total_source_backed_rows_integrated_from_114=24
final_ready=false
```

Son blocker:

```text
need_1_more_source_backed_row_for_target_75
browser_smoke_and_popup_right_panel_proof_required_before_final_ready
canonical_geometry_boundary_evidence_required_for_non_null_geometry_on_batch_rows
```

## Kaldığın yerden devam

Kullanıcı `devam` dediğinde:

1. Proof dosyalarını tekrar kontrol et.
2. Panel/status dosyalarını oku:
   - `england_map_web/data/runner_panel/page_status_index.json`
   - `england_map_web/data/aays1/aays1_product_status_latest.json`
   - `docs/chatgpt_status/aays1/status/117_aays1_source_verified_batch_latest.json`
3. Mevcut durum %74 ise hedef %75 için **en az 1 yeni gerçek source-backed row** üret.
4. İnternetten doğrulanmış kaynak kullan. Kaynak yoksa yüzde artırma.
5. Yeni satırı CSV/GeoJSON/site/status/panel dosyalarına yaz.
6. Geometri kanıtı yoksa GeoJSON `geometry:null` olsun.
7. Final false kalacak.

## Kısa cevap formatı

Sıkıntı yoksa sadece şu formatta cevap ver:

```text
İşlem yolunda. Sıkıntı yok.

Yeni eklenen satır: N
Toplam source-backed satır: N
Toplam verified row: N
CSV/GeoJSON: N
Accuracy ≥3: N
Panel: %X → %Y
Artış: +%Z
Kalan: %K
Sıradaki hedef: %H
Hedefe kalan: N source-backed row
Bekleme: 10–20 dk
Final: false
```

Sıkıntı varsa sadece sıkıntıyı ve çözüm adımını söyle.
