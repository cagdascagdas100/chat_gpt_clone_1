# AAYS / TerraYield — Codex Şartlı %100 Tamamlama Raporu

Tarih: 2026-07-08  
PAGE_KEY: aays1  
Ana görev: terrayield-046-runner-sync-recovery-then-accuracy-expansion  
Branch: codex/aays-single-runner-v5-20260706  
Beklenen aktif repo: C:\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707  
Başlatıcı: C:\Users\cagda\Documents\GitHub\AAYS\START_AAYS_RUNNER.bat  
Tek shared runner: RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707  

## 0. Amaç

Bu rapor Codex için şartlı yürütme talimatıdır.

Hedef: Kullanıcı sadece `devam et` dediğinde bu sayfadaki aays1 / TerraYield AAYS işi gerçek GitHub kanıtlarıyla ilerlemeli, sitede/panelde görünür olmalı ve sahte tamamlandı yazılmadan gerçek kabul kriterlerine göre %100’e taşınmalıdır.

Codex bu raporu uygularken:
- yeni runner açmayacak,
- yeni V5 runner başlatmayacak,
- paralel runner açmayacak,
- fake completed yazmayacak,
- fake %100 yazmayacak,
- fake final_ready=true yazmayacak,
- final_ready=false kalacak; yalnızca gerçek product kabul kanıtı ayrı raporlanacak,
- fake_data=false,
- db_write=false,
- migration=false,
- production_deploy=false,
- allowed_paths dışına çıkmayacak,
- GitHub output/runner kanıtı olmadan ilerleme metriği artırmayacak.

## 1. Bu sayfanın kimliği

Bu sayfa için PAGE_KEY kesin olarak:

```text
aays1
```

Bu sayfadaki ana iş:

```text
terrayield-046-runner-sync-recovery-then-accuracy-expansion
```

Başta hedeflenen program:
1. runner/Git sync recovery,
2. preflight checks,
3. runner stuck detector + watchdog kontrolü,
4. endpoint health probe,
5. project red-flag quickscan,
6. 044 kapsamlı doğruluk artırma child görevi başlatma,
7. bu işlemlerin site/panelde gözlenebilir status/report çıktısına dönüşmesi.

Başlangıç skorları / izleme hedefleri:
- Kaynak Doğruluk Skoru: 45/100
- Parsel Eşleşme Doğruluk Skoru: 27/100
- Operasyonel Sağlık Skoru: 0/100
- Genel Güven Skoru: 32/100
- Teknik runner ilerleme: %99
- Geniş doğruluk artırma programı: %35

Bu skorlar yalnızca gerçek evidence ile artırılabilir.

## 2. Mevcut bilinen durum

GitHub’da son kontrolde runner process aktif görünüyordu ama gerçek pickup/output kanıtı eksikti.

Görülen eski durum:
- runner_status=runner_active
- runner_exit_code=0
- controller_sync_ok=true
- fakat repo_root hâlâ C:\AAYS_WT\AAYS_RUNNER_CLEAN_20260707 görünüyor
- beklenen repo_root C:\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707 olmalı
- queue_started=false
- runner_output_uploaded=false
- PUSH_SYNC_OK=false
- processed=[]
- aays1 task pickup kanıtı yok

Bu yüzden mevcut ana blocker:

```text
HEALTHY_RUNNER_PICKUP_OUTPUT_MISSING
RUNNER_REPO_ROOT_STILL_POINTS_TO_OLD_CLEAN_WORKTREE
SITE_PANEL_OUTPUT_MAPPING_NOT_VERIFIED
```

## 3. ChatGPT tarafından repo’ya eklenen son gerçek task

Şu iki dosya branch’e yazıldı ve Codex tarafından esas alınmalıdır:

```text
docs/chatgpt_status/aays1/queue/aays1-visible-program-sync-20260708.task.json
docs/chatgpt_status/aays1/automation/aays1_visible_program_sync_20260708.ps1
```

Bu task’ın amacı:
- bu sayfanın planını site/panelde gözlenebilir hale getirmek,
- aays1 altında status/report/heartbeat/runner_outputs üretmek,
- final_ready=false bırakmak,
- DB/migration/prod deploy yapmamak.

Bu task kesinlikle completed sayılmayacak; runner pickup edip output pushlamadan sadece queued kabul edilecek.

## 4. Codex için şartlı yürütme akışı

### Şart A — Runner eski repo’ya bağlıysa

Eğer latest status dosyalarında hâlâ şu görünüyorsa:

```text
repo_root=C:\AAYS_WT\AAYS_RUNNER_CLEAN_20260707
```

ve beklenen şu ise:

```text
repo_root=C:\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707
```

Codex yapacak:
1. `START_AAYS_RUNNER.bat` içeriğini kontrol edecek.
2. Başlatıcının gerçekten `C:\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707` repo’sunu hedeflediğini doğrulayacak.
3. Eski daemon/lock dosyası varsa sahte aktiflik üretmeden raporlayacak.
4. Gerekirse stale lock’u kanıtla kapatacak; yeni runner açmayacak, aynı shared stable runner sözleşmesini sürdürecek.
5. `runner_bootstrap_latest.json`, `stable_runner_daemon_latest.json`, `MULTI_PAGE_latest_status.json` yeni repo root ile GitHub’a pushlanmadan bu şart tamamlanmış sayılmayacak.

Beklenen kanıt:

```text
repo_root=C:\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707
runner_engine=stable_legacy_worktree_runner_20260707
scan_runner=RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707
CONTINUE_RUNNER_READY=true
```

### Şart B — Queue task pickup olmuyorsa

Eğer `MULTI_PAGE_latest_status.json` içinde hâlâ:

```text
queue_started=false
processed=[]
```

görülüyorsa Codex yapacak:
1. aays1 queued task dosyasını okuyacak:
   `docs/chatgpt_status/aays1/queue/aays1-visible-program-sync-20260708.task.json`
2. Queue selection mekanizmasının bu task’ı neden almadığını debug edecek.
3. Aşağıdaki debug dosyalarını üretecek:
   - `docs/chatgpt_status/_shared/status/queue_selection_debug_20260708.json`
   - `docs/chatgpt_status/_shared/status/queue_skip_status_check_20260708.json`
4. Eğer bozuk JSON queue dosyası varsa tüm runner fatal düşmeyecek; invalid queue olarak skip/debug’e yazılacak.
5. Sağlam queued task işlenmeye devam edecek.

Beklenen kanıt:

```text
queue_seen=true
queue_started=true
processed includes aays1-visible-program-sync-20260708
```

### Şart C — Runner output upload olmuyorsa

Eğer:

```text
runner_output_uploaded=false
PUSH_SYNC_OK=false
```

görülüyorsa Codex yapacak:
1. latest runner output dosyasını bulacak:
   `docs/chatgpt_status/_shared/reports/MULTI_PAGE_runner_output_<run_id>.json`
2. Bu dosya localde varsa GitHub’a commit/push edecek.
3. Localde yoksa runner’ın neden report üretmediğini `runner_output_missing_debug_20260708.json` ile raporlayacak.
4. Push/rebase conflict varsa reset/clean yapmadan conflict path, status, branch ve hata çıktısını raporlayacak.

Beklenen kanıt:

```text
runner_output_uploaded=true
PUSH_SYNC_OK=true
docs/chatgpt_status/_shared/reports/MULTI_PAGE_runner_output_<new_run_id>.json exists in GitHub
```

### Şart D — aays1 site-visible output yoksa

Eğer şu dosyalar GitHub’da yoksa Codex task’ı tamamlanmış saymayacak:

```text
docs/chatgpt_status/aays1/status/aays1_site_visible_current_status_latest.json
docs/chatgpt_status/aays1/reports/aays1_visible_program_sync_20260708.md
docs/chatgpt_status/aays1/heartbeat/aays1_visible_program_sync_heartbeat_latest.txt
docs/chatgpt_status/aays1/runner_outputs/aays1_visible_program_sync_20260708_runner_output.txt
```

Codex yapacak:
1. `aays1_visible_program_sync_20260708.ps1` script’ini stable runner üzerinden çalıştıracak.
2. Outputları yalnızca `docs/chatgpt_status/aays1/` altında üretecek.
3. Bu dosyaları GitHub’a pushlayacak.
4. Site/panel bu dosyaları okuyorsa görünürlük doğrulanacak; okumuyorsa panel mapping eksik raporlanacak.

Beklenen kanıt:

```text
aays1 status/report/heartbeat/runner_outputs exist in GitHub
final_ready=false
fake_data=false
db_write=false
migration=false
production_deploy=false
```

### Şart E — Site/panel değişiklikleri görünmüyorsa

Eğer runner output GitHub’da var ama kullanıcı sitede göremiyorsa Codex yapacak:
1. Sitenin/panelin hangi status path’lerini okuduğunu bulacak.
2. Aşağıdaki dosyalardan hangisinin siteye bağlı olduğunu doğrulayacak:
   - `docs/chatgpt_status/_shared/panel/page_status_index_latest.json`
   - `docs/chatgpt_status/aays1/status/aays1_site_visible_current_status_latest.json`
   - `docs/chatgpt_status/aays1/reports/aays1_visible_program_sync_20260708.md`
3. Eğer panel index güncellenmiyorsa aays1 kaydını panel index’e ekleyecek.
4. Site tarafı build/static data cache kullanıyorsa ilgili data file’ı güncelleyecek.
5. Kullanıcının gözlemleyebileceği minimum alanları gösterecek:
   - page_key=aays1
   - task_id
   - runner status
   - last_checked_at
   - queue_started
   - processed task
   - final_ready=false
   - blocker varsa blocker

Beklenen kanıt:

```text
site/panel aays1 latest status path'i okuyor
aays1 latest status kullanıcı arayüzünde gözlenebilir
```

### Şart F — 046/044 asıl program ilerlemiyorsa

aays1 visible sync yalnızca görünürlük başlangıç task’ıdır. Asıl 046/044 işinin ilerlemesi için Codex ayrıca şu taskları üretmeli veya mevcutları pickup ettirmeli:

1. 046 runner sync recovery status/report
2. preflight checks
3. stuck detector/watchdog report
4. endpoint health probe report
5. project red-flag quickscan report
6. 044 child accuracy expansion kickoff/report
7. doğruluk skoru değişim raporu
8. site-visible score/status update

Beklenen output path’leri:

```text
docs/chatgpt_status/aays1/status/046_recovery_latest.json
docs/chatgpt_status/aays1/reports/046_recovery_report.md
docs/chatgpt_status/aays1/status/preflight_latest.json
docs/chatgpt_status/aays1/reports/preflight_report.md
docs/chatgpt_status/aays1/status/watchdog_latest.json
docs/chatgpt_status/aays1/reports/watchdog_report.md
docs/chatgpt_status/aays1/status/endpoint_health_latest.json
docs/chatgpt_status/aays1/reports/endpoint_health_report.md
docs/chatgpt_status/aays1/status/red_flag_quickscan_latest.json
docs/chatgpt_status/aays1/reports/red_flag_quickscan_report.md
docs/chatgpt_status/aays1/status/044_accuracy_expansion_latest.json
docs/chatgpt_status/aays1/reports/044_accuracy_expansion_report.md
docs/chatgpt_status/aays1/status/score_progress_latest.json
```

Bu outputlar olmadan 046/044 planı %100 sayılmayacak.

## 5. %100 tamamlandı sayma şartları

Codex ancak şu şartların tamamı GitHub’da kanıtlandığında %100 raporlayabilir:

### Runner kabul kriterleri

```text
runner_status=runner_active
repo_root=C:\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707
scan_runner=RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707
runner_exit_code=0
controller_sync_ok=true
queue_seen=true
queue_started=true
runner_output_uploaded=true
PUSH_SYNC_OK=true
processed includes aays1-visible-program-sync-20260708 or later aays1 task
```

### aays1 output kabul kriterleri

```text
docs/chatgpt_status/aays1/status/aays1_site_visible_current_status_latest.json exists
docs/chatgpt_status/aays1/reports/aays1_visible_program_sync_20260708.md exists
docs/chatgpt_status/aays1/heartbeat/aays1_visible_program_sync_heartbeat_latest.txt exists
docs/chatgpt_status/aays1/runner_outputs/aays1_visible_program_sync_20260708_runner_output.txt exists
```

### 046/044 program kabul kriterleri

```text
046 recovery report exists
preflight report exists
watchdog/stuck detector report exists
endpoint health probe report exists
red-flag quickscan report exists
044 accuracy expansion kickoff/report exists
score progress latest status exists
site-visible status is updated
```

### Güvenlik kabul kriterleri

```text
fake_data=false
db_write=false
migration=false
production_deploy=false
final_ready=false
product_final_ready=false
```

Not: `final_ready=false` kalması bu aşamada hata değildir. Bu görev runner/site-visible ilerleme ve 046/044 program execution görevidir; product final ayrı kanıt ister.

## 6. Codex'in üretmesi gereken final rapor formatı

Codex işlem sonunda şu formatta rapor üretmeli:

```text
PAGE_KEY=aays1
TASK=terrayield-046-runner-sync-recovery-then-accuracy-expansion
STATUS=<RUNNER_HEALTHY_AND_TASK_PROCESSED | BLOCKED>
completion_percent=<kanıtlı yüzde>
runner_repo_root=<path>
queue_started=<true/false>
runner_output_uploaded=<true/false>
PUSH_SYNC_OK=<true/false>
processed_tasks=<list>
site_visible_outputs=<list>
046_outputs=<list>
044_outputs=<list>
final_ready=false
fake_data=false
db_write=false
migration=false
production_deploy=false
blockers=<none veya gerçek blocker listesi>
```

## 7. Eğer herhangi bir şart sağlanmazsa

Codex şu şekilde fail-closed davranacak:
- completed yazmayacak,
- %100 yazmayacak,
- final_ready=true yazmayacak,
- hangi şartın eksik olduğunu blocker olarak yazacak,
- mümkünse debug dosyasını GitHub’a pushlayacak.

Olası blocker isimleri:
```text
RUNNER_REPO_ROOT_STILL_POINTS_TO_OLD_CLEAN_WORKTREE
HEALTHY_RUNNER_PICKUP_OUTPUT_MISSING
QUEUE_SELECTION_SKIPPED_AAYS1_TASK
INVALID_QUEUE_JSON_CAUSED_FATAL
RUNNER_OUTPUT_NOT_UPLOADED
PUSH_SYNC_FAILED
SITE_PANEL_OUTPUT_MAPPING_NOT_VERIFIED
AAYS1_SITE_VISIBLE_OUTPUTS_MISSING
046_RECOVERY_OUTPUTS_MISSING
044_ACCURACY_EXPANSION_OUTPUTS_MISSING
SCORE_PROGRESS_OUTPUT_MISSING
```

## 8. Codex için nihai talimat

Bu raporu uygula ve aays1 sayfasında kullanıcının sadece `devam et` diyerek baştaki planı izleyebilmesini sağla.

Öncelik sırası:
1. Runner latest status’ı HEALTHY repo root’a bağla.
2. aays1 queued task’ı pickup ettir.
3. runner output upload ve push sync’i kanıtla.
4. aays1 site-visible status/report/heartbeat/runner_outputs üret.
5. site/panel mapping’i doğrula.
6. 046/044 asıl program outputlarını üret.
7. Her şeyi GitHub’da kanıtla.
8. final_ready=false bırak; sahte final yazma.
