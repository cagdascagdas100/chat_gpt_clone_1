# SAFETY_CONTRACT

```json
{
  "no_new_runner": true,
  "no_parallel_runner": true,
  "canonical_storage": "F_PORTABLE_ROOT",
  "final_ready": false,
  "product_final_ready": false,
  "fake_data": false,
  "db_write": false,
  "migration": false,
  "production_deploy": false,
  "no_fake_completed": true,
  "no_fake_100_percent": true,
  "metric_increase_requires_real_github_output": true,
  "geometry_policy": "geometry_null_until_canonical_boundary_evidence"
}
```
