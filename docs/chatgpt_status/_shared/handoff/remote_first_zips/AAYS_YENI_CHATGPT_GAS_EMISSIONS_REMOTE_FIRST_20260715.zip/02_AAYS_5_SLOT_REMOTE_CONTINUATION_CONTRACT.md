# AAYS 5 Slot Remote Continuation Contract

- WORKSTREAM_ID: `AAYS_5_SLOT_SAFE_PARALLEL_V1`
- Bir ChatGPT sayfası tam olarak bir `SLOT_ID`'ye aittir.
- ChatGPT sayfaları runner değildir.
- Gerçek paralel iş yalnız mevcut coordinator altındaki child slotlarda yürür.
- Coordinator yoksa yeni runner/coordinator oluşturulmaz; mevcut single-shared-runner fallback kullanılır.
- Her yeni sayfa remote checkpoint'ten yeniden kurulur.
- Eski sohbet geçmişi ve ZIP snapshot yüzdeleri authoritative değildir.
- Aynı task queued, claimed, running veya terminal ise duplicate oluşturulmaz.
- Terminal task replay edilmez; stale heartbeat aktif sayılmaz.
- Remote branch HEAD authoritative kaynaktır.
- `01_CURRENT_RESULT_REPORT.md` yalnız tarihsel completed scope ve replay yasağını taşır.
- Bütün safety flags false kalır.
