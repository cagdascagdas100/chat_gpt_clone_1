# Dogruluk Skalasi - 4 Uzerinden

## Etiketler

```text
0.00 - 0.99 = No Evidence / Unknown
1.00 - 1.99 = Low Accuracy
2.00 - 2.99 = Medium Accuracy
3.00 - 3.49 = High Accuracy
3.50 - 4.00 = Very High Accuracy
```

## Kaynak katkisi

Temel katkilar:

```text
official_document_or_registry = +1.50
official_address_or_planning_source = +1.25
verified_web_source = +0.75
map_poi_or_building_label = +0.50
photo_ai_visual_confirmation = +0.50
parcel_geometry_match_high = +0.50
source_recency_good = +0.25
multiple_independent_sources = +0.25
```

Sinirlar:

```text
only_ai_photo_max = 2.25
only_web_or_map_max = 2.75
official_plus_location_max = 3.00
official_plus_ai_or_web_max = 3.50
multiple_official_plus_ai_max = 4.00
conflict_max = 2.75
unknown_max = 0.99
```

## Cakisma cezasi

```text
ai_source_conflict = -0.75
source_conflict = -1.00
weak_geometry_match = -0.50
stale_source_date = -0.25
```

Skor her zaman `0 <= accuracy_score_4 <= 4` olacak.
