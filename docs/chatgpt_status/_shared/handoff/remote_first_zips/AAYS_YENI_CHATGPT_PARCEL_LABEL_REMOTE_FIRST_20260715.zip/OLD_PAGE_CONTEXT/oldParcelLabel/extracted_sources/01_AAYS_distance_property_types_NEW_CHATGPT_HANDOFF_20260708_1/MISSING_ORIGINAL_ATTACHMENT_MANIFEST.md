# Original Attachment Manifest

This handoff ZIP includes all files currently visible in /mnt/data at handoff creation time under original_uploads/.

Visible uploads copied:
- distance_property_types_page_completed_20260703.zip
- distance_property_types_chatgpt_handoff_20260703.zip
- distance_property_types_applied_20260703.zip
- 00_CHATGPT_PROMPT_TR.md
- AAYS_CHATGPT_COMMON_DEVAM_PROMPT_20260706.md
- AAYS_CHATGPT_SAYFALARI_DEVAM_PROMPT.md
- Yapıştırılan metin.txt
- Yeni proje yapısı.txt
- image.png

Caveat:
I cannot guarantee these are every file ever attached in earlier/maxed pages; I can only copy attachments present in this current runtime. If an original project ZIP existed only in an older page and is not present here, it is not accessible from this page.
