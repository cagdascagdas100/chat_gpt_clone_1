# SAFETY_CONTRACT

Bu projede aşağıdaki güvenlik sözleşmesi zorunludur:

```json
{
  "single_runner_only": true,
  "new_runner": false,
  "parallel_runner": false,
  "canonical_root": "F:\\TerraYield_AAYS_Portable",
  "c_drive_canonical": false,
  "final_ready": false,
  "product_final_ready": false,
  "fake_data": false,
  "db_write": false,
  "migration": false,
  "production_deploy": false,
  "no_fake_completed": true,
  "no_fake_percent_100": true,
  "no_fake_geometry": true
}
```

## Uygulama notları

- Gerçek GitHub output/proof yoksa metrik artırma.
- Completed/report dosyası yoksa task tamamlandı deme.
- Geometri kanıtı yoksa `geometry:null` kullan.
- Source URL ve evidence olmadan aday ekleme.
- Final sadece gerçek kabul kriterleri sağlanınca değerlendirilebilir; mevcut handoffta `final_ready=false`.
