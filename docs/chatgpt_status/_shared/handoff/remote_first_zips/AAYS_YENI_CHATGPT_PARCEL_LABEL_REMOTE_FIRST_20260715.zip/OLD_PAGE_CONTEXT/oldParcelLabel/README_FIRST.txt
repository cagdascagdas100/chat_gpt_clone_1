oldParcelLabel.zip

Bu paket kullanıcının belirttiği 5 dosyayı eksiksiz biçimde bir araya getirir.

İçerik:
- original_files/: Dosyaların adları değiştirilmeden saklanan özgün kopyaları
- extracted_sources/: Dört ZIP'in çakışma yaratmayacak ayrı klasörlere açılmış içerikleri
- 00_CHATGPT_PROMPT_TR.md: Tek başına verilen prompt dosyasının kolay erişim kopyası
- integrity/MANIFEST.json: CRC, SHA256, dosya sayısı, nested ZIP kontrolleri
- integrity/SHA256SUMS.txt: Özgün kaynakların SHA256 değerleri

Not:
AAYS_aays1_NEW_CHATGPT_HANDOFF_20260710(4) (1).zip ile
AAYS_aays1_NEW_CHATGPT_HANDOFF_20260710(4)(1).zip birebir aynıdır.
Kullanıcı her ikisini de istediği için iki özgün dosya da korunmuştur.

ZIP içindeki Windows ters-eğik çizgili yollar güvenli klasör yollarına normalize edilmiştir.
Hiçbir kaynak dosya silinmemiş veya üzerine yazılmamıştır.
