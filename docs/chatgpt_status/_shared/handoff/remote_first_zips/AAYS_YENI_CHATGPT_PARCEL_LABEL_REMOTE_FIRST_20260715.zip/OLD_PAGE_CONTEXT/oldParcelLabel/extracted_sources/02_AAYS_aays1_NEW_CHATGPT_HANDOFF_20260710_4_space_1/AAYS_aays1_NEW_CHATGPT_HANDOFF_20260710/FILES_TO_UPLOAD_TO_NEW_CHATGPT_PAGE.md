# FILES_TO_UPLOAD_TO_NEW_CHATGPT_PAGE

Yeni sayfaya yükleme sırası:

1. `AAYS_aays1_NEW_CHATGPT_HANDOFF_20260710.zip` dosyasını yükle.
2. ZIP içindeki `NEW_CHATGPT_PAGE_CONTINUE_PROMPT.md` içeriğini yeni sayfaya yapıştır.
3. Sonra sadece `devam` yaz.
4. Yeni ChatGPT önce GitHub proof dosyalarını okuyacak.
5. F portable tek shared runner dışında runner istemeyecek.
6. Completed/report GitHub’a gelmeden task tamamlandı saymayacak.
