# Site Guncelleme ve Filtre Gereksinimleri

## Katman butonu

Katman acildiginda `Distance to Nearby Property Types` verisi haritada gorunmeli.

Buton aktifken:

- sadece ilgili katman vurgusu aktif olsun,
- parcel tiklaninca popup/sag panel dolsun,
- legend alti yapi turunu gostersin.

## Guncel degisiklikler filtresi

Yeni filtre adi:

```text
Guncel degisiklikler
```

Filtre aktifken sadece su kayitlar gorunsun:

```text
changed_in_latest_run=true
```

Panelde su alanlar gorunsun:

```text
last_updated
change_reason
previous_property_type
new_property_type
previous_accuracy_score_4
new_accuracy_score_4
```

## Popup / sag panel zorunlu alanlari

```text
Parcel ID
Selected Building Type
Color Category
Distance to Nearest Industrial Unit
Distance to Nearest Detached Home
Distance to Nearest Retail Property
Distance to Nearest Apartment Building
Distance to Nearest Office Building
Distance to Nearest Mixed Building
Official Source Evidence
Web Source Evidence
Map Source Evidence
Photo AI Evidence
Photo AI Observation
Source Date
Matching Method
Accuracy Score / Label
Conflict Status
Manual Review
Explanation
```

## Kullaniciya acik ifade

Eger veri yetersizse:

```text
Bu parcel icin yapi turu kaniti 3/4 dogruluk esigine ulasmadi. Manuel inceleme onerilir.
```
