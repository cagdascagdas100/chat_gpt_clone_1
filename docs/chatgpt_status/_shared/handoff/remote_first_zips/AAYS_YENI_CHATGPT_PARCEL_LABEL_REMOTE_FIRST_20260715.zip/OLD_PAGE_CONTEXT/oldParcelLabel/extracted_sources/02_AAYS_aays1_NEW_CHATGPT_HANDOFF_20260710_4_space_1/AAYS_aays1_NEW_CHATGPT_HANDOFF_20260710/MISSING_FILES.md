# MISSING_FILES

Eksik / ulaşılamayanlar:

1. Kullanıcının bahsettiği 5 ayrı eski ChatGPT sayfasının tam export dosyaları bu runtime içinde tam olarak yok.
2. Orijinal proje ana ZIP’i bu sandbox içinde kesin olarak doğrulanamadı.
3. Runner’ın local F diskindeki canlı log dosyaları doğrudan okunamadı; sadece GitHub’a push edilmiş proof dosyaları kullanıldı.
4. `135_aays1_f_portable_github_visibility_recheck_20260709_completed.json` son kontrolde GitHub’da yoktu.
5. `f_portable_one_click_runner_github_report_test_20260709.md` son kontrolde GitHub’da yoktu.

Mevcut snapshotlar:
- `snapshots/site_data/dpt_14.csv`
- `snapshots/site_data/dpt_14.geojson`
- `snapshots/site_data/dpt_14_audit.json`
- `snapshots/site_data/dpt_14_manifest.json`
- `snapshots/site_data/dpt_14_site_status.json`
