# AAYS Distance Property Types — New ChatGPT Handoff Summary

## PAGE_KEY

distance_property_types

## Repo / runner

- Active repo root: C:\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707
- Branch: codex/aays-single-runner-v5-20260706
- Starter: C:\Users\cagda\Documents\GitHub\AAYS\START_AAYS_RUNNER.bat
- Runner: RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707
- New runner: DO NOT OPEN
- Parallel runner: DO NOT OPEN
- Same PAGE_KEY: distance_property_types

## User goal

Build and show the TerraYield AAYS program layer for Distance Property Types on the site/panel, using real evidence only.

## Program output

Distance to Nearby Property Types

## Allowed property types

1. Industrial Unit
2. Detached Home
3. Retail Property
4. Apartment Building
5. Office Building
6. Mixed Building
7. Unknown / Manual Review fallback

Mixed Building definition: ground-floor shop / office / retail plus upper residential mixed-use.

## Required output fields

parcel_id, selected_property_type, selected_color_category, nearest_industrial_unit_distance_m, nearest_detached_home_distance_m, nearest_retail_property_distance_m, nearest_apartment_building_distance_m, nearest_office_building_distance_m, nearest_mixed_building_distance_m, selected_match_distance_m, official_source_evidence, web_source_evidence, map_source_evidence, photo_ai_evidence, photo_ai_image_path, photo_ai_model_or_tool, photo_ai_observation, source_date, matching_method, conflict_status, needs_manual_review, accuracy_score_4, accuracy_label_4, explanation, last_updated, changed_in_latest_run, change_reason.

## Work completed in this page

- Confirmed runner pickup for distance_property_types page task.
- Confirmed page queue `distance_property_types_site_check_20260703_0950.task.json` became `done`, with `runner_completed_at=2026-07-07T20:16:14Z` and `PUSH_SYNC_OK=true`.
- Confirmed runner output existed and initially blocked on missing input file and missing evidence rows.
- Created/confirmed source candidate input schema file: `docs/chatgpt_status/distance_property_types/inputs/distance_property_types_source_candidates.csv`.
- Created recheck queue: `docs/chatgpt_status/distance_property_types/queue/distance_property_types_recheck_after_input_schema_20260708.task.json`.
- Confirmed recheck queue processed as `done`, with `runner_completed_at=2026-07-07T23:15:12Z` and `PUSH_SYNC_OK=true`.
- Confirmed after recheck, blocker reduced to only `missing_real_evidence_rows`; missing input file blocker is gone.
- Created page-local report: `docs/chatgpt_status/distance_property_types/reports/distance_property_types_required_input_and_site_gap_20260708.md` with commit `ac9815ecd5a04068ce7b52e642084df3bebdc3eb`.
- Added source candidate schema file with commit `506b1900cad7981e523bf0b35c5a3c9f57a02f0e`.
- Added recheck queue with commit `9038310d72b06e534d2cd9d25a7e12d1ebe2e6c8`.

## Runner fix evidence supplied by user / Codex

The user reported Codex fixed the wider runner issues:

- `dac75a2`: runner accepts nested `safety_flags` as well as top-level flags.
- `1ec50eb`: aays1 visible sync task processed by runner.
- `b812e60`: dated queue debug files treated as runtime; controller no longer blocks on them.
- Live validation reported by user: Runner PID 18192, runner_exit_code=0, queue_started=true, runner_output_uploaded=true, PUSH_SYNC_OK=true, controller_sync_ok=true, no blocker, no rebase conflict.

## Current GitHub evidence snapshot

Page-level current state:

- queue: `docs/chatgpt_status/distance_property_types/queue/distance_property_types_recheck_after_input_schema_20260708.task.json`
  - status=done
  - runner_completed_at=2026-07-07T23:15:12Z
  - PUSH_SYNC_OK=true
  - final_ready=false
- runner output: `docs/chatgpt_status/distance_property_types/runner_outputs/distance_property_types_site_check_20260703_0950.report.json`
  - status=blocked
  - evidence_rows=0
  - verified_csv_rows=0
  - blockers=[missing_real_evidence_rows]
  - completion_percent=35
  - remaining_percent=65
- progress latest:
  - status=blocked
  - completion_percent=35
  - remaining_percent=65
  - blockers=missing_real_evidence_rows

Shared/global status files are partly stale and still reference older CLEAN repo path. Do not use those stale shared files to reject page-level runner pickup evidence. Page-level queue + runner_outputs are the stronger current evidence.

## Site/panel output status

Existing site output files:

- `england_map_web/data/distance_property_types/distance_property_types_verified.csv`: header only, no data rows.
- `england_map_web/data/distance_property_types/distance_property_types_verified.geojson`: FeatureCollection with `features: []`.
- `england_map_web/data/distance_property_types/distance_property_types_evidence_manifest.json`: bootstrap/contract manifest.

User cannot see real map features yet because there are no real evidence rows and no GeoJSON features.

## Current blocker

missing_real_evidence_rows

Meaning: `distance_property_types_source_candidates.csv` exists but has only schema/header. At least one real evidence-backed source candidate row is required before progress can increase above 35%.

## Remaining work

1. Find or create real evidence-backed source candidate rows for this PAGE_KEY. Do not fabricate data.
2. Each row needs parcel_id or parcel_ref, property type candidate, source evidence or URL, source date, matching method, confidence/accuracy, manual review flag, and geometry or resolvable feature reference.
3. Generate verified CSV and GeoJSON from those rows.
4. Populate evidence manifest and manual review CSV.
5. Update site/panel data files so the layer is visible.
6. Requeue page-local task if no valid pending task exists.
7. Wait for shared runner pickup and GitHub output proof.
8. Keep final_ready=false until all criteria are actually met.

## Safety flags

- final_ready=false
- product_final_ready=false
- fake_data=false
- db_write=false
- migration=false
- production_deploy=false

## Current progress

- Completed: 35%
- Remaining: 65%
- Last turn increase: 0%
- Next wait estimate after new valid queue: 5 minutes

## What to answer when user says “devam et”

Use a short status block:

- Runner durumu: <GitHub-proven status>
- Yapılan işlemler: <1-4 bullets>
- Tamamlanan işlem: <percent>
- Bu tur artış: <percent>
- Kalan işlem: <percent>
- Bekleme: <minutes>
- Final: false
- Blocker: <blocker or none>

Do not write long explanations unless there is a new blocker.
