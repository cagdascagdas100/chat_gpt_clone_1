# Tek Runner Is Akisi

## Page key

```text
distance_property_types
```

## F repo

```text
F:\chatgpt\chat_gpt_clone_1_main
```

## Queue dosyasi

```text
F:\chatgpt\chat_gpt_clone_1_main\docs\chatgpt_status\distance_property_types\queue\<task_id>.task.json
```

## Live runner queue

```text
C:\AAYS_GITHUB_BRIDGE_CLEAN2\ai-queue\pending\<task_id>.task.json
```

## Task JSON ornegi

```json
{
  "task_id": "distance_property_types_batch_001",
  "page_key": "distance_property_types",
  "script_path": "F:\\chatgpt\\chat_gpt_clone_1_main\\docs\\chatgpt_status\\distance_property_types\\automation\\distance_property_types_batch_runner.ps1",
  "result_path": "C:\\AAYS_GITHUB_BRIDGE_CLEAN2\\ai-results\\distance_property_types_batch_001.result.json",
  "repo_result_path": "F:\\chatgpt\\chat_gpt_clone_1_main\\docs\\chatgpt_status\\distance_property_types\\reports\\distance_property_types_batch_001.md",
  "status": "pending",
  "priority": 90,
  "db_write": false,
  "ddl": false,
  "migration": false,
  "production_deploy": false,
  "fake_data": false
}
```

## Devam mantigi

ChatGPT sayfasinda kullanici `devam` dediginde:

1. Son raporu oku.
2. `next_batch` varsa yeni task hazirla.
3. Taski repo queue ve live pending klasorune yaz.
4. Runner sonucunu bekle.
5. Raporu kontrol et.
6. Gerekirse site dosyalarini guncelle.

## Final degilse ne yapilacak?

Eksik kanit varsa:

```text
final_ready=false
remaining_blockers=<liste>
next_single_action=<tek is>
```

Asla sahte `final_ready=true` yazma.
