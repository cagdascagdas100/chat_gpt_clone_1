# NEXT_ACTION_PLAN

## Öncelik 1 — Runner proof / queue pickup

- Proof dosyalarını oku.
- Runner aktif değilse canonical launcher talimatı ver.
- Runner aktif ama `processed_task_count=0` ise final/bulk deme.
- Queue pickup düzelmeden `final_ready=true` yazma.

## Öncelik 2 — Distance Property Types veri devamı

Kaldığın yer:

```text
visible_program_layer_rows=10
source_audit_rows=14
latest_audited_pending_append=4
```

Sonraki küçük batch:

1. Audit edilmiş 4 adayı program layer’a append et:
   - The Gherkin
   - One Park Drive
   - Trafford Centre
   - Magna Park Lutterworth
2. `site_status` sayısını 14’e çıkar.
3. `data_manifest` sayısını 14 visible olarak güncelle.
4. Her feature için:
   - `source_url`
   - `web_source_evidence`
   - `map_source_evidence`
   - `accuracy_score_4`
   - `fake_data=false`
   - `final_ready=false`
   - `needs_manual_review=false`
   alanlarını koru.

## Öncelik 3 — Yeni adaylar

İnternetten 2-4 yeni İngiltere property-type adayı bul:
- Official / primary site tercih et.
- Koordinat kanıtı olmadan geometri uydurma.
- Geometri emin değilse `geometry:null`.
- Accuracy hedefi >=3.0/4.

## Öncelik 4 — Kısa rapor formatı

Kullanıcı sistem kasmasın istiyor. Her tur kısa cevap ver:
- Sıkıntı
- Yapılan ilerleme
- Adaylar
- Doğruluk
- Web görünür satır
- Audit satır
- Yüzde
- Kaç dakika
- Final=false
