# FILE_MANIFEST

## Handoff dokümanları

- `NEW_CHATGPT_PAGE_CONTINUE_PROMPT.md`
- `CURRENT_PAGE_WORK_SUMMARY.md`
- `GITHUB_EVIDENCE_INDEX.md`
- `RUNNER_HEALTH_AND_RECOVERY_GUIDE.md`
- `NEXT_ACTION_PLAN.md`
- `SAFETY_CONTRACT.md`
- `FILE_MANIFEST.md`
- `CURRENT_PAGE_CLOSEOUT_PROMPT.md`
- `HANDOFF_INDEX.json`
- `MISSING_FILES.md`

## Snapshot dizinleri

- `snapshots/github_proofs/`
- `snapshots/site_data/`
- `snapshots/previous_uploads/`

## Önemli GitHub pathleri

- `docs/chatgpt_status/aays1/status/134_f_portable_one_click_recovery_test_latest.json`
- `docs/chatgpt_status/aays1/status/130_f_portable_one_click_recovery_bootstrap_latest.json`
- `docs/chatgpt_status/_shared/heartbeat/stable_runner_daemon_heartbeat_latest.json`
- `docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json`
- `docs/chatgpt_status/_shared/locks/single_runner.lock`
- `england_map_web/data/program_layer_matrix/distance_property_types.geojson`
- `england_map_web/data/distance_property_types/distance_property_types_site_status.json`
- `england_map_web/data/distance_property_types/distance_property_types_source_audit_20260709.json`
- `england_map_web/data/distance_property_types/distance_property_types_data_manifest_20260709.json`
