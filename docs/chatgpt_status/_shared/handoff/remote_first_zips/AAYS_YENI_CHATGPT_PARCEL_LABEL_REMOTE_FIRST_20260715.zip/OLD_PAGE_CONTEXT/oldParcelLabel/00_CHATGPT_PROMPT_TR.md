# CHATGPT PROMPT - AAYS Distance to Nearby Property Types

Bu gorev yalnizca AAYS/TerraYield uygulamasindaki `Distance to Nearby Property Types` katmani icindir.

## Sabit kokler

Aktif GitHub/F repo:

```text
F:\chatgpt\chat_gpt_clone_1_main
```

Yardimci C repo:

```text
C:\Users\cagda\Documents\GitHub\AAYS
```

Runner/bridge:

```text
C:\AAYS_GITHUB_BRIDGE_CLEAN2
```

Uygulama:

```text
http://127.0.0.1:8010/england_map_web/
```

Program matrix kontrol sayfasi:

```text
http://127.0.0.1:8020/TerraYield_England_Program_Parcel_Layer_Matrix_20260629.html?refresh=20260630-final
```

## Katman

Layer name:

```text
Distance to Nearby Property Types
```

Program output alanlari:

```text
Distance to Nearest Industrial Unit
Distance to Nearest Detached Home
Distance to Nearest Retail Property
Distance to Nearest Apartment Building
Distance to Nearest Office Building
Distance to Nearest Mixed Building
```

## Altı yapı turu

Her parcel icin sadece asagidaki alti kategoriden biri ana sonuc olarak secilecek:

1. Industrial Unit
2. Detached Home
3. Retail Property
4. Apartment Building
5. Office Building
6. Mixed Building

Mixed Building tanimi:

```text
Alt katta dukkan/ofis/perakende, ust katta konut gibi karma kullanimli yapilar.
```

## Ana gorev

Her parcel icin eslesen en yakin yapi/birim turunu belirle. Sonuc, kanit ve dogruluk skoruyla birlikte programa yazilabilir halde uretilsin.

Her parcel icin su bilgileri uretilmeli:

- parcel_id
- selected_property_type
- selected_color_category
- nearest_industrial_unit_distance_m
- nearest_detached_home_distance_m
- nearest_retail_property_distance_m
- nearest_apartment_building_distance_m
- nearest_office_building_distance_m
- nearest_mixed_building_distance_m
- selected_match_distance_m
- official_source_evidence
- web_source_evidence
- map_source_evidence
- photo_ai_evidence
- photo_ai_image_path
- photo_ai_model_or_tool
- photo_ai_observation
- source_date
- matching_method
- conflict_status
- needs_manual_review
- accuracy_score_4
- accuracy_label_4
- explanation
- last_updated

## Kanit toplama mantigi

Kanitlar oncelik sirasiyla kullanilsin:

1. Resmi kaynak / belediye / planlama / land registry / resmi adres veya kullanim verisi
2. Guvenilir web sitesi / firma sitesi / ilan / ticari kayit / harita kaydi
3. Harita tabanli analiz / POI / bina etiketi / cadde seviyesi konum eslesmesi
4. Fotograf veya goruntu AI kontrolu
5. Manuel inceleme notu

Fotograf AI kontrolu:

- Ilgili konum veya yapinin fotograflari varsa sisteme kanit olarak kaydedilecek.
- AI, goruntude hangi yapi turunu destekledigini aciklayacak.
- AI sonucu tek basina final 4/4 yapmaz; resmi/web kaynakla desteklenirse skoru artirir.
- Fotograf yoksa `photo_ai_evidence=not_available` yaz.

## Dogruluk hedefi

Hedef dogruluk:

```text
accuracy_score_4 >= 3.0
```

Kaynak katkisi:

- Resmi veya guvenilir belge + konum eslesmesi: en fazla 3.0/4
- Resmi kaynak + web/harita destegi: en fazla 3.25/4
- Resmi kaynak + web/harita + fotograf AI uyumu: en fazla 3.5/4
- Birden fazla resmi kaynak + fotograf AI + net parcel geometry uyumu: 3.75/4 veya 4/4
- AI ile kaynaklar celisirse final skoru dusur ve manuel incelemeye ayir.

## Cakisma kurallari

AI sonucu ile resmi/web kaynak farkliysa:

- `conflict_status=ai_source_conflict`
- `needs_manual_review=true`
- final type kaynak agirlikli secilsin ama aciklamada celiski yazilsin.
- accuracy_score_4 genelde 2.0-2.75 araliginda kalsin.

Kaynaklar birbirleriyle celisirse:

- `conflict_status=source_conflict`
- `needs_manual_review=true`
- resmi ve daha guncel kaynak daha yuksek agirlik alsin.

Kanit yoksa:

- `selected_property_type=Unknown`
- `accuracy_score_4=0`
- `needs_manual_review=true`
- sahte veri uretme.

## Cikti dosyalari

Asagidaki dosyalar uretilsin veya guncellensin:

```text
F:\chatgpt\chat_gpt_clone_1_main\england_map_web\data\distance_property_types\distance_property_types_verified.geojson
F:\chatgpt\chat_gpt_clone_1_main\england_map_web\data\distance_property_types\distance_property_types_verified.csv
F:\chatgpt\chat_gpt_clone_1_main\england_map_web\data\distance_property_types\distance_property_types_evidence_manifest.json
F:\chatgpt\chat_gpt_clone_1_main\docs\chatgpt_status\distance_property_types\reports\distance_property_types_progress_latest.md
F:\chatgpt\chat_gpt_clone_1_main\docs\chatgpt_status\distance_property_types\reports\distance_property_types_manual_review_latest.csv
```

## Site entegrasyonu

Uygulamada katman acildiginda:

- Sadece dogrulanmis veya incelemeye ayrilmis parcel featurelari gorunsun.
- Renkler alti kategoriye gore ayri olsun.
- Parcel tiklaninca popup/sag panelde alanlar gosterilsin:
  - yapi turu
  - renk kategorisi
  - mesafeler
  - kaynaklar
  - fotograf AI kaniti
  - kaynak tarihi
  - matching method
  - accuracy score / label
  - conflict/manual review durumu
  - hesaplama aciklamasi

Ek filtre:

```text
Guncel degisiklikler
```

Bu filtre son islemde degisen parcel kayitlarini gosterir:

- `last_updated >= current_run_started_at`
- `changed_in_latest_run=true`
- `change_reason`

## Runner akisi

Tek shared runner disinda yeni runner acma.

ChatGPT sayfasinda kullanici `devam` dediginde:

1. GitHub/F repo icindeki son raporu oku.
2. Eksik veya bekleyen parcel grubunu belirle.
3. Queue task dosyasini ilgili page-key altina yaz.
4. Tek runner taski alsin.
5. Runner islem sonucunu rapora yazsin.
6. ChatGPT raporu okuyup sonraki batch icin devam etsin.

## Kabul kriteri

Katman ancak su kosullarda tamam sayilir:

- GeoJSON parse ediliyor.
- Her feature parcel_id tasiyor.
- Her feature alti kategori sozlesmesine uyuyor.
- Accuracy score 0-4 araliginda.
- En az 3/4 hedefi icin kanitlar listeleniyor.
- Problemli kayitlar manuel review dosyasina ayriliyor.
- Sitede katman aciliyor.
- Sitede guncel degisiklikler filtresi calisiyor.
- Popup/sag panel kaynak ve AI kanitlarini gosteriyor.

Sahte veri uretilirse gorev basarisiz sayilir.
