# AAYS ChatGPT Sayfalari Ortak Devam Promptu

Bu promptu bes ChatGPT sayfasinin tamaminda ortak kullan. Bundan sonraki mesajlarda sadece `devam et` yaz.

```text
AAYS / TerraYield icin kaldigin yerden devam et.

Aktif repo/branch:
- Repo: C:\AAYS_WT\AAYS_RUNNER_CLEAN_20260707
- Branch: codex/aays-single-runner-v5-20260706
- Ana C proje: C:\Users\cagda\Documents\GitHub\AAYS

Runner karari:
- Yeni V5 runner mantigina donme.
- F: yolunu canonical kabul etme.
- Tek aktif sistem stable legacy worktree runner:
  docs/chatgpt_status/_shared/automation/RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707.ps1
- Tek baslatici:
  C:\Users\cagda\Documents\GitHub\AAYS\START_AAYS_RUNNER.bat
- Bu baslatici repair repo icindeki stable runner + panel launcher'i acar.

Zorunlu kurallar:
- Yeni veya paralel runner baslatma.
- Tek shared runner lock disina cikma.
- Sahte completed, sahte %100, sahte final_ready=true yazma.
- Product final_ready=false kalir; ancak gercek kanit varsa sayfa bazinda ayrica raporla.
- Fake data yok.
- DB write yok.
- Migration yok.
- Production deploy yok.
- allowed_paths disina cikma.
- Queue/status/report/heartbeat veya blocked kaniti olmadan ilerleme iddiasi kurma.
- GitHub push kaniti yoksa metrik artirma.
- Main entegrasyonu yoksa ana urun completed deme.

Mevcut dogrulanmis durum:
- Runner aktif: stable_legacy_worktree_runner_20260707
- scan_runner: RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707
- CONTINUE_RUNNER_READY=true
- Runner loop exit_code=0 oldugu goruldu.
- 2026-07-07 low-memory fetch + stable identity fix GitHub'a push edildi:
  commit eb32cb3 Fix stable runner fetch refspec quoting
- 2026-07-07 fresh GitHub health evidence push edildi:
  commit 5861448 Publish stable runner health evidence
- 2026-07-07 18:25:07Z daemon latest: runner_exit_code=0, blocker bos, controller_sync_ok=true.
- Bu zamandan onceki V5 / RUNNER_ALREADY_ACTIVE / STATUS_FAILED raporlari stale olabilir; son status dosyalarini esas al.
- 080 restore source CSV gorevi obsolete/blocked olarak isaretlendi; bu is tamamlandi veya final_ready sayilmayacak.

Bu sayfa icin PAGE_KEY:
PAGE_KEY=<BURAYA_PAGE_KEY_YAZ>

Devam ederken:
1. Once docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json dosyasini oku.
2. Sonra docs/chatgpt_status/_shared/status/stable_runner_daemon_latest.json dosyasini oku.
3. PAGE_KEY icin docs/chatgpt_status/<PAGE_KEY>/queue, status, reports, heartbeat, runner_outputs dosyalarini oku.
4. Pending/queued task varsa yeni runner acma; tek stable runner'in pickup/status kanitini bekle.
5. ready_count=0 ise runner saglikli ama alinacak valid task yok demektir; yapilacak is varsa once kendi PAGE_KEY altina valid *.task.json queue yaz.
6. Task gereksiz/obsolete ise completed yapma; status=blocked veya skipped_obsolete yaz, final_ready=false birak ve nedenini raporla.
7. Gercek is yapilacaksa queue task formatina ve allowed_paths sozlesmesine uy.
8. Cevabi su kisa formatta ver:

Bekleme: <dakika>
Tamamlanan islem: <% veya kanitli adet>
Kalan islem: <% veya kanitli adet>
Runner durumu: <runner_active / runner_blocked / runner_idle>
Final: false
Blocker: <none veya gercek blocker>

Kullanici sadece "devam et" derse ayni PAGE_KEY ve bu tek stable runner sozlesmesiyle surdur.
```
