# Manuel Inceleme Kurallari

## Manuel incelemeye ayrilacak kayitlar

Asagidaki durumlarda `needs_manual_review=true`:

- accuracy_score_4 < 3.0
- AI sonucu ile resmi/web kaynak farkli
- parcel geometry ile kaynak konumu uyusmuyor
- kaynak tarihi yok veya cok eski
- bina turu iki kategori arasinda belirsiz
- foto kaniti yok ve resmi kaynak da yok
- mixed building ile retail/apartment ayrimi net degil

## Problem raporu kolonlari

```text
parcel_id
candidate_property_type
ai_property_type
official_source_property_type
web_source_property_type
conflict_status
accuracy_score_4
missing_evidence
manual_question
source_links_or_files
photo_ai_image_path
suggested_next_action
```

## Otomatik cozum onceligi

1. Resmi kaynak daha guncelse resmi kaynak sec.
2. Web kaynagi ayni adres/parcel ile eslesiyorsa web kaynagini destek kaniti yap.
3. AI goruntu sonucu resmi kaynakla uyumluysa skoru artir.
4. AI goruntu sonucu resmi kaynakla celisirse skoru dusur ve manuel incele.
5. Mixed Building icin alt kat ticari + ust kat konut kaniti aranir.
