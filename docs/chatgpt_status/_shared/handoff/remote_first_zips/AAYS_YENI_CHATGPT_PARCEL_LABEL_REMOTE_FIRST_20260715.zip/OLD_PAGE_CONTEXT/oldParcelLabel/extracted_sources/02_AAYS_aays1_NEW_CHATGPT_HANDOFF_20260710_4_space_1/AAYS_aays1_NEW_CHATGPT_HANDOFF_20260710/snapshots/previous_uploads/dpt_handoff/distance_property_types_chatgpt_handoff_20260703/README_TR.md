# AAYS / TerraYield - Distance to Nearby Property Types ChatGPT Handoff

Bu paket, `Distance to Nearby Property Types` katmanini ChatGPT sayfasinda ilerletmek icin hazirlandi.

Ana hedef:

- Her parcel icin alti yapi turunden birini kanitli sekilde belirlemek.
- Kanitlari resmi kaynaklar, web kaynaklari, fotograf/goruntu AI kontrolu ve harita analizinden ayirmak.
- Sonucu AAYS/TerraYield uygulamasinda katman, popup, sag panel ve guncel degisiklik filtresiyle gostermek.
- Tek shared runner uzerinden GitHub/F-repo tabanli is akisini korumak.

Dosyalar:

- `00_CHATGPT_PROMPT_TR.md`: ChatGPT sayfasina yapistirilacak ana prompt.
- `01_DATA_CONTRACT_TR.md`: Uretilmesi gereken tablo/GeoJSON/rapor alanlari.
- `02_ACCURACY_SCALE_TR.md`: 4 uzerinden dogruluk ve kaynak katkisi skalasi.
- `03_RUNNER_WORKFLOW_TR.md`: Tek runner, F repo ve rapor okuma/yazma akisi.
- `04_SITE_FILTER_REQUIREMENTS_TR.md`: Sitede guncel degisiklik filtresi ve kullanici gorunumu.
- `05_MANUAL_REVIEW_RULES_TR.md`: AI/kaynak celiskileri ve manuel inceleme kurallari.

Onemli kural:

Sahte veri uretme. Kanit yoksa `needs_manual_review=true` ve `accuracy_score_4 < 3.0` yaz.
