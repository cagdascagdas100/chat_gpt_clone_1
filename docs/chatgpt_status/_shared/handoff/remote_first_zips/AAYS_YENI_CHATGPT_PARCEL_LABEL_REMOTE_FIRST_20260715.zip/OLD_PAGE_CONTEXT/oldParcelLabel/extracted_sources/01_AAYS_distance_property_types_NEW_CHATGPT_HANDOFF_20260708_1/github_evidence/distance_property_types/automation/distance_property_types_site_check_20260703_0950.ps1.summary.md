# distance_property_types_site_check_20260703_0950.ps1 summary

TaskId: distance_property_types_site_check_20260703_0950
PageKey: distance_property_types

Checks:
- input: docs/chatgpt_status/distance_property_types/inputs/distance_property_types_source_candidates.csv
- verified_csv: england_map_web/data/distance_property_types/distance_property_types_verified.csv
- verified_geojson: england_map_web/data/distance_property_types/distance_property_types_verified.geojson
- evidence_manifest: england_map_web/data/distance_property_types/distance_property_types_evidence_manifest.json
- manual_review_csv: docs/chatgpt_status/distance_property_types/reports/distance_property_types_manual_review_latest.csv

Logic:
- Count data rows in input and verified CSV.
- Block if evidence rows <= 0.
- Completion 35 when evidence_rows <= 0.
- Completion 70 when evidence exists but outputs incomplete.
- Completion 90 when site check passed and waiting final review.
- Always final_ready=false, product_final_ready=false, fake_data=false, db_write=false, ddl=false, migration=false, production_deploy=false.

Full source was present in GitHub path:
docs/chatgpt_status/distance_property_types/automation/distance_property_types_site_check_20260703_0950.ps1
