# Yeni ChatGPT Sayfası Devam Promptu — AAYS Distance Property Types

Bu ZIP’i oku ve aynı PAGE_KEY ile kaldığımız yerden devam et.

## Sabit bilgiler

PAGE_KEY=distance_property_types
Repo=C:\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707
Branch=codex/aays-single-runner-v5-20260706
Başlatıcı=C:\Users\cagda\Documents\GitHub\AAYS\START_AAYS_RUNNER.bat
Runner=RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707

## Kesin kurallar

- Yeni runner açma.
- Paralel runner açma.
- Aynı stable shared runner kullan.
- Aynı PAGE_KEY altında devam et.
- GitHub kanıtı olmadan yüzde artırma.
- Sahte completed yazma.
- Sahte %100 yazma.
- final_ready=true yazma.
- final_ready=false bırak.
- fake_data=false.
- db_write=false.
- migration=false.
- production_deploy=false.
- Sahte parcel_id, sahte property type, sahte source, sahte URL, sahte geometry, sahte distance üretme.

## İlk yapılacak kontroller

Önce ZIP içindeki HANDOFF_SUMMARY.md dosyasını oku.
Sonra GitHub’dan şu dosyaları kontrol et:

1. docs/chatgpt_status/distance_property_types/queue/
2. docs/chatgpt_status/distance_property_types/status/
3. docs/chatgpt_status/distance_property_types/reports/
4. docs/chatgpt_status/distance_property_types/heartbeat/
5. docs/chatgpt_status/distance_property_types/runner_outputs/
6. docs/chatgpt_status/distance_property_types/automation/
7. docs/chatgpt_status/distance_property_types/inputs/distance_property_types_source_candidates.csv
8. england_map_web/data/distance_property_types/distance_property_types_verified.csv
9. england_map_web/data/distance_property_types/distance_property_types_verified.geojson
10. england_map_web/data/distance_property_types/distance_property_types_evidence_manifest.json

## Current known state from previous page

- `distance_property_types_source_candidates.csv` exists but only header/schema exists.
- Recheck queue `distance_property_types_recheck_after_input_schema_20260708.task.json` was processed and done.
- Latest runner output is blocked with `missing_real_evidence_rows`.
- Completion is 35%, remaining 65%, final_ready=false.

## Next real task

Find or create real evidence-backed source candidate rows for Distance Property Types.
Each accepted row must include at least:

- parcel_id or parcel_ref
- geometry_wkt or existing feature reference
- candidate_property_type
- source evidence text or source_url
- source_date
- matching_method
- accuracy_score_4
- needs_manual_review

Allowed property types:

- Industrial Unit
- Detached Home
- Retail Property
- Apartment Building
- Office Building
- Mixed Building
- Unknown

If evidence is weak/conflicting, keep needs_manual_review=true. If there is no real evidence, do not create a data row and do not increase progress.

## Queue behavior

If there is a pending/queued valid task under this PAGE_KEY, wait for runner pickup and GitHub proof.
If no valid pending task exists and work is needed, write a new queue task under:

docs/chatgpt_status/distance_property_types/queue/

The task must include top-level safety flags:

- no_fake_final_ready=true
- no_db_write=true
- no_migration=true
- no_production_deploy=true
- final_ready=false
- product_final_ready=false
- fake_data=false
- db_write=false
- migration=false
- production_deploy=false

## User interaction

When the user writes only “devam et”, continue from this state without asking repeated questions.
Keep the answer short:

- Runner durumu
- Yapılan işlemler
- Tamamlanan işlem yüzdesi
- Bu tur artış yüzdesi
- Kalan işlem yüzdesi
- Kaç dakika beklemeli
- Final=false
- Blocker varsa adı

## Do not claim completion

Do not say completed, final, or 100% unless real GitHub evidence proves all acceptance criteria.
