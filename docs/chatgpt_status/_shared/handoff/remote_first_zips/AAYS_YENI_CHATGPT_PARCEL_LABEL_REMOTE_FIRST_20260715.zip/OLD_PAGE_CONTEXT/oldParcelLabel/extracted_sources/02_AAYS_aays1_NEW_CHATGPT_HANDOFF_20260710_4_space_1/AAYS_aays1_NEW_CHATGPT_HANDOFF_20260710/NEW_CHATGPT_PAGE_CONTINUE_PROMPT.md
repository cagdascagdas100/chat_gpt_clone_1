# AAYS / TerraYield — Yeni ChatGPT Sayfası Devam Promptu

Bu ZIP paketini oku ve bu sayfadaki işi aynı yerden devral.

## Repo / Branch

```text
REPO=cagdascagdas100/chat_gpt_clone_1
BRANCH=codex/aays-single-runner-v5-20260706
PROJECT=AAYS / TerraYield
PAGE_KEY=aays1
ACTIVE_LAYER=Distance to Nearby Property Types
LAYER_KEY=distance_property_types
```

## Canonical runner ve repo

```text
CANONICAL_RUNNER=F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd
CANONICAL_REPO=F:\TerraYield_AAYS_Portable\runner_system\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707
CANONICAL_WORKROOT=F:\TerraYield_AAYS_Portable\runner_system\AAYS_WT\AAYS_STABLE_RUNNER_WORKTREES
```

## Kesin kurallar

- Yeni runner açma.
- Paralel runner isteme.
- C:\ canonical kabul etme.
- F portable tek shared runner kullanılacak.
- Sahte completed yazma.
- Sahte %100 yazma.
- Sahte `final_ready=true` yazma.
- `final_ready=false` kalacak.
- `fake_data=false`, `db_write=false`, `migration=false`, `production_deploy=false` kalacak.
- Gerçek GitHub proof/output olmadan metrik artırma.
- Geometri kanıtı yoksa `geometry:null` kullan; geometri uydurma.
- Web/site görünür çıktılar gerçek repo dosyalarına yazılacak.
- Cevapları kısa ver.

## İlk yapılacak GitHub proof kontrolü

Önce şu dosyaları GitHub’dan oku:

```text
docs/chatgpt_status/aays1/status/134_f_portable_one_click_recovery_test_latest.json
docs/chatgpt_status/aays1/status/130_f_portable_one_click_recovery_bootstrap_latest.json
docs/chatgpt_status/_shared/heartbeat/stable_runner_daemon_heartbeat_latest.json
docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json
docs/chatgpt_status/_shared/locks/single_runner.lock
```

Sağlıklı kabul şartı:

```text
runner_active=true
pid_alive=true
lock_valid=true
git_push_status=pushed
final_ready=false
fake_data=false
db_write=false
migration=false
production_deploy=false
```

Not: Son doğrulamada proof dosyaları runner açık gösterdi; ancak `processed_task_count=0` olduğu için queue pickup tam sağlıklı kabul edilmedi. Completed/report dosyası oluşmadan görev tamamlandı sayma.

Runner aktif değilse veya proof okunamıyorsa sadece şunu söyle:

```text
F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd dosyasına çift tıkla, sonra bu sayfaya devam yaz.
```

## Mevcut Distance Property Types durumu

Web’de görünür program layer dosyası:

```text
england_map_web/data/program_layer_matrix/distance_property_types.geojson
```

Son doğrulanmış durum:

```text
visible_program_layer_rows=10
source_audit_rows=14
accuracy_target_4>=3.0
passed_accuracy_target_rows=14
final_ready=false
fake_data=false
```

Görünür 10 satır:

| # | Feature | Type | Accuracy |
|---|---|---|---|
| 1 | Westfield London | Retail Property | 3.0/4 |
| 2 | The News Building | Office Building | 3.0/4 |
| 3 | The Shard | Mixed Building | 3.0/4 |
| 4 | One Hyde Park | Apartment Building | 3.0/4 |
| 5 | Witanhurst | Detached Home | 3.0/4 |
| 6 | LSIP / SEGRO Dagenham | Industrial Unit | 3.0/4 |
| 7 | 22 Bishopsgate | Office Building | 3.25/4 |
| 8 | Battersea Power Station | Mixed Building | 3.25/4 |
| 9 | Bluewater | Retail Property | 3.1/4 |
| 10 | One The Elephant | Apartment Building | 3.1/4 |

Audit edilmiş, web layer’a append bekleyen 4 aday:

| # | Feature | Type | Accuracy |
|---|---|---|---|
| 11 | The Gherkin | Office Building | 3.25/4 |
| 12 | One Park Drive | Apartment Building | 3.15/4 |
| 13 | Trafford Centre | Retail Property | 3.15/4 |
| 14 | Magna Park Lutterworth | Industrial Unit | 3.05/4 |

## Yeni sayfada devam akışı

Kullanıcı `devam` yazınca:

1. GitHub proof dosyalarını oku.
2. Runner aktif ve proof sağlıklı mı kontrol et.
3. Queue pickup hâlâ sağlıksızsa final/bulk yapma.
4. `distance_property_types` katmanında kaldığı yerden ilerle.
5. İnternetten birkaç gerçek aday daha bul.
6. Her aday için şu alanları üret:
   - `parcel_id`
   - `selected_property_type`
   - `selected_color_category`
   - `source_url`
   - `official_source_evidence`
   - `web_source_evidence`
   - `map_source_evidence`
   - `matching_method`
   - `accuracy_score_4`
   - `needs_manual_review`
   - `fake_data=false`
   - `final_ready=false`
7. Görünür site çıktısı gerekiyorsa:
   - `england_map_web/data/program_layer_matrix/distance_property_types.geojson`
   - `england_map_web/data/distance_property_types/distance_property_types_site_status.json`
   - `england_map_web/data/distance_property_types/distance_property_types_source_audit_20260709.json`
   - `england_map_web/data/distance_property_types/distance_property_types_data_manifest_20260709.json`
   dosyalarını güncelle.
8. Gerçek GitHub output/proof yoksa yüzde artırma.

## Kısa cevap formatı

Sıkıntı varsa en başta söyle. Sıkıntı yoksa sadece kısa özet ver:

```text
Yapılan ilerleme:
- ...

Adaylar:
- ...

Doğruluk:
- ...

Web görünür satır:
Audit satır:
Bu işlemle artan yüzde:
Genel işlem yüzdesi:
Kalan işlem yüzdesi:
Kaç dakika beklemeliyim:
Final: false
```
