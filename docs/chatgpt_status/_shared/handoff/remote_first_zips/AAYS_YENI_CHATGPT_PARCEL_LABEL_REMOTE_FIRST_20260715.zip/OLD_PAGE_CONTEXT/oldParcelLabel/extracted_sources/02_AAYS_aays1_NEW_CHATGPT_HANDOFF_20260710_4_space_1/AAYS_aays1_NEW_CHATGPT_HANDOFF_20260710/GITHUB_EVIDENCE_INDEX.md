# GITHUB_EVIDENCE_INDEX

## Runner proof dosyaları

| Path | Son gözlenen durum |
|---|---|
| `docs/chatgpt_status/aays1/status/134_f_portable_one_click_recovery_test_latest.json` | runner_active=true, pid_alive=true, lock_valid=true, processed_task_count=0 |
| `docs/chatgpt_status/aays1/status/130_f_portable_one_click_recovery_bootstrap_latest.json` | runner_active=true, pid_alive=true, lock_valid=true, processed_task_count=0 |
| `docs/chatgpt_status/_shared/heartbeat/stable_runner_daemon_heartbeat_latest.json` | runner_active=true, pid_alive=true, lock_valid=true, processed_task_count=0 |
| `docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json` | runner_active=true, pid_alive=true, lock_valid=true, processed_task_count=0 |
| `docs/chatgpt_status/_shared/locks/single_runner.lock` | pid=10108, repo_root=F portable, final_ready=false |

## Site/data dosyaları

| Path | Kullanım |
|---|---|
| `england_map_web/data/program_layer_matrix/distance_property_types.geojson` | Web’de görünen program layer; son doğrulamada 10 feature |
| `england_map_web/data/distance_property_types/distance_property_types_site_status.json` | Site status; 10 visible feature |
| `england_map_web/data/distance_property_types/distance_property_types_source_audit_20260709.json` | Audit status; 14 audited source row |
| `england_map_web/data/distance_property_types/distance_property_types_data_manifest_20260709.json` | Manifest; 10 visible + 14 audit |
| `england_map_web/data/distance_property_types/distance_property_types_verified.csv` | Eski verified CSV; bazı snapshotlarda 14 satırlık aday seti yerel olarak mevcut |
| `england_map_web/data/distance_property_types/distance_property_types_verified.geojson` | Eski verified GeoJSON / pilot data |

## Queue/status/report dosyaları

| Path | Durum |
|---|---|
| `docs/chatgpt_status/aays1/queue/135_aays1_f_portable_github_visibility_recheck_20260709.task.json` | queued_for_single_shared_runner olarak oluşturuldu |
| `docs/chatgpt_status/aays1/status/135_aays1_f_portable_github_visibility_recheck_20260709_completed.json` | son kontrolde yoktu |
| `docs/chatgpt_status/aays1/reports/f_portable_one_click_runner_github_report_test_20260709.md` | son kontrolde yoktu |

## Önemli commit/patch bilgisi

- Bootstrap/launcher alias patch’i GitHub’a yazıldı:
  - `docs/chatgpt_status/aays1/automation/130_f_portable_one_click_recovery_bootstrap_20260709.ps1`
  - Ama local F diskinde script’in çalıştırılması gerekebilir.
