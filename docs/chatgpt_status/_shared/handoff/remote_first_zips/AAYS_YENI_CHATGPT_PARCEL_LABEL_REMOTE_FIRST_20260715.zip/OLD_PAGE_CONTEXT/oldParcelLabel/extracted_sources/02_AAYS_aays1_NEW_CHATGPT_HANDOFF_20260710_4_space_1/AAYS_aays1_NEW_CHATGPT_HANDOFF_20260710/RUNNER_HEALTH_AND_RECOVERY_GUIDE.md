# RUNNER_HEALTH_AND_RECOVERY_GUIDE

## Canonical değerler

```text
RUNNER=F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd
REPO=F:\TerraYield_AAYS_Portable\runner_system\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707
WORKROOT=F:\TerraYield_AAYS_Portable\runner_system\AAYS_WT\AAYS_STABLE_RUNNER_WORKTREES
BRANCH=codex/aays-single-runner-v5-20260706
```

## Kontrol sırası

1. GitHub proof dosyalarını oku.
2. `runner_active`, `pid_alive`, `lock_valid`, `git_push_status` alanlarını doğrula.
3. `processed_task_count` değerini kontrol et.
4. Queue task için completed/report dosyası GitHub’a gelmiş mi kontrol et.
5. Completed/report yoksa queue pickup sağlıklı sayma.

## Runner aktif değilse kullanıcıya sadece bunu söyle

```text
F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd dosyasına çift tıkla, sonra bu sayfaya devam yaz.
```

## Bilinen problem

Runner proof dosyaları aktiflik gösterebiliyor fakat `processed_task_count=0` kalabiliyor. Bu durumda:
- Runner process açık olabilir.
- GitHub proof push edebilir.
- Ancak queue içindeki yeni task’ları işlemeyebilir.
- Completed/report dosyası yoksa işlem tamamlandı sayılmayacak.

## Local recovery komutu

Kullanıcı kabul ederse PowerShell’de:

```powershell
cd /d F:\TerraYield_AAYS_Portable\runner_system\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707
git pull --ff-only origin codex/aays-single-runner-v5-20260706
powershell -NoProfile -ExecutionPolicy Bypass -File "docs\chatgpt_status\aays1\automation\130_f_portable_one_click_recovery_bootstrap_20260709.ps1"
cmd /c "F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd"
```
