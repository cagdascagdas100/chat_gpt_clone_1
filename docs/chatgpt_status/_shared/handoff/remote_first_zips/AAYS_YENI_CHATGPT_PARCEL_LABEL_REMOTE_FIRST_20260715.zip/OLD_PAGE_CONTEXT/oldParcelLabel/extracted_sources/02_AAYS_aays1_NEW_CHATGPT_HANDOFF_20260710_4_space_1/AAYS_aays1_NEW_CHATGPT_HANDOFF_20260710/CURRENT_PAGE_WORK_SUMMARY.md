# CURRENT_PAGE_WORK_SUMMARY

## Kapsam

Bu handoff, mevcut ağırlaşan ChatGPT sayfasındaki AAYS / TerraYield işini yeni ChatGPT sayfasına devretmek için hazırlandı.

```text
Repo: cagdascagdas100/chat_gpt_clone_1
Branch: codex/aays-single-runner-v5-20260706
Page key: aays1
Layer key: distance_property_types
Layer: Distance to Nearby Property Types
Canonical runner: F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd
Canonical repo: F:\TerraYield_AAYS_Portable\runner_system\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707
```

## Bu sayfada yapılan başlıca işler

1. F portable tek shared runner proof dosyaları defalarca kontrol edildi.
2. Runner process proof olarak aktif görünse de queue pickup’ın tam sağlıklı olmadığı belirlendi.
3. Distance Property Types için web/site görünür 6 pilot satır 10 satıra yükseltildi.
4. Audit tarafında 14 gerçek kaynaklı aday doğrulandı.
5. Tüm satırlarda `fake_data=false`, `final_ready=false`, `needs_manual_review=false` korundu.
6. Bulk parcel-distance expansion için `final_ready=true` yazılmadı.
7. Runner launcher tarafı için `RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd` ile gerçek queue runner continuation script’i arasında alias/bağlantı patch’i GitHub’a yazıldı, fakat local F diskinde çalıştırılması gerektiği not edildi.

## Son doğrulanmış sayılar

```text
visible_program_layer_rows=10
source_audit_rows=14
covered_property_type_count=6
accuracy_target_4=3.0
passed_accuracy_target_rows=14
final_ready=false
fake_data=false
db_write=false
migration=false
production_deploy=false
```

## Görünür 10 satır

- DPT_WEB_PILOT_WESTFIELD_LONDON_001: Westfield London — Retail Property — 3.0/4 — https://www.westfield.com/united-kingdom/london
- DPT_WEB_PILOT_NEWS_BUILDING_002: The News Building — Office Building — 3.0/4 — https://www.news.co.uk/contact-us/
- DPT_WEB_PILOT_THE_SHARD_003: The Shard — Mixed Building — 3.0/4 — https://www.the-shard.com/
- DPT_WEB_PILOT_ONE_HYDE_PARK_004: One Hyde Park — Apartment Building — 3.0/4 — https://www.mandarinoriental.com/en/residences/one-hyde-park
- DPT_WEB_PILOT_WITANHURST_005: Witanhurst — Detached Home — 3.0/4 — https://historicengland.org.uk/listing/the-list/list-entry/1379026
- DPT_WEB_PILOT_LSIP_DAGENHAM_006: LSIP / SEGRO Dagenham — Industrial Unit — 3.0/4 — https://www.segro.com/property-search/gb/segro-park-dagenham
- DPT_WEB_VERIFIED_22_BISHOPSGATE_007: 22 Bishopsgate — Office Building — 3.25/4 — https://22bishopsgate.com/
- DPT_WEB_VERIFIED_BATTERSEA_POWER_STATION_008: Battersea Power Station — Mixed Building — 3.25/4 — https://batterseapowerstation.co.uk/
- DPT_WEB_VERIFIED_BLUEWATER_009: Bluewater — Retail Property — 3.1/4 — https://bluewater.co.uk/
- DPT_WEB_VERIFIED_ONE_THE_ELEPHANT_010: One The Elephant — Apartment Building — 3.1/4 — https://onetheelephant.com/

## Audit edilmiş ama görünür layer’a append bekleyen 4 aday

- DPT_WEB_VERIFIED_THE_GHERKIN_011: The Gherkin — Office Building — 3.25/4 — https://thegherkin.com/
- DPT_WEB_VERIFIED_ONE_PARK_DRIVE_012: One Park Drive — Apartment Building — 3.15/4 — https://oneparkdrive.com/
- DPT_WEB_VERIFIED_TRAFFORD_CENTRE_013: Trafford Centre — Retail Property — 3.15/4 — https://traffordcentre.co.uk/
- DPT_WEB_VERIFIED_MAGNA_PARK_LUTTERWORTH_014: Magna Park Lutterworth — Industrial Unit — 3.05/4 — https://www.glp.com/global/magna-park-lutterworth
