# File Manifest

## Required handoff files in this ZIP

- `NEW_CHATGPT_PAGE_CONTINUE_PROMPT.md`
- `CURRENT_PAGE_WORK_SUMMARY.md`
- `GITHUB_EVIDENCE_INDEX.md`
- `RUNNER_HEALTH_AND_RECOVERY_GUIDE.md`
- `NEXT_ACTION_PLAN.md`
- `SAFETY_CONTRACT.md`
- `FILE_MANIFEST.md`
- `CURRENT_PAGE_CLOSEOUT_PROMPT.md`
- `HANDOFF_INDEX.json`
- `MISSING_FILES.md`

## Snapshot files in this ZIP

- `snapshots/runner_proof_134_f_portable_one_click_recovery_test_latest.json`
- `snapshots/runner_proof_130_f_portable_one_click_recovery_bootstrap_latest.json`
- `snapshots/stable_runner_daemon_heartbeat_latest.json`
- `snapshots/runner_bootstrap_latest.json`
- `snapshots/single_runner.lock.json`
- `snapshots/144_aays1_rows_15_17_23_26_27_live_verified_latest.json`
- `snapshots/photo_ai_boundary_review_results_summary.json`

## Previous uploaded package

If present in `/mnt/data`, the previous uploaded ZIP was copied into:
`previous_uploads/AAYS_aays1_NEW_CHATGPT_HANDOFF_20260708.zip`
