# AAYS / aays1 — Yeni ChatGPT Sayfası Devam Promptu

Bu ZIP paketini oku ve bu projeyi aynı yerden devam ettir.

## Sabit bilgiler

Repo: `cagdascagdas100/chat_gpt_clone_1`  
Branch: `codex/aays-single-runner-v5-20260706`  
PAGE_KEY: `aays1`

Canonical runner:
`F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd`

Canonical repo:
`F:\TerraYield_AAYS_Portable\runner_system\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707`

## Kesin kurallar

- Yeni runner açma.
- Paralel runner isteme.
- `C:\` yolunu canonical kabul etme.
- F portable tek shared runner kullanılacak.
- Sahte completed yazma.
- Sahte %100 yazma.
- Sahte `final_ready=true` yazma.
- `final_ready=false` kalacak.
- `fake_data=false`, `db_write=false`, `migration=false`, `production_deploy=false` kalacak.
- Gerçek GitHub proof/output olmadan metrik artırma.
- Geometri kanıtı yoksa `geometry:null` kullan; geometri uydurma.
- Cevapları kısa ver.

## İlk yapılacak GitHub kontrolü

Önce şu dosyaları GitHub’dan oku:

```text
docs/chatgpt_status/aays1/status/134_f_portable_one_click_recovery_test_latest.json
docs/chatgpt_status/aays1/status/130_f_portable_one_click_recovery_bootstrap_latest.json
docs/chatgpt_status/_shared/heartbeat/stable_runner_daemon_heartbeat_latest.json
docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json
docs/chatgpt_status/_shared/locks/single_runner.lock
```

Runner sağlıklı kabul şartı:

```text
runner_active=true
pid_alive=true
lock_valid=true
git_push_status=pushed
final_ready=false
fake_data=false
db_write=false
migration=false
production_deploy=false
```

Runner sağlıklı değilse sadece şunu söyle:

```text
F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd dosyasına çift tıkla, sonra bu sayfaya devam yaz.
```

## Son doğrulanmış durum

```text
Genel işlem: 97%
Site görünür: 86%
Yapılan doğrulama: 30 / 1264 satır
Son eklenen satırlar: 15, 16, 17, 23, 26, 27
Kalan: 3%
final_ready=false
```

Son site data:
`england_map_web/data/geometry_review_3of4/photo_ai_boundary_review_results.json`

Son web görünüm:
`england_map_web/geometry_review_3of4_columns_1264.html`

Son durum dosyası:
`docs/chatgpt_status/aays1/status/144_aays1_rows_15_17_23_26_27_live_verified_latest.json`

## Devam mantığı

Kullanıcı `devam` derse:

1. Proof dosyalarını tekrar oku.
2. Runner sağlıklıysa `aays1` işi dışında hiçbir page_key’e dokunma.
3. Son site datasını oku.
4. Yeni adayları sadece internetten canlı kaynak açılabiliyorsa doğrula.
5. Açılmayan URL’leri doğrulanmış yazma.
6. Site data JSON’una sadece gerçek kaynak doğrulaması olan satırları ekle.
7. Web sitesinde satır satır görünür olsun:
   - `CANLI KAYNAK DOĞRULANDI`
   - listing type
   - foto sayısı
   - alan / planning ref / title
8. `3.5+` güven yazma; bunun için photo download + polygon render + visual match/vision compare gerekir.
9. Her tur sonunda sadece kısa metrik ver:

```text
Bu işlem artışı: +X%
Genel işlem: Y%
Site görünür: Z%
Yapılan doğrulama: N / 1264 satır
Bu turda eklenen: M satır
Kalan: W%
Bekleme: A-B dk
Durum: ...
```

## Sıkıntı varsa

Sıkıntıyı kısa söyle. Sahte ilerleme yazma. Gerçek GitHub output/proof yoksa yüzde artırma.
