# GitHub Evidence Index

## Runner proof files

```text
docs/chatgpt_status/aays1/status/134_f_portable_one_click_recovery_test_latest.json
docs/chatgpt_status/aays1/status/130_f_portable_one_click_recovery_bootstrap_latest.json
docs/chatgpt_status/_shared/heartbeat/stable_runner_daemon_heartbeat_latest.json
docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json
docs/chatgpt_status/_shared/locks/single_runner.lock
```

## Latest aays1 status files

```text
docs/chatgpt_status/aays1/status/144_aays1_rows_15_17_23_26_27_live_verified_latest.json
docs/chatgpt_status/aays1/status/143_aays1_next_clean_candidate_batch_after_30_latest.json
docs/chatgpt_status/aays1/status/142_aays1_live_fetch_blocker_next_batch_required_latest.json
docs/chatgpt_status/aays1/status/141_aays1_site_row_visibility_improved_latest.json
docs/chatgpt_status/aays1/status/140_aays1_runner_pickup_repair_for_139_latest.json
docs/chatgpt_status/aays1/status/139_aays1_real_fix_queued_latest.json
```

## Site files

```text
england_map_web/data/geometry_review_3of4/photo_ai_boundary_review_results.json
england_map_web/geometry_review_3of4_columns_1264.html
```

## Queue / automation

```text
docs/chatgpt_status/aays1/queue/current.task.json
docs/chatgpt_status/aays1/queue/139_aays1_retry_skipped_candidates_and_queue_vision_20260709.task.json
docs/chatgpt_status/aays1/automation/139_aays1_retry_skipped_candidates_and_queue_vision_20260709.ps1
docs/chatgpt_status/aays1/queue/143_aays1_extract_next_clean_candidate_batch_after_30_20260709.task.json
docs/chatgpt_status/aays1/automation/143_aays1_extract_next_clean_candidate_batch_after_30_20260709.ps1
```
