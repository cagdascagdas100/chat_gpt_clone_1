# Runner Health and Recovery Guide

## Canonical runner

```text
F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd
```

## Canonical repo

```text
F:\TerraYield_AAYS_Portable\runner_system\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707
```

## Healthy criteria

```text
runner_active=true
pid_alive=true
lock_valid=true
git_push_status=pushed
final_ready=false
fake_data=false
db_write=false
migration=false
production_deploy=false
```

## If unhealthy

Yeni ChatGPT sayfası sadece şunu söyleyecek:

```text
F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd dosyasına çift tıkla, sonra bu sayfaya devam yaz.
```

## Hard rule

Yeni runner açma. Paralel runner isteme. C:\ canonical kabul etme.
