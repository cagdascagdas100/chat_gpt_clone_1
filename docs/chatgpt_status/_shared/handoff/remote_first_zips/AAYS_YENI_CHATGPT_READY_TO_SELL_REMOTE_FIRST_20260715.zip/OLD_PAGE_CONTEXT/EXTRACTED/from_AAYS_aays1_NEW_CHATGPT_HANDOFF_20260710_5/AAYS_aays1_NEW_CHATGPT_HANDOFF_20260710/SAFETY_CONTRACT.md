# Safety Contract

- New runner: forbidden.
- Parallel runner: forbidden.
- C:\ canonical path: forbidden.
- Fake completed: forbidden.
- Fake 100%: forbidden.
- Fake `final_ready=true`: forbidden.
- `final_ready=false` must remain until real final proof.
- `fake_data=false`
- `db_write=false`
- `migration=false`
- `production_deploy=false`
- No metric increase without real GitHub proof/output.
- No geometry fabrication. If no geometry evidence, use `geometry:null`.
- No 3.5+ confidence without photo download + polygon render + vision compare.
