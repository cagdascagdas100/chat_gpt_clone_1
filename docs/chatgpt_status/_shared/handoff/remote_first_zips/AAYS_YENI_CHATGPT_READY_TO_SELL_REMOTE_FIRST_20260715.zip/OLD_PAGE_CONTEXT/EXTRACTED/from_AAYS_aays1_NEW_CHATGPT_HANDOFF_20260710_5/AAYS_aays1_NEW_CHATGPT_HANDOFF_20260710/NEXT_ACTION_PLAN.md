# Next Action Plan

## Immediate next step

1. GitHub proof dosyalarını oku.
2. `photo_ai_boundary_review_results.json` dosyasını oku.
3. Row 31’den veya mevcut data sonrası temiz aday batch’ten devam et.
4. Sadece canlı internet kaynağı açılan satırları doğrula.
5. Doğrulananları site data JSON’una yaz.
6. Web sitesinde satır satır görünür hale getir.
7. 3.5+ güveni yalnızca photo download + polygon render + vision compare sonrası ver.

## Current known progress

- Verified live source rows: 30
- Site visible progress: 86%
- Overall progress: 97%
- Remaining: 3%

## Next response format

```text
Bu işlem artışı: +X%
Genel işlem: Y%
Site görünür: Z%
Yapılan doğrulama: N / 1264 satır
Bu turda eklenen: M satır
Kalan: W%
Bekleme: A-B dk
Durum: ...
```
