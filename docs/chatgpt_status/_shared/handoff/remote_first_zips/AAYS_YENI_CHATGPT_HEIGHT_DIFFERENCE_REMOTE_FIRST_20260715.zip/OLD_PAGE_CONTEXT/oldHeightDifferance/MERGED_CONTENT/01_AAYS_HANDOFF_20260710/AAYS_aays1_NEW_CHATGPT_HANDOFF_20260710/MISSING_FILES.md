# Missing Files

Aşağıdaki beklenen runner output dosyaları son GitHub readback kontrolünde bulunamadı:

```text
docs/chatgpt_status/aays1/reports/f_portable_site_8012_smoke_latest.json
docs/chatgpt_status/aays1/status/135_force_8012_smoke_and_parcel_binding_latest.json
```

Bunlar oluşturulana kadar:

```text
final_ready=false
fake_data=false
progress=99.5
```

Not: Orijinal proje ZIP’leri varsa yeni sayfaya ayrıca yüklenebilir. Bu ZIP mevcut sayfada erişilebilen `/mnt/data` dosyalarının kopyalarını `uploaded_inputs/` altına koyar.
