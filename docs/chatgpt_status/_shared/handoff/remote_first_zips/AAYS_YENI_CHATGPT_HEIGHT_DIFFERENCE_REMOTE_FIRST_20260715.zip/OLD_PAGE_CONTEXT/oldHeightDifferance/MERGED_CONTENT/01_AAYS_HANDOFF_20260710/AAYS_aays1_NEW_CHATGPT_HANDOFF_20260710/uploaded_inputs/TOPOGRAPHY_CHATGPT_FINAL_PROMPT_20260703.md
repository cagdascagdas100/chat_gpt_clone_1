# TerraYield AAYS - Topography ChatGPT Runner Prompt

Bu paketi TerraYield AAYS Topography katmani icin kullan. Kullanici ChatGPT sayfasinda sadece "devam" dediginde, tek runner ve GitHub repo dosyalari uzerinden kaldigin yerden ilerle.

## Katman

- Layer name: Topography
- Program output: Elevation Difference from Sea Level, Elevation Difference from Regional Average
- Control site: `http://127.0.0.1:8020/TerraYield_England_Program_Parcel_Layer_Matrix_20260629.html?refresh=20260630-final`
- Main app: `http://127.0.0.1:8010/england_map_web/`
- Site-visible update JSON: `outputs/england_program_parcel_matrix_20260629/topography_updates/latest_changes.json`
- Current task: `docs/chatgpt_status/topography/current_task/topography_current_task_20260703.json`
- Runner bridge: `docs/chatgpt_status/topography/automation/topography_single_runner_bridge_20260703.ps1`
- Fillable CSV: `docs/chatgpt_status/topography/fixtures/topography_verified_rows_template_20260703.csv`
- Schema: `docs/chatgpt_status/topography/schemas/topography_site_update_schema_20260703.json`
- Legacy status folder to check: `docs/chatgpt_status/AAYS_REAL_TOPOGRAPHY_PRODUCT`

## Source Of Truth

Topography tamamlandi sayilmaz, eger sadece icon, toggle, frontend binding veya harita altligi dogrulandiysa. Final kabul icin kullanici bir parsel secince ilgili elevation/topography dugmesine bastiginda popup veya sag panelde hem deniz seviyesine gore yukseklik hem de bolgesel ortalamaya gore yukseklik farki gorunmelidir.

Existing file to inspect first:

```text
england_map_web/data/program_layer_matrix/topography.geojson
```

Known current risk: this file can contain `topography_sea_level_value` and `topography_regional_average_value`, but example rows may only be `2/4`. Do not mark final until source-backed verification reaches at least `3/4`.

## Zorunlu Alanlar

Her dogrulanmis satir su alanlari doldurmalidir:

- parcel_id
- parcel_ref
- elevation_sea_level_m
- regional_average_elevation_m
- elevation_difference_regional_average_m
- elevation_class
- color_category
- confidence_rating
- confidence_percent
- source
- source_url
- source_date
- matching_method
- calculation_explanation
- accuracy_score_4
- needs_manual_review
- changed_in_latest_run

## Source Candidates

Use official or highly verifiable sources first:

- Copernicus DEM
- Environment Agency LIDAR / terrain data
- Ordnance Survey Terrain products
- USGS/SRTM only as fallback where official local data is unavailable
- project-generated regional average elevation calculation report

Every source must include source URL, source date or publication date, geography level, and which output it proves.

## Dogruluk Skoru

- 0/4: Veri yok veya sadece icon/toggle/altlik var.
- 1/4: Yerel topography alani var ama kaynak/evidence belirsiz.
- 2/4: Parsel eslesmesi ve UI baglantisi var ama kaynak zayif veya eksik.
- 3/4: Resmi veya guvenilir DEM kaynagi + parcel match + UI popup/panel kaniti var.
- 3.5/4: Resmi kaynak + AI kontrolu uyumlu, celiski yok.
- 4/4: Resmi kaynak + AI kontrolu + browser smoke + runner raporu + 8020 site gorunumu tamam.

## Tek Runner Akisi

1. Yeni runner baslatmadan once status/heartbeat dosyalarini oku.
2. `current_task/topography_current_task_20260703.json` dosyasini oku.
3. `england_map_web/data/program_layer_matrix/topography.geojson` alanlarini kontrol et.
4. Legacy durum icin `docs/chatgpt_status/AAYS_REAL_TOPOGRAPHY_PRODUCT` klasorunu oku.
5. Dogrulanmis satirlari `fixtures/topography_verified_rows_template_20260703.csv` icine yaz.
6. Runner bridge komutunu repo root'ta calistir:

```powershell
$env:AAYS_REPO_ROOT="C:\Users\cagda\Documents\GitHub\AAYS"
powershell -NoProfile -ExecutionPolicy Bypass -File docs\chatgpt_status\topography\automation\topography_single_runner_bridge_20260703.ps1
```

7. Sonuclari su dosyalardan kontrol et:

- `outputs/england_program_parcel_matrix_20260629/topography_updates/latest_changes.json`
- `docs/chatgpt_status/topography/reports/topography_progress_latest_20260703.md`
- `docs/chatgpt_status/topography/status/topography_current_status_20260703.txt`

8. Kullanici 8020 kontrol sitesinde Topography - Guncel Degisiklikler panelinden sonucu gorebilmeli.

## Final Kabul Kurali

`final_ready=true` sadece su kosullarda yaz:

- Kullanici bir parsel secebiliyor.
- Topography/elevation dugmesine tiklayinca ilgili parsel icin elevation paneli aciliyor.
- Popup veya sag panelde `elevation_sea_level_m` ve `elevation_difference_regional_average_m` gorunuyor.
- Source, source date, confidence, matching method ve calculation explanation gorunuyor.
- Bolgesel ortalama hesaplama yontemi raporda aciklaniyor.
- `latest_changes.json` 8020 kontrol sitesinde guncel sonucu gosteriyor.
- Kaynak/evidence ve AI kontrolu raporda yaziyor.

Eksik varsa `final_ready=false`, `manual_review_required=true/false`, `blockers=` ve `next_action=` alanlarini net yaz.
