param(
  [string]$TaskPath = "docs\chatgpt_status\topography\current_task\topography_current_task_20260703.json",
  [string]$VerifiedRowsCsv = "docs\chatgpt_status\topography\fixtures\topography_verified_rows_template_20260703.csv",
  [string]$SiteVisibleJson = "outputs\england_program_parcel_matrix_20260629\topography_updates\latest_changes.json"
)

$ErrorActionPreference = "Stop"
$RepoRoot = if ($env:AAYS_REPO_ROOT) { $env:AAYS_REPO_ROOT } else { (Resolve-Path ".").Path }
$RowsFullPath = Join-Path $RepoRoot $VerifiedRowsCsv
$SiteJsonFullPath = Join-Path $RepoRoot $SiteVisibleJson
$ReportDir = Join-Path $RepoRoot "docs\chatgpt_status\topography\reports"
$StatusDir = Join-Path $RepoRoot "docs\chatgpt_status\topography\status"
$HeartbeatDir = Join-Path $RepoRoot "docs\chatgpt_status\topography\heartbeat"
New-Item -ItemType Directory -Force -Path $ReportDir,$StatusDir,$HeartbeatDir,(Split-Path -Parent $SiteJsonFullPath) | Out-Null

$ts = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
$rows = @()
if (Test-Path -LiteralPath $RowsFullPath) {
  $rows = @(Import-Csv -LiteralPath $RowsFullPath)
}

function Convert-OptionalDouble {
  param([string]$Value)
  if ([string]::IsNullOrWhiteSpace($Value)) { return $null }
  $parsed = 0.0
  if ([double]::TryParse($Value, [Globalization.NumberStyles]::Any, [Globalization.CultureInfo]::InvariantCulture, [ref]$parsed)) {
    return $parsed
  }
  return $null
}

function Convert-OptionalBool {
  param([string]$Value, [bool]$Default)
  if ([string]::IsNullOrWhiteSpace($Value)) { return $Default }
  $normalized = $Value.Trim().ToLowerInvariant()
  if ($normalized -in @("1", "true", "yes", "y")) { return $true }
  if ($normalized -in @("0", "false", "no", "n")) { return $false }
  return $Default
}

$realRows = @($rows | Where-Object {
  $_.parcel_id -and
  $_.parcel_id -notlike "REPLACE_WITH_*" -and
  $_.elevation_sea_level_m -ne "" -and
  $_.elevation_difference_regional_average_m -ne "" -and
  $_.source_url -and
  $_.source_url -notlike "REPLACE_WITH_*"
})

$changes = @($realRows | ForEach-Object {
  [ordered]@{
    parcel_id = $_.parcel_id
    parcel_ref = $_.parcel_ref
    elevation_sea_level_m = Convert-OptionalDouble $_.elevation_sea_level_m
    regional_average_elevation_m = Convert-OptionalDouble $_.regional_average_elevation_m
    elevation_difference_regional_average_m = Convert-OptionalDouble $_.elevation_difference_regional_average_m
    elevation_class = $_.elevation_class
    color_category = $_.color_category
    confidence_rating = $_.confidence_rating
    confidence_percent = Convert-OptionalDouble $_.confidence_percent
    source = $_.source
    source_url = $_.source_url
    source_date = $_.source_date
    matching_method = $_.matching_method
    calculation_explanation = $_.calculation_explanation
    accuracy_score_4 = Convert-OptionalDouble $_.accuracy_score_4
    needs_manual_review = Convert-OptionalBool $_.needs_manual_review $true
    changed_in_latest_run = Convert-OptionalBool $_.changed_in_latest_run $false
    change_reason = "Runner imported verified Topography row from CSV template."
  }
})

$finalReady = ($changes.Count -gt 0) -and (($changes | Where-Object { $_.accuracy_score_4 -lt 3 -or $_.needs_manual_review }).Count -eq 0)
$payload = [ordered]@{
  layer = "Topography"
  program_output = "Elevation Difference from Sea Level, Elevation Difference from Regional Average"
  status = if ($finalReady) { "RUNNER_VERIFIED_SITE_VISIBLE" } else { "WAITING_FOR_VERIFIED_SOURCE_ROWS" }
  fake_data = $false
  db_write = $false
  migration_apply = $false
  prod_deploy = $false
  last_updated = $ts
  runner_status = "single_runner_bridge_completed"
  verification_score_before = "0/4"
  verification_score_after = if ($finalReady) { "3/4" } elseif ($changes.Count -gt 0) { "2/4" } else { "0/4" }
  next_action = if ($finalReady) { "Open 8020 matrix site and verify Topography updated changes panel." } else { "ChatGPT must replace template CSV rows with verified source-backed parcel rows, then rerun this bridge." }
  existing_project_context = [ordered]@{
    legacy_status_folder = "docs/chatgpt_status/AAYS_REAL_TOPOGRAPHY_PRODUCT"
    program_matrix_geojson = "england_map_web/data/program_layer_matrix/topography.geojson"
    overlay_config = "england_map_web/config/topography.overlay.json"
  }
  summary = [ordered]@{
    changed_count = $changes.Count
    verified_count = @($changes | Where-Object { $_.accuracy_score_4 -ge 3 }).Count
    manual_review_count = @($changes | Where-Object { $_.needs_manual_review }).Count
    accuracy_ge_3_count = @($changes | Where-Object { $_.accuracy_score_4 -ge 3 }).Count
    final_ready = $finalReady
  }
  changes = $changes
}

$json = $payload | ConvertTo-Json -Depth 14
Set-Content -LiteralPath $SiteJsonFullPath -Value $json -Encoding UTF8
Set-Content -LiteralPath (Join-Path $StatusDir "topography_current_status_20260703.txt") -Value @(
  "layer=Topography",
  "task_path=$TaskPath",
  "site_visible_json=$SiteVisibleJson",
  "runner_status=$($payload.runner_status)",
  "final_ready=$finalReady",
  "changed_count=$($changes.Count)",
  "verification_score_after=$($payload.verification_score_after)",
  "updated_at=$ts"
) -Encoding UTF8
Set-Content -LiteralPath (Join-Path $HeartbeatDir "topography_single_runner_bridge_20260703_heartbeat.txt") -Value "heartbeat=$ts" -Encoding UTF8
Set-Content -LiteralPath (Join-Path $ReportDir "topography_progress_latest_20260703.md") -Value @(
  "# Topography Progress Latest",
  "",
  "updated_at=$ts",
  "runner_status=$($payload.runner_status)",
  "final_ready=$finalReady",
  "verification_score_after=$($payload.verification_score_after)",
  "site_visible_json=$SiteVisibleJson",
  "changed_count=$($changes.Count)",
  "",
  "## Next Action",
  $payload.next_action
) -Encoding UTF8

Write-Output "topography_single_runner_bridge_completed"
