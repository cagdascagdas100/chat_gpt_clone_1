# Safety Contract

- Yeni runner açma.
- Paralel runner isteme.
- `C:\` canonical kabul etme.
- F portable tek shared runner kullanılacak.
- Sahte completed yazma.
- Sahte `%100` yazma.
- Sahte `final_ready=true` yazma.
- Gerçek GitHub proof/output olmadan metrik artırma.
- `final_ready=false` kalacak.
- `fake_data=false` kalacak.
- `db_write=false` kalacak.
- `migration=false` kalacak.
- `production_deploy=false` kalacak.
- Geometri kanıtı yoksa `geometry:null` kullan; geometri uydurma.
- Siteye yazılan satırlar resmi veya güvenilir kaynakla desteklenmeli.
- Kullanıcı “devam” dediğinde önce runner proof dosyaları okunmalı.
