# Site / Panel Output Files

The site-visible aays1 outputs currently available in this package are status-panel files, not full web app source files.

Included:

- `repo_evidence/docs/chatgpt_status/aays1/status/aays1_site_visible_current_status_latest.json`
- `repo_evidence/docs/chatgpt_status/aays1/status/aays1_work_progress_latest.json`
- `repo_evidence/docs/chatgpt_status/aays1/status/aays1_required_sources_latest.json`

Potential full site files such as `england_map_web/app.js` were not available through the current sandbox as local files. In the next page, check the GitHub branch/local repo for:

- `england_map_web/`
- `england_map_web/app.js`
- `england_map_web/data/program_layer_matrix/`

If present, update them only after real evidence exists. If absent, report missing paths.
