# TerraYield AAYS Topography — Auto-Continue Fix Package (2026-07-04)

Bu paket önceki F-disk paketinin düzeltilmiş halidir. Önceki denemede hata alınmasının nedeni scriptin yerel repo içine henüz kopyalanmamış olması veya PowerShell'in `C:\Users\cagda` dizininden çalıştırılmasıydı.

## Amaç

- Yeni runner başlatmadan Topography bridge dosyalarını F repo içine uygular.
- `F:\chatgpt\chat_gpt_clone_1_main` dışına yazmaz.
- CSV gerçek kaynaklı parsel satırlarıyla dolmadan `final_ready=true` üretmez.
- Her `devam` turunda rapor formatı şu metriklere indirgenir:
  - tamamlanan yüzde
  - bekleme dakika aralığı
  - kalan yüzde
  - doldurulan parsel sayısı
  - doğruluk düzeyi
  - blocker / next_action

## Neden önceki komut çalışmadı?

PowerShell şunu söyledi:

```text
The argument '.\docs\chatgpt_status\topography\automation\APPLY_TO_F_DISK_REPO_20260704.ps1' to the -File parameter does not exist.
```

Bu, `APPLY_TO_F_DISK_REPO_20260704.ps1` dosyasının çalıştırılan mevcut klasörde bulunmadığını gösterir. Bu yeni pakette aynı script kök klasöre de kondu:

```text
APPLY_TO_F_DISK_REPO_20260704.ps1
```

## Mevcut başlangıç durumu

```text
setup_package_ready=true
local_f_disk_applied=false
runner_started_by_chatgpt=false
new_runner_started=false
program_integration_percent=0
website_update_percent=0
filled_parcel_count=0
verified_parcel_count=0
accuracy_score_4=0/4
final_ready=false
manual_review_required=true
blockers=package_not_applied_to_f_repo;verified_rows_missing;browser_smoke_missing
next_action=extract_package_to_a_local_folder_then_run_root_apply_script_from_that_folder_or_copy_package_contents_to_F_repo
```

## Dosya hedefleri

- `docs/chatgpt_status/topography/current_task/topography_current_task_20260703.json`
- `docs/chatgpt_status/topography/schemas/topography_site_update_schema_20260703.json`
- `docs/chatgpt_status/topography/fixtures/topography_verified_rows_template_20260703.csv`
- `docs/chatgpt_status/topography/automation/topography_single_runner_bridge_20260703.ps1`
- `england_map_web/data/program_layer_matrix/topography.geojson`
- `outputs/england_program_parcel_matrix_20260629/topography_updates/latest_changes.json`
- `docs/chatgpt_status/topography/reports/topography_progress_latest_20260703.md`
- `docs/chatgpt_status/topography/status/topography_current_status_20260703.txt`

## Final kabul kapısı

`final_ready=true` sadece aşağıdakiler tamamlanınca verilir:

1. Gerçek kaynaklı parsel satırları CSV içinde var.
2. Satırlar `topography.geojson` içindeki parsellerle eşleşiyor.
3. 8020 panelinde Topography - Güncel Değişiklikler görünür.
4. 8010 ana uygulama parsel seçimi sonrası Topography/Elevation popup veya sağ panel gösterir.
5. Source, source date, confidence, matching method ve calculation explanation görünür.
6. Browser smoke ve runner raporu tamamdır.
7. Tüm kabul satırları minimum `accuracy_score_4 >= 3` seviyesindedir.
