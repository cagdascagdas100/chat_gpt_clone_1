# File Manifest

## Root files in this ZIP

- `NEW_CHATGPT_PAGE_CONTINUE_PROMPT.md`
- `CURRENT_PAGE_WORK_SUMMARY.md`
- `GITHUB_EVIDENCE_INDEX.md`
- `RUNNER_HEALTH_AND_RECOVERY_GUIDE.md`
- `NEXT_ACTION_PLAN.md`
- `SAFETY_CONTRACT.md`
- `FILE_MANIFEST.md`
- `CURRENT_PAGE_CLOSEOUT_PROMPT.md`
- `HANDOFF_INDEX.json`
- `MISSING_FILES.md`

## Snapshot copies in this ZIP

- `snapshots/github/proof/134_f_portable_one_click_recovery_test_latest.json`
- `snapshots/github/proof/130_f_portable_one_click_recovery_bootstrap_latest.json`
- `snapshots/github/proof/stable_runner_daemon_heartbeat_latest.json`
- `snapshots/github/proof/runner_bootstrap_latest.json`
- `snapshots/github/proof/single_runner.lock.json`
- `snapshots/github/site_data/latest_changes.json`
- `snapshots/github/site_data/gas_emissions_status_latest.json`
- `snapshots/github/site_data/gas_emissions_visible_rows_latest.json`
- `snapshots/github/site_data/app.js`
- `snapshots/github/site_data/index.html`
- `snapshots/github/queue/135_force_8012_smoke_and_parcel_binding.task.json`
- `snapshots/github/queue/aays1_135_force_8012_smoke_and_parcel_binding.task.json`

## Uploaded inputs copied when available

- `/mnt/data/AAYS_aays1_NEW_CHATGPT_HANDOFF_20260708 (2).zip`
- `/mnt/data/Yeni proje yapısı.txt`
- `/mnt/data/image.png`
- `/mnt/data/TOPOGRAPHY_CHATGPT_FINAL_PROMPT_20260703.md`
- `/mnt/data/topography_final_handoff_20260703.zip`
