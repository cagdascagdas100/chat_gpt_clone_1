# TerraYield AAYS Topography — F Disk Application Package (2026-07-04)

Bu paket, yüklenen 2026-07-03 Topography handoff ZIP'inin F-disk-only uygulama dosyalarıyla genişletilmiş halidir.

## Kural

- Yeni runner başlatma.
- Repo root olarak yalnızca `F:\chatgpt\chat_gpt_clone_1_main` kullan.
- `C:` veya `D:` root'a yazma.
- Gerçek kaynak/evidence yoksa `final_ready=false` kalır.
- CSV içinde gerçek parsel satırı yoksa bridge sadece blocker raporu üretir.

## F diskine uygulama

```powershell
$env:AAYS_REPO_ROOT="F:\chatgpt\chat_gpt_clone_1_main"
powershell -NoProfile -ExecutionPolicy Bypass -File .\docs\chatgpt_status	opographyutomation\APPLY_TO_F_DISK_REPO_20260704.ps1 -RepoRoot "F:\chatgpt\chat_gpt_clone_1_main"
```

## Verified rows doldurma

Doldurulacak dosya:

```text
docs/chatgpt_status/topography/fixtures/topography_verified_rows_template_20260703.csv
```

Her gerçek satır şu alanları eksiksiz içermeli:

```text
parcel_id, parcel_ref, elevation_sea_level_m, regional_average_elevation_m,
elevation_difference_regional_average_m, elevation_class, color_category,
confidence_rating, confidence_percent, source, source_url, source_date,
matching_method, calculation_explanation, accuracy_score_4,
needs_manual_review, changed_in_latest_run
```

`calculation_explanation` içinde mutlaka şu mantık açık olmalı:

```text
elevation_difference_regional_average_m = elevation_sea_level_m - regional_average_elevation_m
```

## Bridge çalıştırma

```powershell
$env:AAYS_REPO_ROOT="F:\chatgpt\chat_gpt_clone_1_main"
powershell -NoProfile -ExecutionPolicy Bypass -File docs\chatgpt_status	opographyutomation	opography_single_runner_bridge_20260703.ps1
```

## Browser smoke

Yerel 8010 ve 8020 servisleri açıkken:

```powershell
$env:AAYS_REPO_ROOT="F:\chatgpt\chat_gpt_clone_1_main"
node docs\chatgpt_status	opographyutomation	opography_browser_smoke_check_20260704.js
powershell -NoProfile -ExecutionPolicy Bypass -File docs\chatgpt_status	opographyutomation	opography_single_runner_bridge_20260703.ps1
```

Smoke kanıtı şu dosyaya yazılır:

```text
docs/chatgpt_status/topography/browser_smoke/topography_browser_smoke_latest_20260704.json
```

## Oluşturulan/patchlenen uygulama dosyaları

- `england_map_web/topography_panel_runtime_patch_20260704.js`
- `outputs/england_program_parcel_matrix_20260629/topography_matrix_runtime_patch_20260704.js`
- `outputs/england_program_parcel_matrix_20260629/TerraYield_England_Program_Parcel_Layer_Matrix_20260629.html`
- `docs/chatgpt_status/topography/automation/topography_single_runner_bridge_20260703.ps1`
- `docs/chatgpt_status/topography/automation/topography_browser_smoke_check_20260704.js`
- `docs/chatgpt_status/topography/sources/topography_official_source_registry_20260704.json`

## Final kabul

Bridge `final_ready=true` üretmez; şu koşullar tamamlanana kadar `final_ready=false` kalır:

1. CSV gerçek kaynaklı parsel satırlarıyla dolu.
2. Satırlar `topography.geojson` içindeki parsellerle eşleşiyor.
3. 8020 Topography - Güncel Değişiklikler paneli zorunlu alanları gösteriyor.
4. Ana uygulamada Topography/Elevation paneli görünür.
5. Browser smoke dosyası iki UI görünürlüğünü de doğruluyor.
6. Tüm satırlarda `accuracy_score_4 >= 3`, `needs_manual_review=false`, kaynak URL/tarih/matching/calculation alanları eksiksiz.
