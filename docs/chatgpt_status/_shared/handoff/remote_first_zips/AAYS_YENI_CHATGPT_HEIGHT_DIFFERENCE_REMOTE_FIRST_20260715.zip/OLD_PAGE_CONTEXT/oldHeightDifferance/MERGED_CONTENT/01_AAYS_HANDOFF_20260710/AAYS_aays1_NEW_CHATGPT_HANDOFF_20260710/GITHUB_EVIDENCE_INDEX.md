# GitHub Evidence Index

## Runner proof dosyaları

- `docs/chatgpt_status/aays1/status/134_f_portable_one_click_recovery_test_latest.json`
- `docs/chatgpt_status/aays1/status/130_f_portable_one_click_recovery_bootstrap_latest.json`
- `docs/chatgpt_status/_shared/heartbeat/stable_runner_daemon_heartbeat_latest.json`
- `docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json`
- `docs/chatgpt_status/_shared/locks/single_runner.lock`

## Gas Emissions status / site data

- `outputs/england_program_parcel_matrix_20260629/gas_emissions_updates/latest_changes.json`
- `england_map_web/data/program_layer_matrix/gas_emissions_status_latest.json`
- `england_map_web/data/program_layer_matrix/gas_emissions_visible_rows_latest.json`
- `england_map_web/app.js`
- `england_map_web/index.html`

## Queue dosyaları

- `docs/chatgpt_status/aays1/queue/135_force_8012_smoke_and_parcel_binding.task.json`
- `docs/chatgpt_status/_shared/queue/aays1_135_force_8012_smoke_and_parcel_binding.task.json`

## Beklenen fakat son kontrolde eksik dosyalar

- `docs/chatgpt_status/aays1/reports/f_portable_site_8012_smoke_latest.json`
- `docs/chatgpt_status/aays1/status/135_force_8012_smoke_and_parcel_binding_latest.json`

## Kaynak veri

- GOV.UK DESNZ local authority and regional greenhouse gas emissions statistics 2005–2023.
- CSV preview source URL: `https://www.gov.uk/csv-preview/68653c7ee6c3cc924228943f/2005-23-uk-local-authority-ghg-emissions-CSV-dataset.csv`
