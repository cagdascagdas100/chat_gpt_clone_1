# AAYS / aays1 Yeni ChatGPT Sayfası Devam Promptu

Bu ZIP paketini oku ve bu sayfadaki işi aynı yerden devam ettir.

## Sabit proje bilgileri

```text
REPO=cagdascagdas100/chat_gpt_clone_1
BRANCH=codex/aays-single-runner-v5-20260706
PROJECT_FAMILY=AAYS
PAGE_KEY=aays1
LAYER=Gas Emissions
PROGRAM_OUTPUT=Gas Emission Level
CANONICAL_RUNNER=F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd
CANONICAL_REPO=F:\TerraYield_AAYS_Portable\runner_system\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707
ACTIVE_SITE=http://127.0.0.1:8012/england_map_web/index.html
```

## Kesin çalışma kuralları

- Yeni runner açma.
- Paralel runner isteme.
- `C:\` canonical kabul etme.
- Mevcut F portable tek shared runner kullanılacak.
- Sahte completed yazma.
- Sahte `%100` yazma.
- Sahte `final_ready=true` yazma.
- `final_ready=false` kalacak.
- `fake_data=false`, `db_write=false`, `migration=false`, `production_deploy=false` kalacak.
- Gerçek GitHub proof/output olmadan metrik artırma.
- Geometri kanıtı yoksa `geometry:null` kullan; geometri uydurma.
- Web/site görünür çıktılar gerçek dosyalara yazılsın.
- Cevapları kısa ver; işlem yolundaysa sadece ilerleme/yüzde/kalan blocker özetini ver.

## İlk yapılacak kontrol

Önce GitHub’dan şu proof dosyalarını oku:

```text
docs/chatgpt_status/aays1/status/134_f_portable_one_click_recovery_test_latest.json
docs/chatgpt_status/aays1/status/130_f_portable_one_click_recovery_bootstrap_latest.json
docs/chatgpt_status/_shared/heartbeat/stable_runner_daemon_heartbeat_latest.json
docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json
docs/chatgpt_status/_shared/locks/single_runner.lock
```

Sağlıklı kabul şartı:

```text
runner_active=true
pid_alive=true
lock_valid=true
git_push_status=pushed
final_ready=false
fake_data=false
db_write=false
migration=false
production_deploy=false
```

Runner sağlıklı değilse sadece şunu söyle:

```text
F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd dosyasına çift tıkla, sonra bu sayfaya devam yaz.
```

Runner sağlıklıysa `aays1 / Gas Emissions` işine kaldığı yerden devam et.

## Son doğrulanmış durum

```text
Genel ilerleme: %99.5
Yapılan işlem: 17/18
Kalan işlem: 1
Kalan blocker: 8012 browser smoke raporu / runner site doğrulaması
final_ready=false
fake_data=false
```

Web görünür çıktı:

```text
england_map_web/index.html
england_map_web/app.js
england_map_web/data/program_layer_matrix/gas_emissions_status_latest.json
england_map_web/data/program_layer_matrix/gas_emissions_visible_rows_latest.json
```

Görünür satır sayısı: 24 resmi GOV.UK satır. Doğruluk: 3.4/4. Güven: %88.
Kaynak: GOV.UK DESNZ local authority greenhouse gas emissions dataset 2005–2023.

## Devam ederken

- Önce `docs/chatgpt_status/aays1/reports/f_portable_site_8012_smoke_latest.json` var mı kontrol et.
- Varsa smoke sonucunu oku ve metrikleri sadece gerçek sonuca göre güncelle.
- Yoksa bu dosyanın eksik olduğunu söyle; yeni runner isteme.
- Web sitesine yeni satır eklersen sadece resmi/internet kaynağına dayalı satır ekle.
- Her satır için minimum alanlar:
  - row_id
  - calendar_year
  - sector
  - sub_sector
  - greenhouse_gas
  - territorial_emissions_kt_co2e
  - scope_of_influence_kt_co2
  - source_url
  - source_lines
  - matching_method
  - confidence_percent
  - accuracy_score_4
  - needs_manual_review
- Satırları `england_map_web/data/program_layer_matrix/gas_emissions_visible_rows_latest.json` içine ekle.
- Web tablosu `england_map_web/index.html` üzerinden satır satır görünür olmalı.
