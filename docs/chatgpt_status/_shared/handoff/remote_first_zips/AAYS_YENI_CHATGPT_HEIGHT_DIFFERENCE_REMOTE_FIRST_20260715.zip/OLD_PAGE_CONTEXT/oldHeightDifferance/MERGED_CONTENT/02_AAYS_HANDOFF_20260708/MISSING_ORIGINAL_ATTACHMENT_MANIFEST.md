# Missing Original Attachment Manifest

The user requested the original project ZIP from the beginning of this page.

Accessible files found in `/mnt/data` were copied into `attachments_available/`.

Accessible attachment/project files included:
- AAYS_CHATGPT_COMMON_DEVAM_PROMPT_20260706.md
- AAYS_CHATGPT_SAYFALARI_DEVAM_PROMPT.md
- TOPOGRAPHY_CHATGPT_FINAL_PROMPT_20260703.md
- Yapıştırılan metin.txt
- Yeni proje yapısı.txt
- aays1_conditional_100_percent_codex_completion_report_20260708.md
- topography_autocontinue_fix_20260704/
- topography_f_disk_application_files_20260704/
- topography_f_disk_application_files_20260704.zip
- topography_f_disk_autocontinue_fix_20260704.zip
- topography_final_handoff_20260703.zip

Original project ZIP status: **not directly identifiable as a separate original aays1 project ZIP in the active sandbox**.

This package therefore includes all accessible uploaded/provided files and this explicit missing-file manifest.
