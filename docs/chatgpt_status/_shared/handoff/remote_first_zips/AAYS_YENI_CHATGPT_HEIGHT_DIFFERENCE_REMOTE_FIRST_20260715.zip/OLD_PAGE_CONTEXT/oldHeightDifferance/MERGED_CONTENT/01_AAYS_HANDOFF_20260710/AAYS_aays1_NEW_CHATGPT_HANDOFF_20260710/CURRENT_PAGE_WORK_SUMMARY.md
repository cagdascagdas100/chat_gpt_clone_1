# Current Page Work Summary

## Kimlik

- Repo: `cagdascagdas100/chat_gpt_clone_1`
- Branch: `codex/aays-single-runner-v5-20260706`
- Project family: `AAYS`
- Page key: `aays1`
- Layer: `Gas Emissions`
- Program output: `Gas Emission Level`
- Canonical runner: `F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd`
- Canonical repo: `F:\TerraYield_AAYS_Portable\runner_system\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707`
- Active site: `http://127.0.0.1:8012/england_map_web/index.html`

## Son doğrulanmış durum

- Genel ilerleme: `%99.5`
- Yapılan işlem: `17/18`
- Kalan işlem: `1`
- Kalan blocker: `8012 browser smoke report / runner site validation`
- `final_ready=false`
- `fake_data=false`
- `db_write=false`
- `migration=false`
- `production_deploy=false`

## Runner proof sonucu

Son GitHub readback kontrolünde proof dosyaları runner’ı sağlıklı gösterdi:

- `runner_active=true`
- `pid=10108`
- `pid_alive=true`
- `lock_valid=true`
- `git_push_status=pushed`
- `single_runner_only=true`
- `new_runner=false`
- `parallel_runner=false`

## Gas Emissions durumu

- `source_dataset_gate_passed=true`
- `source_row_gate_passed=true`
- `parcel_binding_gate_passed=false`
- `browser_smoke_passed=false`
- `verification_score_after=2.5/4`
- `extracted_row_count=47`
- `trial_mode=true`
- `manual_review_required=true`

## Web görünür çıktı

Aşağıdaki dosyalar branch üzerinde oluşturuldu/güncellendi:

- `england_map_web/app.js`
- `england_map_web/index.html`
- `england_map_web/data/program_layer_matrix/gas_emissions_status_latest.json`
- `england_map_web/data/program_layer_matrix/gas_emissions_visible_rows_latest.json`

Web tablosu artık şunları gösterecek:

- Row ID
- Year
- Sector
- Sub-sector
- Gas
- Territorial kt CO2e
- Scope kt CO2
- Accuracy
- Confidence
- Source line

Görünür satır sayısı: `24`.
Doğruluk: `3.4/4`.
Güven: `%88`.
Kaynak: GOV.UK DESNZ 2005–2023 local authority greenhouse gas emissions dataset.

## Kalan iş

1. `docs/chatgpt_status/aays1/reports/f_portable_site_8012_smoke_latest.json` dosyasının runner tarafından üretilmesi.
2. Smoke sonucu gerçekse site doğrulamasını kaydetmek.
3. Parcel binding kanıtı gerçek dosyaya dönmeden `final_ready=true` yazmamak.
