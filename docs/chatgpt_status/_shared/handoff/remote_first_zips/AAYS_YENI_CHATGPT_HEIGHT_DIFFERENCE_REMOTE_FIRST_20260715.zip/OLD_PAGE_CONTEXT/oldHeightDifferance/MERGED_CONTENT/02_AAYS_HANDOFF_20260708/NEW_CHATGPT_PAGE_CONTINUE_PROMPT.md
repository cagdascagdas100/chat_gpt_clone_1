# NEW CHATGPT PAGE CONTINUE PROMPT

Read this ZIP first. Continue the same AAYS/TerraYield page using the state inside this package.

## Fixed identity

```text
PAGE_KEY=aays1
REPO_LOCAL_ROOT=C:\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707
REPO_FULL_NAME=cagdascagdas100/chat_gpt_clone_1
BRANCH=codex/aays-single-runner-v5-20260706
RUNNER_LAUNCHER=C:\Users\cagda\Documents\GitHub\AAYS\START_AAYS_RUNNER.bat
RUNNER=RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707
```

## Mandatory rules

- Do not create a new runner.
- Do not create a parallel runner.
- Use the existing stable shared runner.
- Keep the same PAGE_KEY: `aays1`.
- Before doing work, read queue/status/report/heartbeat/runner_outputs evidence under `docs/chatgpt_status/aays1/`.
- Also read shared runner status, but note that global `MULTI_PAGE_latest_status.json` may be stale; prefer task-specific aays1 mirror/status proof when conflict exists.
- If pending task exists, wait for/verify runner pickup evidence.
- If no valid task exists, write a new contract-compliant queue task under `docs/chatgpt_status/aays1/queue/`.
- Do not write fake completed markers.
- Do not write fake 100%.
- Do not write `final_ready=true` unless all acceptance evidence exists.
- Do not increase metrics without GitHub evidence.
- Keep: `fake_data=false`, `db_write=false`, `migration=false`, `production_deploy=false`.

## Current state to start from

- Current progress: 45%.
- Last increase: +5%.
- Wait time: 0 minutes.
- Runner for aays1: verified.
- final_ready=false.

## Continue behavior

When the user writes only `devam et`, continue from the next item:

1. Create `046_recovery_latest.json` and `046_recovery_report.md` under `docs/chatgpt_status/aays1/`.
2. Then create `preflight_latest.json` and `preflight_report.md`.
3. Then create `endpoint_health_latest.json` and `endpoint_health_report.md`.
4. Then create `red_flag_quickscan_latest.json` and `red_flag_quickscan_report.md`.
5. Then create `044_accuracy_expansion_latest.json` and `044_accuracy_expansion_report.md`.
6. Then update `site_visible_score_status_latest.json`.

Only increase progress when the corresponding output files are actually committed/pushed or otherwise verified by GitHub evidence.

## Response style for future turns

Keep the response short:

```text
- Yapıldı: <1-3 bullets>
- Genel işlem: <%>
- Bu tur artış: <+%>
- Bekleme: <minutes>
- Blocker: <none or exact blocker>
- Sonraki işlem: <next output>
```
