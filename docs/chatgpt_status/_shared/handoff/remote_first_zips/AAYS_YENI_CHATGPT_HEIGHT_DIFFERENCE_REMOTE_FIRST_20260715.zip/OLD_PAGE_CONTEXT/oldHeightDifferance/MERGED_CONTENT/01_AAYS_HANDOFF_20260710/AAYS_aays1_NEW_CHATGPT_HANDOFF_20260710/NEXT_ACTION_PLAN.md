# Next Action Plan

## Sıradaki işlem

1. GitHub runner proof dosyalarını oku.
2. `docs/chatgpt_status/aays1/reports/f_portable_site_8012_smoke_latest.json` var mı kontrol et.
3. Varsa 8012 smoke sonucunu oku ve sadece gerçek sonuca göre ilerleme yaz.
4. Yoksa kalan blocker olarak `8012 browser smoke report / runner site validation` yaz.
5. `england_map_web/index.html` ve `gas_emissions_visible_rows_latest.json` dosyalarının web görünür satırlarını koru.
6. Yeni resmi satır eklenecekse sadece resmi GOV.UK veya eşdeğer güvenilir internet kaynağına dayalı ekle.
7. `final_ready=false` ve `fake_data=false` koru.

## Kısa cevap formatı

İşlem yolundaysa kullanıcıya yalnızca şunu ver:

```text
Bu tur artış: +X%
Genel işlem: %Y
Yapılan işlem: A/B
Kalan işlem: N
Bekleme: M dk
Özet: ...
Kalan blocker: ...
final_ready=false
```
