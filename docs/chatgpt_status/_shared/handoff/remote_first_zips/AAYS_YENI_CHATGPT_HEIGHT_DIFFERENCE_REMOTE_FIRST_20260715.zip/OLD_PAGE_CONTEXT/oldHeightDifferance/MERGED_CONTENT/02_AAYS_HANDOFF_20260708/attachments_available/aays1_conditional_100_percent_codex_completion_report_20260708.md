# aays1 / TerraYield AAYS — Şartlı %100 Codex Bitirme Raporu

## 1. Sayfa kimliği

- PAGE_KEY: `aays1`
- Branch: `codex/aays-single-runner-v5-20260706`
- Kullanıcının istediği aktif repo root: `C:\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707`
- Başlatıcı: `C:\Users\cagda\Documents\GitHub\AAYS\START_AAYS_RUNNER.bat`

Bu raporun amacı: Codex’in bu sayfadaki işi sadece “runner sağlıklı” diyerek bırakmaması; gerçek TerraYield/AAYS program işini, site-visible çıktıyı ve GitHub kanıt zincirini tamamlamasıdır.

## 2. Geri kazanılacak asıl görev

Bu sayfadaki asıl iş runner konuşması değil, şu görevin tamamlanmasıdır:

`terrayield-046-runner-sync-recovery-then-accuracy-expansion`

Kapsam:

1. Runner/Git sync recovery.
2. Preflight checks.
3. Endpoint health probe.
4. Project red-flag quickscan.
5. `044 comprehensive accuracy expansion` child işini başlatmak veya tamamlamak.
6. Her alt işi ayrı gerçek status/report/output dosyasına yazmak.
7. TerraYield/AAYS program veya site-visible çıktılarını güncellemek.
8. Kullanıcının site/panel üzerinden sonucu görebileceği dosya/panel yolunu raporlamak.

Başlangıç skorları:

- Kaynak doğruluk skoru: `45/100`
- Parsel eşleşme doğruluk skoru: `27/100`
- Operasyonel sağlık skoru: `0/100`
- Genel güven skoru: `32/100`

## 3. Kesin yasaklar

Codex şunları yapmayacak:

- Yeni runner açmayacak.
- Yeni V5 runner başlatmayacak.
- Paralel runner açmayacak.
- Sahte completed yazmayacak.
- Sahte `%100` yazmayacak.
- Sahte `final_ready=true` yazmayacak.
- GitHub kanıtı olmadan ilerleme metriği artırmayacak.
- DB write yapmayacak.
- Migration yapmayacak.
- Production deploy yapmayacak.
- Fake data üretmeyecek.
- Başka PAGE_KEY’in blocker’ını bu sayfada çözmeye çalışmayacak.

## 4. Codex’in onarması veya oluşturması gereken eksik yapılar

### 4.1 Shared runner kanıt zinciri

Codex GitHub’da şu kanıtları üretmeli veya güncellemelidir:

- `_shared/status/runner_bootstrap_latest.json`
- `_shared/status/stable_runner_daemon_latest.json`
- `_shared/status/MULTI_PAGE_latest_status.json`
- `_shared/heartbeat/MULTI_PAGE_heartbeat_latest.json`
- `_shared/heartbeat/stable_runner_daemon_heartbeat_latest.json`
- `_shared/reports/MULTI_PAGE_runner_output_*.json`

Bu kanıtlar şunları göstermelidir:

- approved healthy repo root kullanılıyor.
- `runner_exit_code=0`
- `queue_seen=true`
- `queue_started=true`
- `runner_output_uploaded=true`
- `PUSH_SYNC_OK=true`
- `controller_sync_ok=true`
- `final_ready=false`, tamamlanana kadar.

### 4.2 aays1 page-key yapısı

Codex şu klasörleri gerçek içerikle doldurmalıdır:

- `docs/chatgpt_status/aays1/queue/`
- `docs/chatgpt_status/aays1/status/`
- `docs/chatgpt_status/aays1/reports/`
- `docs/chatgpt_status/aays1/heartbeat/`
- `docs/chatgpt_status/aays1/runner_outputs/`
- `docs/chatgpt_status/aays1/automation/`

`completed/` sadece gerçek kabul kanıtı oluşunca kullanılmalıdır.

### 4.3 Valid queue task

Codex `aays1` altında valid pending/queued task oluşturmalıdır.

Zorunlu task alanları:

- `page_key=aays1`
- `status=pending` veya `status=queued`
- `target_branch=codex/aays-single-runner-v5-20260706`
- `automation_script=docs/chatgpt_status/aays1/automation/<real_script>.ps1`
- `new_runner_allowed=false`
- `single_shared_runner_required=true`
- `allowed_paths=["docs/chatgpt_status/aays1/"]`
- `final_ready=false`
- `fake_data=false`
- `db_write=false`
- `migration=false`
- `production_deploy=false`

Blocked veya obsolete task varsa completed yapılmayacak; `blocked` veya `skipped_obsolete` olarak gerekçesiyle bırakılacak.

### 4.4 Gerçek automation script

Automation script sadece blocked raporu yazıp çıkmayacak. Şunları yapacak:

1. Git/worktree preflight.
2. Queue JSON parse toleransı.
3. Endpoint health probe.
4. Red-flag quickscan.
5. 044 accuracy expansion child işini çalıştırma veya eksikse açık blocker yazma.
6. Status/report/heartbeat/runner_output üretme.
7. Program veya site-visible output dosyalarını güncelleme ya da eksik yolları raporlama.

### 4.5 Site-visible çıktı

Kullanıcının istediği ana sonuç sitede gözlemlenebilir çıktı olduğu için Codex şu iki seçenekten birini yapmak zorunda:

- TerraYield/AAYS site-visible program dosyalarını güncellemek.
- Bu branch’te site dosyaları yoksa eksik path’leri tek tek raporlamak.

Rapor şu soruları cevaplamalı:

- Hangi program/site dosyası değişti?
- Kullanıcı hangi panel, JSON, HTML veya app ekranından bunu görebilir?
- Hangi task çıktı dosyası site-visible sonucu destekliyor?
- Hangi kanıtla doğrulandı?

## 5. Şartlı %100 kabul kapısı

Codex ancak aşağıdaki tüm koşullar sağlanırsa `%100` veya `final_ready=true` yazabilir:

1. `queue_started=true`
2. `runner_output_uploaded=true`
3. `PUSH_SYNC_OK=true`
4. `runner_exit_code=0`
5. Fresh `aays1/status` dosyası var.
6. Fresh `aays1/reports` dosyası var.
7. Fresh `aays1/heartbeat` dosyası var.
8. Readable runner output JSON var.
9. `046` recovery çıktısı var.
10. `044` accuracy expansion çıktısı var veya net blocker raporu var.
11. TerraYield/AAYS site-visible çıktı güncellendi veya eksik path raporu var.
12. Safety flags değişmedi:
    - `fake_data=false`
    - `db_write=false`
    - `migration=false`
    - `production_deploy=false`
13. Sahte completed yok.
14. Sahte progress yok.
15. Kullanıcıya “devam et” ile aynı PAGE_KEY altında devam edilebilir durum bırakıldı.

Bu koşullardan biri eksikse:

- `completion_percent=100` yazma.
- `final_ready=true` yazma.
- `completed` marker yazma.
- `final_ready=false` bırak.
- `blocker=<eksik koşul>` yaz.

## 6. Codex’e son direktif

Runner sağlıklı demek tek başına yeterli değildir.

Codex şu sırayla işi bitirmelidir:

1. Shared stable runner kanıt zincirini GitHub’da görünür yap.
2. `aays1` valid queue task oluştur veya blocked task’ı doğru şekilde obsolete/blocker olarak raporla.
3. Gerçek automation script ile `046` recovery ve `044` accuracy expansion işini çalıştır.
4. Fresh status/report/heartbeat/runner output üret.
5. TerraYield/AAYS program/site-visible çıktıyı güncelle veya eksik path’leri açıkça raporla.
6. Bütün acceptance gate’ler geçmeden `%100`, `completed`, `final_ready=true` yazma.

## 7. Beklenen final çıktı

Başarılı finalde GitHub’da şu özet görülecek:

```text
PAGE_KEY=aays1
runner_exit_code=0
queue_started=true
runner_output_uploaded=true
PUSH_SYNC_OK=true
046_recovery_output=present
044_accuracy_expansion_output=present_or_blocked_with_reason
site_visible_output=updated_or_missing_paths_reported
fake_data=false
db_write=false
migration=false
production_deploy=false
final_ready=<only true if every gate passed>
```
