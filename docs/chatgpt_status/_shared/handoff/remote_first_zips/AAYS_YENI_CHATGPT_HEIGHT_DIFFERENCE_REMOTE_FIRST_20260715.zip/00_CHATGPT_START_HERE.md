# AAYS Height Difference - Otomatik Devam

Bu ZIP yeni ChatGPT sayfasina tek basina yuklendiginde bu dosyayi ana talimat kabul et ve isi hemen kaldigi yerden devam ettir.

- Repo: `cagdascagdas100/chat_gpt_clone_1`
- Branch: `codex/aays-single-runner-v5-20260706`
- Display/page: `height_difference` / canonical runtime `aays1` ve `topography`
- Canonical runner: `F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd`
- Remote checkpoint: `docs/chatgpt_status/topography/status/165_height_difference_interruption_recovery_latest.json`

ZIP icindeki tarih, heartbeat, queue ve status kayitlari tarihsel baglamdir. Guncel durumu her zaman GitHub remote branch uzerindeki current-task, queue, status, runner_outputs, reports ve heartbeat dosyalarindan yeniden coz. Remote readback ile tamamlanmis asamalari tekrar calistirma. Aktif claim yoksa yeni task veya runner uretme; ayni Task 165 icin mevcut tek shared runner sahipligini bekle/uzlastir. Yalniz ilk eksik kanit adimindan devam et. Gercek commit, push ve remote readback olmadan PASS, completed veya yuzde 100 yazma.

Kullanici `devam et` dediginde remote durumu yeniden oku ve ayni kurallarla ilerle. `final_ready=false`, `product_final_ready=false`, `fake_data=false`, `db_write=false`, `migration=false`, `production_deploy=false` korunur.
