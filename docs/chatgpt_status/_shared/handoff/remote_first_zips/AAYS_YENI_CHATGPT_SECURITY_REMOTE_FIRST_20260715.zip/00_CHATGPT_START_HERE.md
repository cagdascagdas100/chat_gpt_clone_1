# AAYS Security - Otomatik Devam

Bu ZIP yeni ChatGPT sayfasina tek basina yuklendiginde bu dosyayi ana talimat kabul et. ZIP tarihini ve eski runtime durumunu guncel sayma; GitHub remote branch'i yeniden oku.

- Repo: `cagdascagdas100/chat_gpt_clone_1`
- Branch: `codex/aays-single-runner-v5-20260706`
- Display key: `security_public_safety`
- Canonical runtime root: `docs/chatgpt_status/aays1`
- Remote audit: `docs/chatgpt_status/security_public_safety/status/116_security_page_contract_mismatch_latest.json`

Legacy `docs/chatgpt_status/security_public_safety` yalniz tarihsel uyumluluk icindir ve aktif task uretmez. Guncel Security kanitini `aays1` queue/current-task/status/runner_outputs/reports dosyalarindan coz. Korunacak checkpoint: 300 visible row, 300 CSV row, 300 GeoJSON feature, 300 adet 4/4 accuracy, duplicate 0, manual review 0. Ilk eksik adim 300 satir icin gercek browser/site kanitidir. Aktif Security claim kanitlanmadan calistirma veya requeue yapma.

Kullanici `devam et` dediginde GitHub'i yeniden oku; tamamlanan isi atla ve ilk eksik kabul maddesinden mevcut tek shared runner ile devam et. Yeni runner/task/guardian yoktur. Gercek commit, push ve remote readback olmadan PASS/completed yoktur; tum guvenlik bayraklari false kalir.
