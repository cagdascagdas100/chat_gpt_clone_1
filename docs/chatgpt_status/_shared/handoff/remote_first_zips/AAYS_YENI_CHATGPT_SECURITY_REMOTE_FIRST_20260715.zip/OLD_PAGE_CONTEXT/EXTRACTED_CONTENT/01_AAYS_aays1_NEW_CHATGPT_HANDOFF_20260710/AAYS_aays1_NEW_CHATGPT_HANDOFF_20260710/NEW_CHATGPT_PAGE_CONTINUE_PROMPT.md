# AAYS / aays1 — Yeni ChatGPT Sayfası Devam Promptu

Bu ZIP paketini oku ve sadece devralınan işe odaklan: **aays1 / Safety-Security / Security Level percent**.

## Sabit proje bilgileri

Repo: `cagdascagdas100/chat_gpt_clone_1`  
Branch: `codex/aays-single-runner-v5-20260706`  
PAGE_KEY: `aays1`  
Layer: `Safety / Security`  
Program output: `Security Level percent`

Canonical runner:
`F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd`

Canonical repo:
`F:\TerraYield_AAYS_Portable\runner_system\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707`

Canonical work root:
`F:\TerraYield_AAYS_Portable\runner_system\AAYS_WT\AAYS_STABLE_RUNNER_WORKTREES`

## Kesin kurallar

- Yeni runner açma.
- Paralel runner isteme.
- `C:\` canonical kabul etme.
- F portable tek shared runner kullanılacak.
- Sahte completed yazma.
- Sahte `%100` yazma.
- Sahte `final_ready=true` yazma.
- `final_ready=false` kalacak; gerçek browser/site/runner proof olmadan değişmeyecek.
- `fake_data=false`, `db_write=false`, `migration=false`, `production_deploy=false` kalacak.
- Gerçek GitHub proof/output olmadan metrik artırma.
- Geometri kanıtı yoksa `geometry:null` kullan; geometri uydurma.
- Kişi bazlı suç/verisi kullanma.
- Resmi/open internet kaynaklarını kullan. Bu katmanda ana kaynak akışı: `data.police.uk official/open API + verified LSOA spatial match`.
- Cevapları kısa ver.

## Kullanıcı “devam” dediğinde ilk yapılacak kontrol

Önce GitHub’dan şu runner proof dosyalarını oku:

```text
docs/chatgpt_status/aays1/status/134_f_portable_one_click_recovery_test_latest.json
docs/chatgpt_status/aays1/status/130_f_portable_one_click_recovery_bootstrap_latest.json
docs/chatgpt_status/_shared/heartbeat/stable_runner_daemon_heartbeat_latest.json
docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json
docs/chatgpt_status/_shared/locks/single_runner.lock
```

Sağlıklı kabul şartı:

```text
runner_active=true
pid_alive=true
lock_valid=true
git_push_status=pushed
final_ready=false
fake_data=false
db_write=false
migration=false
production_deploy=false
```

Eğer runner aktif değilse sadece şunu söyle:

```text
F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd dosyasına çift tıkla, sonra bu sayfaya devam yaz.
```

Eğer runner aktifse sadece `aays1` page_key işlerini takip et.

## Öncelikli output kontrolleri

Önce 136 roundtrip output var mı kontrol et:

```text
docs/chatgpt_status/aays1/runner_outputs/136_runner_github_roundtrip_test.json
```

Sonra gerçek iş outputlarını kontrol et:

```text
docs/chatgpt_status/aays1/runner_outputs/104_visible_expansion_orchestrator.json
docs/chatgpt_status/aays1/runner_outputs/103_security_accuracy_count_expansion.json
docs/chatgpt_status/aays1/runner_outputs/102_real_visible_security_site_bridge.json
```

Bunlar yoksa:
- final/%100 verme.
- `final_ready=false` bırak.
- Açıkça “136/104 runner output hâlâ yok” de.
- Veri/site tarafını kontrollü şekilde genişletmeye devam edebilirsin.

## Site-visible dosyalar

Web/site görünür çıktıların ana yolları:

```text
england_map_web/data/program_layer_matrix/security_public_safety_visible_rows.json
england_map_web/data/program_layer_matrix/security_public_safety_visible_status.json
outputs/england_program_parcel_matrix_20260629/security_public_safety_updates/latest_changes.json
england_map_web/data/security_public_safety/parcel_security_scores_verified.csv
england_map_web/data/security_public_safety/parcel_security_scores_verified.geojson
england_map_web/data/security_public_safety/security_evidence_manifest.json
```

Son doğrulanmış durum:
- Toplam verified havuz: `150`
- Site-visible sample rows: `24`
- Doğruluk: `24/24 accuracy_score_4 = 4`
- Manual review: `0`
- Kaynak: `data.police.uk official/open API + verified LSOA spatial match`
- `final_ready=false`
- `fake_data=false`
- `db_write=false`
- `migration=false`
- `production_deploy=false`

## Devam stratejisi

1. Proof dosyalarını oku.
2. 136 roundtrip output var mı bak.
3. 104/103/102 output var mı bak.
4. Output yoksa bunu açıkça belirt; final yazma.
5. Site-visible rows dosyasını verified CSV’den kontrollü artır:
   - 24 → 32 → 40 → 50 → 75 → 100 → 150
   - Her satırda `accuracy_score_4=4`, `needs_manual_review=false`, resmi LSOA kanıtı olmalı.
6. Web sitesinde satır satır görülecek dosya:
   `england_map_web/data/program_layer_matrix/security_public_safety_visible_rows.json`
7. Status dosyasındaki sayaçları güncelle:
   `visible_sample_rows`, `verified_csv_rows`, `accuracy_ge_3_count`, `manual_review_count`.
8. Gerçek runner output gelirse onu esas al; gelmezse site-visible veri genişletmesini “pending browser smoke” olarak sürdür.

## Kısa cevap formatı

Sıkıntı yoksa:

```text
Yapılan ilerleme:
- Görünür satır:
- Aday/satır:
- Doğruluk:
- Kaynak:
- Manual review:
- Toplam verified havuz:
- Genel işlem:
- Yüzde artışı:
- Bekleme:
- Sonraki devam:
```

Sıkıntı varsa:

```text
Sıkıntı:
Net sebep:
Yapılan düzeltme:
Beklenen output:
final_ready=false
```

## Şu anda bilinen blocker

```text
136/104 runner output hâlâ GitHub’da görünmeyebilir.
Final için local 127.0.0.1:8020 Security layer button, thematic colors, legend, popup/right-panel smoke proof gerekiyor.
```
