# CHATGPT'YE YAPISTIRILACAK FINAL PROMPT

Bu ZIP icindeki tum dosyalari oku. Ana kapsam yalnizca AAYS/TerraYield `Safety / Security` katmanidir.

## Sabitler

Repo:

```text
cagdascagdas100/chat_gpt_clone_1
```

Aktif local F repo:

```text
F:\chatgpt\chat_gpt_clone_1_main
```

Yardimci C repo:

```text
C:\Users\cagda\Documents\GitHub\AAYS
```

Tek shared runner / bridge:

```text
F:\AAYS_GITHUB_BRIDGE_CLEAN2
```

Program:

```text
http://127.0.0.1:8010/england_map_web/
```

Matrix kontrol sayfasi:

```text
http://127.0.0.1:8020/TerraYield_England_Program_Parcel_Layer_Matrix_20260629.html?refresh=20260630-final
```

## Katman

```text
Layer name: Safety / Security
Program output: Security Level percent
```

## Senin gorevin

Kullanici sadece `devam` diyecek. Her devam turunda su zinciri kullanilacak:

```text
GitHub/F repo dosyalarini oku
-> docs/chatgpt_status/security_public_safety/queue altindaki task'i kontrol et
-> tek shared runner icin F bridge pending queue sozlesmesine uygun guncelleme yap
-> runner sonuc raporlarini oku
-> eksik batch veya eksik kanit varsa bir sonraki task'i kucuk ve guvenli yaz
-> sonucu GitHub repo raporu olarak yazdir
-> site-visible latest_changes.json dosyasini guncel tut
```

## Zorunlu dosya ve yollar

Runner task template:

```text
docs/chatgpt_status/security_public_safety/queue/security_public_safety_batch_template.task.json
```

Runner script template:

```text
docs/chatgpt_status/security_public_safety/automation/security_public_safety_batch_runner_TEMPLATE.ps1
```

Progress report template:

```text
docs/chatgpt_status/security_public_safety/reports/security_public_safety_progress_latest_TEMPLATE.md
```

Sitede gorunen kucuk degisiklik dosyasi:

```text
outputs/england_program_parcel_matrix_20260629/security_public_safety_updates/latest_changes.json
```

Bu dosya gercek batch islendikce guncellenmelidir. Sahte veri ile doldurma.

## Beklenen veri ciktilari

Gercek ciktilar F repo icinde su klasore yazilmalidir:

```text
F:\chatgpt\chat_gpt_clone_1_main\england_map_web\data\security_public_safety\
```

Beklenen dosyalar:

```text
parcel_security_scores_verified.geojson
parcel_security_scores_verified.csv
security_evidence_manifest.json
security_public_safety_batch_report_<timestamp>.md
```

## Skor modeli

Her parcel icin:

```text
security_score_percent = 0-100
security_level = Very Low Security | Low Security | Medium Security | Good Security | Very Good Security
accuracy_score_4 = 0-4
accuracy_label_4 = Very High Accuracy | High Accuracy | Medium Accuracy | Low Accuracy | No Evidence / Unknown
```

Skor yuksekse bolge daha guvenli kabul edilir.

## Kaynak kurallari

Kullan:

- resmi polis / public safety aggregate istatistikleri,
- Police.uk veya resmi police force/open data,
- local authority community safety raporlari,
- ONS/LSOA/MSOA/local-authority aggregate kaynaklari,
- police station / public safety facility yakinligi,
- harita tabanli konum ve bolge kaniti,
- AI assurance: kaynak-tutarlilik kontrolu.

Kullanma:

- kisi bazli veri,
- supheli/suclu kisi bilgisi,
- sosyal medya dedikodusu,
- ucretli veya izin gerektiren kaynaklari zorla alma,
- fake data.

## Dogruluk hedefi

Minimum yayinlanabilir hedef:

```text
accuracy_score_4 >= 3
```

AI kontrolu eklenirse guven artabilir, ancak AI kontrolu tek basina resmi kaynak yerine gecmez.

Kaynaklar celisirse:

```text
ai_assurance_result=CONFLICT
needs_manual_review=true
final_ready=false
```

## Site kontrol zorunlulugu

Her devam turundan sonra matrix sayfasinda `Security / Public Safety - Guncel Degisiklikler` paneli guncel olmalidir:

```text
http://127.0.0.1:8020/TerraYield_England_Program_Parcel_Layer_Matrix_20260629.html?refresh=20260630-final
```

Bu panel `latest_changes.json` dosyasini okur. Kullanici burada son degisiklikleri gormelidir.

## Final kabul

`final_ready=true` sadece su kanitlar varsa yaz:

1. Security butonu dogru parcel-based thematic layer acar.
2. Haritada parcel polygonlari bes seviyeye gore renklidir.
3. Parcel tiklaninca sag panel/popup su alanlari gosterir:
   - security_score_percent
   - security_level
   - color_category
   - data sources/evidence
   - source date
   - accuracy_score_4 / accuracy_label_4
   - matching_method
   - calculation_explanation
4. Site matrix `latest_changes.json` uzerinden son guncellemeleri gosterir.
5. Fake data yoktur.

Eksik varsa final_ready=false kalir ve eksigi net raporla.
