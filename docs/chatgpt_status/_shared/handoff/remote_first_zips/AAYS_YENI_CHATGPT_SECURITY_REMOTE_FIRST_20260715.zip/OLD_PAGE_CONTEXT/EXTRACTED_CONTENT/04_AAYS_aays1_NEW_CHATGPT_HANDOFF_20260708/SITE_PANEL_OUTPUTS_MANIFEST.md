# Site / panel outputs manifest

Verified site-visible status/report outputs under `docs/chatgpt_status/aays1/` are included:

- `github_evidence/docs/chatgpt_status/aays1/status/aays1_site_visible_current_status_latest.json`
- `github_evidence/docs/chatgpt_status/aays1/reports/aays1_visible_program_sync_20260708.md`
- `github_evidence/docs/chatgpt_status/aays1/runner_outputs/aays1_visible_program_sync_20260708_runner_output.txt`

No concrete `england_map_web` product data/UI change was independently verified in this page. If the next page needs actual website/panel change, Codex must locate and modify the relevant `england_map_web` files and include a changed-file list.
