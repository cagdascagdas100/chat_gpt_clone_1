# SAFETY_CONTRACT

- No fake data.
- No fabricated geometry.
- No person-level crime/person/suspect data.
- No DB write.
- No migration.
- No production deploy.
- No fake completed.
- No fake %100.
- No fake final_ready=true.
- Only official/open aggregate public safety sources.
- If geometry is missing, use geometry:null.
- final_ready=false until browser/site/runner proof is real.
