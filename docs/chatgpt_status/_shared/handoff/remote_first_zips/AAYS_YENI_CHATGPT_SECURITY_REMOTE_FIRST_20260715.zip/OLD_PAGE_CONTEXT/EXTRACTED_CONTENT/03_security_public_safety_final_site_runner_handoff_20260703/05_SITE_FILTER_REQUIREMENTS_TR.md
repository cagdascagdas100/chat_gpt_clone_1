# Site Katman ve Filtre Gereksinimleri

## Security butonu

Harita kontrolunde Security butonu bulunmali.

Tiklama davranisi:

```text
first_click = layer on
second_click = layer off
active_state = visible
```

## Harita stilleri

```text
Very Low Security  = red
Low Security       = orange
Medium Security    = yellow
Good Security      = light green
Very Good Security = dark green
No Data            = gray / transparent
```

## Popup / sag panel zorunlu alanlari

```text
Parcel ID
Security Score Percent
Security Level
Color Category
Crime Rate Index
Incident Density Index
Police Station Distance
Neighborhood Safety Index
Official Source Evidence
Web Source Evidence
Map Source Evidence
AI Assurance Summary
Source Date
Source Geography Level
Matching Method
Calculation Method
Calculation Explanation
Confidence Score / Label
Accuracy Score / Label
Conflict Status
Manual Review
```

## Guncel degisiklikler filtresi

Yeni filtre:

```text
Guncel degisiklikler
```

Filtre aktifken:

```text
changed_in_latest_run=true
```

Panelde su alanlar gorunsun:

```text
last_updated
change_reason
previous_security_score_percent
new_security_score_percent
previous_security_level
new_security_level
previous_accuracy_score_4
new_accuracy_score_4
```

## Kullanici mesaji

Eger veri yetersizse:

```text
Bu parcel icin Safety / Security verisi 3/4 dogruluk esigine ulasmadi. Manuel inceleme onerilir.
```
