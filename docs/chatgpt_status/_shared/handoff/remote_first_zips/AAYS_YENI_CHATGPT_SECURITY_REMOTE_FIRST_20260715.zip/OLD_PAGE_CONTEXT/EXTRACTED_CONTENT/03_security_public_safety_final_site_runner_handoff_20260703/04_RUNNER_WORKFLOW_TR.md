# Tek Runner Is Akisi

## Page key

```text
security_public_safety
```

## F repo

```text
F:\chatgpt\chat_gpt_clone_1_main
```

## Queue dosyasi

```text
F:\chatgpt\chat_gpt_clone_1_main\docs\chatgpt_status\security_public_safety\queue\<task_id>.task.json
```

## Live runner queue

```text
C:\AAYS_GITHUB_BRIDGE_CLEAN2\ai-queue\pending\<task_id>.task.json
```

## Task JSON ornegi

```json
{
  "task_id": "security_public_safety_batch_001",
  "page_key": "security_public_safety",
  "script_path": "F:\\chatgpt\\chat_gpt_clone_1_main\\docs\\chatgpt_status\\security_public_safety\\automation\\security_public_safety_batch_runner.ps1",
  "result_path": "C:\\AAYS_GITHUB_BRIDGE_CLEAN2\\ai-results\\security_public_safety_batch_001.result.json",
  "repo_result_path": "F:\\chatgpt\\chat_gpt_clone_1_main\\docs\\chatgpt_status\\security_public_safety\\reports\\security_public_safety_batch_001.md",
  "status": "pending",
  "priority": 90,
  "db_write": false,
  "ddl": false,
  "migration": false,
  "production_deploy": false,
  "fake_data": false
}
```

## Devam mantigi

ChatGPT sayfasinda kullanici `devam` dediginde:

1. Son progress raporunu oku.
2. Eksik batch veya manuel review listesini belirle.
3. Yeni task dosyasini repo queue ve live pending klasorune yaz.
4. Tek runner sonucu uretene kadar bekle.
5. Raporu oku.
6. Siteye yansiyan dosyalari kontrol et.
7. Bir sonraki batch icin devam et.

## Final degilse

```text
final_ready=false
remaining_blockers=<liste>
next_single_action=<tek is>
```

Sahte `final_ready=true` yazma.
