# Veri Dogruluk ve Guven Skalasi - 4 Uzerinden

## Etiketler

```text
0.00 - 0.99 = No Evidence / Unknown
1.00 - 1.99 = Low Accuracy
2.00 - 2.99 = Medium Accuracy
3.00 - 3.49 = High Accuracy
3.50 - 4.00 = Very High Accuracy
```

## Kaynak katkisi

```text
official_police_or_government_source = +1.50
official_local_authority_safety_report = +1.00
open_aggregate_crime_dataset = +1.00
police_station_or_public_safety_facility_match = +0.50
map_based_location_match = +0.40
source_date_recent = +0.30
ai_consistency_assurance = +0.50
multiple_independent_sources = +0.30
high_precision_geography_lsoa_or_better = +0.50
```

## Sinirlar

```text
only_ai_assurance_max = 1.50
only_map_source_max = 2.00
only_one_aggregate_source_max = 2.75
official_source_plus_location_match_max = 3.00
official_source_plus_ai_assurance_max = 3.50
multiple_official_sources_plus_ai_max = 4.00
source_conflict_max = 2.75
unknown_max = 0.99
```

## Cezalar

```text
source_conflict = -1.00
ai_source_conflict = -0.75
geography_too_broad = -0.50
source_date_stale = -0.25
weak_parcel_match = -0.50
```

Skor her zaman `0 <= accuracy_score_4 <= 4` olacak.
