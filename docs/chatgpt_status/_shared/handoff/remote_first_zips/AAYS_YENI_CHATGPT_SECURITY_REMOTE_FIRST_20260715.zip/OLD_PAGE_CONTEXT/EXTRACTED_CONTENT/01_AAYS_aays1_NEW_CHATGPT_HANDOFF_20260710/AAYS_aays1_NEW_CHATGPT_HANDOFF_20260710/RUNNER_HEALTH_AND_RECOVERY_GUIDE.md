# RUNNER_HEALTH_AND_RECOVERY_GUIDE

## Normal kontrol

Yeni sayfada kullanıcı `devam` dediğinde önce şu dosyaları GitHub’dan oku:

```text
docs/chatgpt_status/aays1/status/134_f_portable_one_click_recovery_test_latest.json
docs/chatgpt_status/aays1/status/130_f_portable_one_click_recovery_bootstrap_latest.json
docs/chatgpt_status/_shared/heartbeat/stable_runner_daemon_heartbeat_latest.json
docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json
docs/chatgpt_status/_shared/locks/single_runner.lock
```

Sağlıklı kabul:

```text
runner_active=true
pid_alive=true
lock_valid=true
git_push_status=pushed
final_ready=false
fake_data=false
db_write=false
migration=false
production_deploy=false
```

## Sağlıklı değilse

Sadece şunu söyle:

```text
F:\TerraYield_AAYS_Portable\RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd dosyasına çift tıkla, sonra bu sayfaya devam yaz.
```

## Sağlıklıysa

1. 136 output kontrolü: `docs/chatgpt_status/aays1/runner_outputs/136_runner_github_roundtrip_test.json`
2. 104 output kontrolü: `docs/chatgpt_status/aays1/runner_outputs/104_visible_expansion_orchestrator.json`
3. 103/102 output kontrolü:
   - `docs/chatgpt_status/aays1/runner_outputs/103_security_accuracy_count_expansion.json`
   - `docs/chatgpt_status/aays1/runner_outputs/102_real_visible_security_site_bridge.json`

## Bilinen sorun

Proof dosyaları runner’ı aktif gösterse bile `processed_task_count=0` görünebilir. Bu durumda runner canlı ama task pickup/roundtrip kanıtı eksiktir. Final verme.
