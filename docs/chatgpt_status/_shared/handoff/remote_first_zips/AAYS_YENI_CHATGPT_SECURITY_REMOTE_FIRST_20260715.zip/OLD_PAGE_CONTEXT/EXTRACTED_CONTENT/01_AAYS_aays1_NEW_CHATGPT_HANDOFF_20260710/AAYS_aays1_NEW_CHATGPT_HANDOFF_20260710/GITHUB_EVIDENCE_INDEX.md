# GITHUB_EVIDENCE_INDEX

## Runner proof dosyaları

```text
docs/chatgpt_status/aays1/status/134_f_portable_one_click_recovery_test_latest.json
docs/chatgpt_status/aays1/status/130_f_portable_one_click_recovery_bootstrap_latest.json
docs/chatgpt_status/_shared/heartbeat/stable_runner_daemon_heartbeat_latest.json
docs/chatgpt_status/_shared/status/runner_bootstrap_latest.json
docs/chatgpt_status/_shared/locks/single_runner.lock
```

Son doğrulanan proof özeti:
- `runner_active=true`
- `pid=10108`
- `pid_alive=true`
- `lock_valid=true`
- `git_push_status=pushed`
- `processed_task_count=0`
- `final_ready=false`
- `fake_data=false`
- `db_write=false`
- `migration=false`
- `production_deploy=false`

## Runner output kontrol edilecek dosyalar

```text
docs/chatgpt_status/aays1/runner_outputs/136_runner_github_roundtrip_test.json
docs/chatgpt_status/aays1/runner_outputs/104_visible_expansion_orchestrator.json
docs/chatgpt_status/aays1/runner_outputs/103_security_accuracy_count_expansion.json
docs/chatgpt_status/aays1/runner_outputs/102_real_visible_security_site_bridge.json
```

Son durum: `Not Found` olabilir; bu final blocker’dır.

## Site-visible dosyalar

```text
england_map_web/data/program_layer_matrix/security_public_safety_visible_rows.json
england_map_web/data/program_layer_matrix/security_public_safety_visible_status.json
outputs/england_program_parcel_matrix_20260629/security_public_safety_updates/latest_changes.json
```

## Verified source data

```text
england_map_web/data/security_public_safety/parcel_security_scores_verified.csv
england_map_web/data/security_public_safety/parcel_security_scores_verified.geojson
england_map_web/data/security_public_safety/security_evidence_manifest.json
```

## Runner chain / queue files

```text
RUN_AAYS_STABLE_RUNNER_FROM_THIS_DISK.cmd
docs/chatgpt_status/_shared/automation/RUN_EXISTING_F_PORTABLE_SINGLE_RUNNER_HOTFIX_THEN_CONTINUE_20260709.cmd
docs/chatgpt_status/_shared/automation/RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707.ps1
docs/chatgpt_status/aays1/queue/135_force_pickup_visible_expansion_20260709.task.json
docs/chatgpt_status/aays1/queue/136_runner_github_roundtrip_test_20260709.task.json
docs/chatgpt_status/aays1/automation/136_runner_github_roundtrip_test.ps1
```
