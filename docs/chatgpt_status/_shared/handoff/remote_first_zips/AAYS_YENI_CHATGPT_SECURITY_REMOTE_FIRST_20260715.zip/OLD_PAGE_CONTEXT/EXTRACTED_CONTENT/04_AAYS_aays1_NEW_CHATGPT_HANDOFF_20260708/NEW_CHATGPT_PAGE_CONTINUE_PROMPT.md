# AAYS / aays1 New ChatGPT Page Continue Prompt

Bu ZIP paketini oku ve aynı iş akışını devral.

## Sabit bilgiler

PAGE_KEY: `aays1`
Repo/worktree: `C:\AAYS_WT\AAYS_RUNNER_HEALTHY_20260707`
Branch: `codex/aays-single-runner-v5-20260706`
Başlatıcı: `C:\Users\cagda\Documents\GitHub\AAYS\START_AAYS_RUNNER.bat`
Runner: `RUN_SINGLE_AAYS_MULTI_PAGE_QUEUE_RUNNER_STABLE_20260707`

## Mutlak kurallar

- Yeni runner açma.
- Paralel runner açma.
- Aynı PAGE_KEY ile devam et: `aays1`.
- Mevcut stable shared runner kullanılacak.
- `final_ready=true` yazma; sadece gerçek GitHub kanıtı varsa.
- Sahte completed yazma.
- Sahte %100 yazma.
- GitHub kanıtı olmadan metrik artırma.
- fake_data=false, db_write=false, migration=false, production_deploy=false kalacak.

## İlk yapılacak okuma sırası

1. `HANDOFF_SUMMARY.md`
2. `MISSING_ORIGINAL_ATTACHMENT_MANIFEST.md`
3. `github_evidence/_shared/status/runner_bootstrap_latest.json`
4. `github_evidence/_shared/status/stable_runner_daemon_latest.json`
5. `github_evidence/_shared/status/MULTI_PAGE_latest_status.json`
6. `github_evidence/docs/chatgpt_status/aays1/status/aays1-real-product-evidence-fetch-20260707_completed.json`
7. `github_evidence/docs/chatgpt_status/aays1/reports/aays1-real-product-evidence-fetch-20260707_runner_output.txt`
8. `github_evidence/docs/chatgpt_status/aays1/automation/065_parallel_source_evidence_batch.ps1`

## Devam mantığı

Kullanıcı sadece `devam et` derse:

1. Önce GitHub connector üzerinden repo/branch dosyalarını doğrula.
2. `docs/chatgpt_status/aays1/queue/`, `status/`, `reports/`, `heartbeat/`, `runner_outputs/`, `automation/` dosyalarını oku.
3. Pending/queued valid task varsa runner pickup kanıtını kontrol et.
4. Valid task yoksa kendi PAGE_KEY altında sözleşmeye uygun yeni queue task yaz; ama implementation yoksa önce implementation blocker raporu yaz.
5. `065_parallel_source_evidence_batch.ps1` hâlâ placeholder ise asıl yapılacak iş onu gerçek ürün/evidence implementation’a çevirmektir.
6. Site/panel görünürlüğü gerekiyorsa ilgili `england_map_web` dosyalarını bul, değiştir, değişen dosyaları final raporda listele.
7. Her tur kullanıcıya kısa özet ver:
   - Yapılan işlemler
   - Genel yüzde
   - Bu tur artış
   - Bekleme süresi
   - Blocker varsa blocker

## Mevcut blocker

`AAYS1_065_BLOCKED_REAL_SOURCE_FETCH_IMPLEMENTATION_REQUIRED`

Anlamı: runner çalışıyor; ürün/evidence fetch implementation eksik.

## Doğru bir sonraki hedef

Codex/ChatGPT artık runner tamiriyle vakit kaybetmemeli. Hedef:

- `aays1 current_task` sözleşmesini oluşturmak veya mevcut plan dosyasını bulmak.
- `065` placeholder scriptini gerçek AAYS/TerraYield ürün/evidence/site-visible implementation’a çevirmek.
- Geçerli queue task yazmak.
- Runner’ın işlediğini GitHub kanıtıyla doğrulamak.
- Gerekirse `england_map_web` dosyalarını güncellemek.

## Çıktı formatı

Kısa cevap ver:

- Runner durumu:
- Yapılan işlemler:
- Genel işlem: `%...`
- Bu tur artış: `+...%`
- Bekleme: `... dk`
- Blocker:
