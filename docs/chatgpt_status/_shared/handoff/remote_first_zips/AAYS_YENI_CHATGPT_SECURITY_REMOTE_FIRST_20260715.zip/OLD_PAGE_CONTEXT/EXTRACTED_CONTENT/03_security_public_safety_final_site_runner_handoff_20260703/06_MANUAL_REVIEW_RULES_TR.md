# Manuel Inceleme Kurallari

## Manuel incelemeye ayrilacak kayitlar

```text
accuracy_score_4 < 3.0
source_geography_level too broad
crime/security sources conflict
AI assurance says inconsistent
parcel-location match weak
source date missing or stale
official source unavailable
```

## Problem raporu kolonlari

```text
parcel_id
candidate_security_score_percent
candidate_security_level
official_source_result
web_source_result
map_source_result
ai_assurance_result
conflict_status
accuracy_score_4
missing_evidence
manual_question
source_links_or_files
suggested_next_action
```

## Otomatik cozum onceligi

1. Resmi aggregate kaynak daha yuksek agirlik alir.
2. Daha guncel ve daha kucuk geography seviyesi daha yuksek agirlik alir.
3. AI guvencesi kaynaklarla uyumluysa accuracy artar.
4. AI guvencesi kaynaklarla celisirse accuracy duser ve manuel review acilir.
5. Cok genis geography seviyesi varsa skor verilebilir ama confidence dusuk olur.

## Gizlilik

Bu katman kisi veya hane bazli guvenlik degerlendirmesi yapmaz. Sokak/mahalle/LSOA/MSOA/local-authority gibi aggregate kamu guvenligi sinyali verir.
