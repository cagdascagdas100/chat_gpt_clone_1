# Safety / Security - Veri Sozlesmesi

## CSV kolonlari

```text
parcel_id
security_score_percent
security_level
security_color_category
crime_rate_index
incident_density_index
police_station_distance_m
neighborhood_safety_index
official_source_evidence
web_source_evidence
map_source_evidence
ai_assurance_summary
ai_assurance_result
source_date
source_geography_level
matching_method
calculation_method
calculation_explanation
confidence_score_4
confidence_label_4
accuracy_score_4
accuracy_label_4
conflict_status
needs_manual_review
last_updated
changed_in_latest_run
change_reason
```

## GeoJSON zorunlu alanlari

```text
type=FeatureCollection
features[].type=Feature
features[].geometry
features[].properties.parcel_id
features[].properties.security_score_percent
features[].properties.security_level
features[].properties.accuracy_score_4
features[].properties.source_geography_level
```

## Security level sozlesmesi

```text
0-20   = Very Low Security
21-40  = Low Security
41-60  = Medium Security
61-80  = Good Security
81-100 = Very Good Security
null   = No Data
```

## Rapor alanlari

Her batch raporu su alanlari icermeli:

```text
page_key=security_public_safety
task_id=<id>
run_started_at=<iso>
run_finished_at=<iso>
input_rows=<number>
processed_rows=<number>
verified_rows=<number>
manual_review_rows=<number>
accuracy_ge_3_rows=<number>
accuracy_lt_3_rows=<number>
no_data_rows=<number>
geojson_output=<path>
csv_output=<path>
manifest_output=<path>
manual_review_output=<path>
fake_data=false
db_write=false
ddl=false
migration_apply=false
prod_deploy=false
next_batch=<description>
```
