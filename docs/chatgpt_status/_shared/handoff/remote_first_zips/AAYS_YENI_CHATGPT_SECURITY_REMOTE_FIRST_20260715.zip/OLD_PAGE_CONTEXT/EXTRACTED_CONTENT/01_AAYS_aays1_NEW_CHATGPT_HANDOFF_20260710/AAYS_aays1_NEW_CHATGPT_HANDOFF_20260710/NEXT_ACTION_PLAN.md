# NEXT_ACTION_PLAN

## Önce

- Proof dosyalarını kontrol et.
- 136/104 output var mı bak.
- Yoksa final verme.

## Veri/site tarafında devam

Görünür satır dosyası:
`england_map_web/data/program_layer_matrix/security_public_safety_visible_rows.json`

Şu an:
- 24/150 satır görünür.
- 24/24 accuracy 4/4.

Sıradaki artış planı:
1. 24 → 32
2. 32 → 40
3. 40 → 50
4. 50 → 75
5. 75 → 100
6. 100 → 150

Her artışta:
- official_source_evidence dolu olmalı.
- source_date dolu olmalı.
- accuracy_score_4 = 4 tercih edilmeli.
- needs_manual_review=false olmalı.
- fake_data=false kalmalı.
- final_ready=false kalmalı.

## Final için gerekenler

- 136 runner roundtrip GitHub output
- 104 gerçek iş output
- 8020 local browser smoke: Security button, thematic colors, legend, popup/right-panel fields
