# Security Level Percent Model

## Ana skor

```text
security_score_percent = 0-100
```

Skor yuksekse bolge daha guvenli kabul edilir.

## Ornek faktorler

```text
crime_rate_index
incident_density_index
violent_crime_index
anti_social_behavior_index
burglary_index
police_station_distance_m
neighborhood_safety_index
source_recency_score
geography_precision_score
```

## Onerilen agirliklar

```text
crime_rate_index = 30%
incident_density_index = 25%
violent_or_serious_crime_index = 15%
police_station_proximity = 10%
neighborhood_safety_index = 10%
source_recency_and_reliability = 10%
```

Not:

Bu agirliklar ilk surum icin oneridir. Daha iyi resmi kaynak veya validasyon gelirse raporda degisiklik aciklanarak guncellenebilir.

## Seviyeler

```text
0-20   Very Low Security
21-40  Low Security
41-60  Medium Security
61-80  Good Security
81-100 Very Good Security
```

## Hesaplama aciklamasi

Her parcel icin `calculation_explanation` insan tarafindan okunur olmali:

```text
Security score was calculated from official/aggregate crime density, local public safety indicators, police station proximity, geography precision, source date, and AI consistency review. This is a parcel-location public-safety signal, not an individual risk assessment.
```
