# ZIP Contents Index

- `HANDOFF_SUMMARY.md` — full handoff state.
- `NEW_CHATGPT_PAGE_CONTINUE_PROMPT.md` — prompt to paste into a new ChatGPT page.
- `MISSING_ORIGINAL_ATTACHMENT_MANIFEST.md` — original attachment availability note.
- `ACCESSIBLE_ATTACHMENT_MANIFEST.md` — copied local upload list.
- `attachments_accessible_in_sandbox/` — all accessible uploaded/local files from `/mnt/data`.
- `github_evidence/` — reconstructed GitHub evidence files and summaries.
- `SITE_PANEL_OUTPUTS_MANIFEST.md` — site-visible output status.
