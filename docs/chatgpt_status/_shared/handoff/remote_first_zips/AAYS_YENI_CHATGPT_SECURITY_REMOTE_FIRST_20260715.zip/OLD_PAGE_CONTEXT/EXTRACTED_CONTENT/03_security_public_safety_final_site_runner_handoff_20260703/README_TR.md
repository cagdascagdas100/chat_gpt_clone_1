# AAYS / TerraYield - Safety / Security ChatGPT Handoff

Bu paket, `Safety / Security` katmanini ayri bir ChatGPT sayfasinda ilerletmek icin hazirlandi.

Ana hedef:

- Her parcel icin konum tabanli public-safety / police-security yuzde skoru uretmek.
- Sonucu bes seviyeli guvenlik sinifina cevirmek.
- Kaynaklari resmi/acik/aggregate veriyle kanitlamak.
- AI guvencesini kaynak tutarliligi ve hesaplama denetimi icin kullanmak.
- 3/4 veya uzeri veri dogrulugu hedeflemek.
- Tek shared runner uzerinden F repo -> runner -> rapor -> ChatGPT devam akisini korumak.
- Sitede `Guncel degisiklikler` filtresiyle son guncellenen parcel kayitlarini gostermek.

Onemli sinir:

Bu katman bireyler hakkinda guvenlik/kriminal degerlendirme yapmaz. Yalnizca bolge, sokak, mahalle, LSOA/MSOA, local authority veya resmi aggregate kamu guvenligi verilerini kullanir.

Dosyalar:

- `00_CHATGPT_PROMPT_TR.md`: ChatGPT sayfasina yapistirilacak ana prompt.
- `01_DATA_CONTRACT_TR.md`: CSV/GeoJSON/rapor veri sozlesmesi.
- `02_SECURITY_SCORE_MODEL_TR.md`: Security Level percent ve bes seviyeli siniflama.
- `03_ACCURACY_SCALE_TR.md`: 4 uzerinden kaynak/dogruluk skalasi.
- `04_RUNNER_WORKFLOW_TR.md`: Tek runner, F repo ve rapor okuma/yazma akisi.
- `05_SITE_FILTER_REQUIREMENTS_TR.md`: Sitede katman, popup, sag panel ve guncel degisiklik filtresi.
- `06_MANUAL_REVIEW_RULES_TR.md`: Cakisma, eksik kaynak ve manuel inceleme kurallari.

Kural:

Sahte veri uretme. Kaynak yoksa `needs_manual_review=true`, `final_ready=false`, `accuracy_score_4 < 3.0` yaz.
