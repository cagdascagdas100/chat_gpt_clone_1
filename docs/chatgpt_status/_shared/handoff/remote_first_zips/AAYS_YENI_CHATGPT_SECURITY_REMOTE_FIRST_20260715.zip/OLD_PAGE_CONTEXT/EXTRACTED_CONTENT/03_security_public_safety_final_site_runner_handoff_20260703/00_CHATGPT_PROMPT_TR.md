# CHATGPT PROMPT - AAYS Safety / Security Public Safety Layer

Bu gorev yalnizca AAYS/TerraYield uygulamasindaki `Safety / Security` katmani icindir.

## Sabit kokler

Aktif GitHub/F repo:

```text
F:\chatgpt\chat_gpt_clone_1_main
```

Yardimci C repo:

```text
C:\Users\cagda\Documents\GitHub\AAYS
```

Runner/bridge:

```text
C:\AAYS_GITHUB_BRIDGE_CLEAN2
```

Uygulama:

```text
http://127.0.0.1:8010/england_map_web/
```

Program matrix kontrol sayfasi:

```text
http://127.0.0.1:8020/TerraYield_England_Program_Parcel_Layer_Matrix_20260629.html?refresh=20260630-final
```

## Katman

Layer name:

```text
Safety / Security
```

Program output:

```text
Security Level percent
```

## Ana hedef

Her parcel icin konum bilgisine gore public-safety / police-security skoru hesapla.

Skor su sekilde verilecek:

```text
security_score_percent = 0-100
security_level = Very Low Security | Low Security | Medium Security | Good Security | Very Good Security
```

Burada `security_score_percent` yuksekse bolge daha guvenli kabul edilir. Bu risk skoru degil, guvenlik skorudur.

## Kaynaklar

Yalnizca yasal, resmi veya acik aggregate kaynaklar kullan:

1. Resmi polis/public safety istatistikleri
2. Police.uk veya resmi police force/open data kaynaklari
3. Local authority community safety / crime reports
4. ONS / LSOA / MSOA / deprivation-crime-domain gibi bolgesel aggregate kaynaklar
5. Polis karakolu / public safety facility yakinligi
6. Harita tabanli bolge ve cadde/sokak eslesmesi
7. Guvenilir web kaynaklari ve raporlar
8. AI guvencesi: kaynaklarin, skorun ve aciklamanin tutarlilik kontrolu

Kullanma:

- kisi bazli veri
- supheli/suclu kisilerle ilgili veri
- sosyal medya kisileri
- ozel/kapali/izin gerektiren veri
- ucretli veya iletisim gerektiren veri
- sahte veya tahmini veri

## AI guvencesi

AI kontrolu su isleri yapacak:

- Kaynaklar ayni parcel/bolge/geography ile eslesiyor mu kontrol edecek.
- Crime/security sinifi ile hesaplanan skor tutarli mi kontrol edecek.
- Kaynak tarihlerinin cok eski olup olmadigini kontrol edecek.
- Polis karakolu yakinligi, incident density, neighborhood crime rate gibi faktorlerin agirligini denetleyecek.
- Celiski varsa `conflict_status` alanina yazacak.

AI tek basina final kanit degildir. AI onayi, resmi/acik kaynak kanitlarini destekler.

## Her parcel icin uretilecek alanlar

```text
parcel_id
security_score_percent
security_level
security_color_category
crime_rate_index
incident_density_index
police_station_distance_m
neighborhood_safety_index
official_source_evidence
web_source_evidence
map_source_evidence
ai_assurance_summary
ai_assurance_result
source_date
source_geography_level
matching_method
calculation_method
calculation_explanation
confidence_score_4
confidence_label_4
accuracy_score_4
accuracy_label_4
conflict_status
needs_manual_review
last_updated
changed_in_latest_run
change_reason
```

## Bes seviye siniflama

```text
0-20   = Very Low Security
21-40  = Low Security
41-60  = Medium Security
61-80  = Good Security
81-100 = Very Good Security
```

Renkler:

```text
Very Low Security  = #b91c1c
Low Security       = #f97316
Medium Security    = #facc15
Good Security      = #22c55e
Very Good Security = #15803d
No Data            = #6b7280
```

## Dogruluk hedefi

Hedef:

```text
accuracy_score_4 >= 3.0
```

Genel mantik:

- Resmi aggregate kaynak + parcel/geography eslesmesi varsa 3/4 seviyesine yaklasir.
- Resmi kaynak + harita eslesmesi + AI tutarlilik kontrolu varsa 3.5/4 seviyesine cikabilir.
- Birden fazla resmi/acik kaynak, guncel tarih ve iyi geography eslesmesi varsa 3.75/4 veya 4/4 olabilir.
- Kaynaklar celisirse veya geography seviyesi cok genelse skoru dusur.

## Cakisma kurallari

AI guvencesi ile kaynaklar farkli sonuc verirse:

```text
conflict_status=ai_source_conflict
needs_manual_review=true
accuracy_score_4 <= 2.75
```

Resmi kaynaklar birbirleriyle celisirse:

```text
conflict_status=source_conflict
needs_manual_review=true
```

Kanit yoksa:

```text
security_score_percent=null
security_level=No Data
accuracy_score_4=0
needs_manual_review=true
```

## Cikti dosyalari

Asagidaki dosyalar uretilsin veya guncellensin:

```text
F:\chatgpt\chat_gpt_clone_1_main\england_map_web\data\security_public_safety\parcel_security_scores_verified.geojson
F:\chatgpt\chat_gpt_clone_1_main\england_map_web\data\security_public_safety\parcel_security_scores_verified.csv
F:\chatgpt\chat_gpt_clone_1_main\england_map_web\data\security_public_safety\security_evidence_manifest.json
F:\chatgpt\chat_gpt_clone_1_main\docs\chatgpt_status\security_public_safety\reports\security_public_safety_progress_latest.md
F:\chatgpt\chat_gpt_clone_1_main\docs\chatgpt_status\security_public_safety\reports\security_public_safety_manual_review_latest.csv
```

## Site entegrasyonu

Security butonu tiklandiginda:

- Katman acilmali/kapanmali.
- Buton aktifken gorsel aktif state olmali.
- Parceller 5 seviyeli renge gore boyanmali.
- Veri yoksa gri/transparent olmali.
- Parcel tiklaninca popup veya sag panelde security score, level, color, sources, evidence, source date, confidence/accuracy, matching method ve hesaplama aciklamasi gorunmeli.

Ek filtre:

```text
Guncel degisiklikler
```

Bu filtre son calismada degisen kayitlari gosterir:

```text
changed_in_latest_run=true
```

## Runner akisi

Tek shared runner disinda yeni runner acma.

ChatGPT sayfasinda kullanici `devam` dediginde:

1. Son raporu oku.
2. Eksik/bekleyen parcel batchini belirle.
3. Queue task dosyasini ilgili page-key altina yaz.
4. Tek runner taski alsin.
5. Runner ciktiyi F repo altina yazsin.
6. ChatGPT raporu okuyup sonraki batch icin devam etsin.

## Kabul kriteri

Katman ancak su kosullarda tamam sayilir:

- GeoJSON parse ediliyor.
- Her feature parcel_id tasiyor.
- Her feature `security_score_percent` veya No Data sebebi tasiyor.
- Her feature 5 seviyeli security level sozlesmesine uyuyor.
- Accuracy score 0-4 araliginda.
- 3/4 hedefi icin kaynaklar listeleniyor.
- Problemli kayitlar manuel review dosyasina ayriliyor.
- Sitede Security katmani aciliyor.
- Sitede guncel degisiklikler filtresi calisiyor.
- Popup/sag panel score, level, source/evidence, confidence ve hesaplama aciklamasini gosteriyor.

Sahte veri uretilirse gorev basarisiz sayilir.
