# README_START_HERE

Yeni sayfada önce `NEW_CHATGPT_PAGE_CONTINUE_PROMPT.md` dosyasını kullan. Durum özeti için `CURRENT_PAGE_WORK_SUMMARY.md`, dosya yolları için `GITHUB_EVIDENCE_INDEX.md` oku.
