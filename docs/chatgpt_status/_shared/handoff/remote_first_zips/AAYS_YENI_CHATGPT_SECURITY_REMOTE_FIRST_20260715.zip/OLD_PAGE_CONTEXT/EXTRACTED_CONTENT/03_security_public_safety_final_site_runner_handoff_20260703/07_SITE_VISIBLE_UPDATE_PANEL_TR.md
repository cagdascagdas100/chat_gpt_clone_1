# Site-visible update panel contract

Bu dosya `Safety / Security` katmani icin ChatGPT + tek runner akisinda sitede gorulebilir guncelleme sozlesmesidir.

## Kontrol sayfasi

Kullanici su sayfadan ilerlemeyi kontrol eder:

```text
http://127.0.0.1:8020/TerraYield_England_Program_Parcel_Layer_Matrix_20260629.html?refresh=20260630-final
```

Bu sayfa su kucuk JSON dosyasini okur:

```text
outputs/england_program_parcel_matrix_20260629/security_public_safety_updates/latest_changes.json
```

## ChatGPT / runner davranisi

Her `devam` turunda:

1. Son raporu oku.
2. Islenecek parcel batch'ini belirle.
3. Sadece yasal, resmi veya acik aggregate public-safety kaynaklari kullan.
4. Kisi bazli veri, supheli/suclu kisi verisi veya hassas kisisel veri kullanma.
5. Sonuclari `docs/chatgpt_status/security_public_safety/reports/` altina raporla.
6. Site gorunurlugu icin `latest_changes.json` dosyasini guncelle.
7. Kanitlar gercek degilse `final_ready=false` kalmali.

## latest_changes.json zorunlu alanlari

```json
{
  "layer": "Safety / Security",
  "program_output": "Security Level percent",
  "status": "RUNNING_OR_READY_OR_BLOCKED",
  "fake_data": false,
  "last_updated": "YYYY-MM-DD",
  "summary": {
    "changed_count": 0,
    "verified_count": 0,
    "manual_review_count": 0,
    "accuracy_ge_3_count": 0,
    "final_ready": false
  },
  "changes": []
}
```

Her `changes[]` kaydi en az sunlari icermeli:

```json
{
  "parcel_id": "parcel_...",
  "security_score_percent": 0,
  "security_level": "Very Low Security | Low Security | Medium Security | Good Security | Very Good Security",
  "accuracy_score_4": 3,
  "accuracy_label_4": "High Accuracy",
  "changed_in_latest_run": true,
  "needs_manual_review": false,
  "change_reason": "official aggregate crime data + police proximity + AI consistency check",
  "source_geography_level": "street | postcode | LSOA | MSOA | local_authority",
  "source_date": "YYYY-MM-DD",
  "official_source_evidence": "source names, file names, URLs",
  "ai_assurance_result": "PASS | WARNING | CONFLICT"
}
```

## Dogruluk esigi

Kullanicinin bekledigi minimum yayinlanabilir dogruluk:

```text
accuracy_score_4 >= 3/4
```

AI kontrolu tek basina yeterli degildir. Resmi/acik aggregate kaynakla desteklenmelidir.

## Final kural

`final_ready=true` sadece su durumda yazilir:

- parcel polygon layer sitede gorulebilir,
- Security butonu dogru katmani acar,
- parcel tiklaninca skor, seviye, renk, kaynak, kaynak tarihi, confidence/accuracy, matching method ve hesaplama aciklamasi panelde gorunur,
- `latest_changes.json` son run degisikliklerini gosterir,
- fake data yoktur.
