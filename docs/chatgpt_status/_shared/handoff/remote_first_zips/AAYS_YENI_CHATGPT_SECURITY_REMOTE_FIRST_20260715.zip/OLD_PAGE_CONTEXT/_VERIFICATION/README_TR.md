# oldSecurity doğrulama notu

Bu paket, istenen dört kaynak dosyayı tek ZIP içinde birleştirir.

## Yapı

- `ORIGINAL_FILES/`: Yüklenen dört dosyanın birebir kopyaları.
- `EXTRACTED_CONTENT/`: Üç ZIP arşivinin içerikleri birbirinden ayrılmış klasörlere çıkarılmıştır; bağımsız Markdown dosyası da ayrı klasöre kopyalanmıştır.
- `_VERIFICATION/manifest.json`: Boyut, SHA-256, ZIP CRC sonucu, üye sayısı ve hedef yollar.
- `_VERIFICATION/SHA256SUMS.txt`: Orijinal dosyaların SHA-256 değerleri.

## Kontroller

- Tüm dört kaynak dosya bulundu.
- Üç ZIP için CRC testi geçti.
- Arşiv içi mutlak yol ve `..` path traversal yolları reddedildi.
- Kaynaklar ayrı klasörlerde tutulduğu için dosya adı çakışmasıyla veri kaybı yoktur.
- Orijinal arşivler de aynen saklandığından hiçbir bilgi kaybolmamıştır.
